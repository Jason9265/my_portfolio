"""Run the leave-one-region-out K-shot protocol on the L2 embeddings, and on the
random-init control. Same folds, class sets, seeds and readouts as the L1 study,
so the comparison is like-for-like.
"""
import argparse
import collections
import json
import os

import numpy as np
from sklearn.linear_model import LogisticRegression

from experiment import macro_f1, standardize


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feats", default="data/l2_presto.npz")
    ap.add_argument("--ks", default="1,5,10,20")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--out", default="results/l2.json")
    a = ap.parse_args()

    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    y, region = d["y"], d["region"]
    reg = json.load(open("data/regions.json"))
    F = np.load(a.feats)
    ks = [int(x) for x in a.ks.split(",")]

    warm_missing = []
    runs = []
    for key in sorted(F.files):
        parts = key.rsplit("_", 1)
        family, w = parts[0], int(parts[1][1:])
        E = F[key]

        for test_r in reg["viable"]:
            te = region == test_r
            cnt = collections.Counter(y[te].tolist())
            shared = np.array(sorted(
                c for c in set(np.unique(y[~te]).tolist()) & set(cnt)
                if cnt[c] >= max(30, max(ks) + 10)))
            if len(shared) < 3:
                continue
            te_sel = te & np.isin(y, shared)
            tr_sel = (~te) & np.isin(y, shared)
            Etr, Ete = E[tr_sel], E[te_sel]
            ytr, yte = y[tr_sel], y[te_sel]
            Etr, Ete = standardize(Etr, Ete)

            for k in ks:
                for seed in range(a.seeds):
                    rng = np.random.default_rng(1000 * seed + k)
                    sup = np.concatenate([
                        rng.choice(np.where(yte == c)[0], k, replace=False)
                        for c in shared])
                    q = np.setdiff1d(np.arange(len(yte)), sup)
                    if len(q) < 50:
                        continue
                    Xs, ys = Ete[sup], yte[sup]
                    Xq, yq = Ete[q], yte[q]

                    # nearest class mean (cosine)
                    M = np.stack([Xs[ys == c].mean(0) for c in shared])
                    M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-8
                    Q = Xq / (np.linalg.norm(Xq, axis=1, keepdims=True) + 1e-8)
                    p_proto = shared[(Q @ M.T).argmax(1)]

                    clf = LogisticRegression(max_iter=2000, C=1.0, n_jobs=-1)
                    clf.fit(Xs, ys)
                    p_lr = clf.predict(Xq)

                    for name, p in (("proto", p_proto), ("logreg", p_lr)):
                        runs.append({
                            "family": family, "w": w, "region": test_r, "k": k,
                            "seed": seed, "method": name,
                            "oa": float((p == yq).mean()),
                            "macro_f1": macro_f1(yq, p),
                        })
        print(f"  {key} done ({len(runs)} runs)", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(runs, open(a.out, "w"))
    print(f"saved {a.out}: {len(runs)} runs")


if __name__ == "__main__":
    main()
