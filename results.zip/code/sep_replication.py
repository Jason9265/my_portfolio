"""Independent replication of the separability construct on CropHarvest.

Why this matters: on BreizhCrops the peak-DOY predictor was PRE-REGISTERED and
failed, and the separability construct was chosen only afterwards. That is a
garden-of-forking-paths risk -- a reviewer will ask whether the replacement was
found by trying until something worked. If the same construct reproduces on an
independent dataset, the post-hoc concern largely dissolves.

Design choices that keep the test honest:
  * Separability is computed from the NDVI trajectory ALONE (1 of 18 channels).
    The per-class accuracy it must predict comes from a classifier over the full
    90-dim temporal-statistics representation. So the predictor is not simply
    reading back the geometry the classifier was fit on.
  * Class mean profiles are taken from the held-out region's own samples, since
    that is the region the per-class accuracy is measured on.
  * Same protocol cell as BreizhCrops: logreg, k=20.
"""
import collections
import json

import numpy as np
from scipy import stats

NDVI = 17


def class_profiles(X, y, w, n_classes):
    """Class mean NDVI trajectory over bins [0, w) -> (n_classes, w), NaN if absent.

    NOTE: y holds integer class INDICES; d["classes"] holds the class NAMES.
    Iterate over range(n_classes), not over the names.
    """
    prof = np.full((n_classes, w), np.nan)
    for c in range(n_classes):
        m = y == c
        if m.sum() < 10:
            continue
        prof[c, :w] = X[m, :w, NDVI].mean(axis=0)
    return prof


def separability(prof):
    """Min distance from each class's profile to any other class's. NaN if undefined."""
    C = len(prof)
    out = np.full(C, np.nan)
    for c in range(C):
        best = np.inf
        for d in range(C):
            if d == c:
                continue
            v = ~np.isnan(prof[c]) & ~np.isnan(prof[d])
            if v.sum() < 2:
                continue
            best = min(best, np.sqrt(np.mean((prof[c, v] - prof[d, v]) ** 2)))
        out[c] = best if np.isfinite(best) else np.nan
    return out


def main():
    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    X, y, region = d["X"], d["y"], d["region"]
    classes = list(d["classes"])

    ps = json.load(open("results/per_sample.json"))
    by = collections.defaultdict(list)
    for r in ps:
        by[(r["region"], r["w"])].append(r)

    print("CropHarvest separability replication (logreg, k=20)")
    print(f"{'region':22s}{'w':>3s}{'n_cls':>7s}{'r':>9s}{'p':>10s}{'rho':>9s}{'p':>10s}")
    allr, allp = [], []
    per_region = {}
    for (reg, w), v in sorted(by.items()):
        cls = np.array([x["cls"] for x in v])
        acc = np.array([x["acc"] for x in v])
        te = region == reg
        prof = class_profiles(X[te], y[te], w, len(classes))
        sep = separability(prof)
        # per-class mean accuracy
        pacc = np.array([acc[cls == c].mean() if (cls == c).sum() >= 10 else np.nan
                         for c in range(len(classes))])
        ok = ~np.isnan(sep) & ~np.isnan(pacc)
        if ok.sum() < 4:
            continue
        r, p = stats.pearsonr(sep[ok], pacc[ok])
        rho, prho = stats.spearmanr(sep[ok], pacc[ok])
        print(f"{reg:22s}{w:3d}{ok.sum():7d}{r:+9.3f}{p:10.4f}{rho:+9.3f}{prho:10.4f}")
        allr.append(r); allp.append(p)
        per_region.setdefault(reg, []).append(r)

    allr = np.array(allr); allp = np.array(allp)
    print()
    print(f"  cells: {len(allr)}")
    print(f"  positive r: {(allr>0).sum()}/{len(allr)}")
    print(f"  median r  : {np.median(allr):+.3f}")
    print(f"  cells with p<0.05: {(allp<0.05).sum()}/{len(allp)}")
    # Fisher-style: is the pooled set of cells positive?
    print(f"  sign-test on 24 cells: p = {stats.binomtest((allr>0).sum(), len(allr), 0.5).pvalue:.2e}")
    print()
    print("  per-region median r:")
    for reg, rs in sorted(per_region.items()):
        print(f"    {reg:22s} median r = {np.median(rs):+.3f}  (n_cells={len(rs)})")


if __name__ == "__main__":
    main()
