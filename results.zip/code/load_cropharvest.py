"""Load CropHarvest precomputed features + labels into aligned arrays.

Feature layout (verified empirically against cropharvest/bands.py BANDS order):
  0-1   VV, VH              (Sentinel-1, dB)
  2-12  B2,B3,B4,B5,B6,B7,B8,B8A,B9,B11,B12  (Sentinel-2, reflectance x1e4)
  13    temperature_2m      (K)
  14    total_precipitation (m)
  15    elevation           (m)   STATIC
  16    slope               (deg) STATIC
  17    NDVI
"""
import glob
import json
import os

import h5py
import numpy as np

FEAT_DIR = os.path.join("data", "features", "features", "arrays")
LABELS = os.path.join("data", "labels.geojson")

BAND_NAMES = (
    ["VV", "VH"]
    + ["B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9", "B11", "B12"]
    + ["temperature_2m", "total_precipitation", "elevation", "slope", "NDVI"]
)
NDVI_IDX = 17
STATIC_IDX = [15, 16]


def load_labels():
    with open(LABELS) as f:
        feats = json.load(f)["features"]
    rows = []
    for f in feats:
        p = f["properties"]
        rows.append({
            "index": p["index"],
            "dataset": p["dataset"],
            "is_crop": p["is_crop"],
            "crop_type": p.get("classification_label"),
            "planting_date": p.get("planting_date"),
            "harvest_date": p.get("harvest_date"),
            "collection_date": p.get("collection_date"),
            "lat": p.get("lat"),
            "lon": p.get("lon"),
            "is_test": p["is_test"],
        })
    return rows


def load_features(rows, limit=None):
    """Join h5 features to label rows. Returns X (N,T,C), plus parallel metadata."""
    meta = {(r["index"], r["dataset"]): r for r in rows}
    X, kept = [], []
    files = sorted(glob.glob(os.path.join(FEAT_DIR, "*.h5")))
    if limit:
        files = files[:limit]
    for fp in files:
        base = os.path.basename(fp)[:-3]          # strip .h5
        idx_s, ds = base.split("_", 1)
        key = (int(idx_s), ds)
        r = meta.get(key)
        if r is None:
            continue
        with h5py.File(fp, "r") as h:
            X.append(h["array"][:])
        kept.append(r)
    return np.stack(X), kept


if __name__ == "__main__":
    rows = load_labels()
    print(f"label rows: {len(rows)}")
    X, kept = load_features(rows)
    print(f"feature tensor: {X.shape}  (N, T, C)")
    np.save("data/X_cropharvest.npy", X)
    with open("data/meta_cropharvest.json", "w") as f:
        json.dump(kept, f)
    print("saved data/X_cropharvest.npy + data/meta_cropharvest.json")
