"""How much does the random-init encoder's own draw move the §4.8 comparison?

The seventh review's Comment 5: the Presto-vs-random control builds the random
encoder once (seed=0) and reuses it for every window, k and seed, so the
reported +0.031 advantage could partly reflect that single random draw.

This extracts features from additional independent random initializations and
re-runs the identical protocol on each, so the draw-to-draw spread of the random
arm can be compared against the reported pretraining gap.

Protocol is copied from run_l2.py so the seed=0 arm reproduces results/l2.json.

Outputs results/random_encoder_draws.json.
"""
import argparse
import collections
import json
import os
import time

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression

from experiment import macro_f1, standardize
from presto_features import extract
from extract_l2 import build_random_encoder


def eval_arm(E, y, region, viable, ks, seeds):
    """run_l2.py's protocol on one feature matrix -> mean macro-F1 (logreg)."""
    out = []
    for test_r in viable:
        te = region == test_r
        cnt = collections.Counter(y[te].tolist())
        shared = np.array(sorted(
            c for c in set(np.unique(y[~te]).tolist()) & set(cnt)
            if cnt[c] >= max(30, max(ks) + 10)))
        if len(shared) < 3:
            continue
        te_sel = te & np.isin(y, shared)
        tr_sel = (~te) & np.isin(y, shared)
        Etr, Ete = standardize(E[tr_sel], E[te_sel])
        ytr, yte = y[tr_sel], y[te_sel]
        for k in ks:
            for seed in range(seeds):
                rng = np.random.default_rng(1000 * seed + k)
                sup = np.concatenate([
                    rng.choice(np.where(yte == c)[0], k, replace=False)
                    for c in shared])
                q = np.setdiff1d(np.arange(len(yte)), sup)
                if len(q) < 50:
                    continue
                clf = LogisticRegression(max_iter=2000, C=1.0, n_jobs=-1)
                clf.fit(Ete[sup], yte[sup])
                p = clf.predict(Ete[q])
                out.append(macro_f1(yte[q], p))
    return np.array(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--W", type=int, default=12)
    ap.add_argument("--ks", default="1,5,10,20")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--draws", default="1,2")     # additional random inits
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--out", default="results/random_encoder_draws.json")
    a = ap.parse_args()

    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    X, y, region = d["X"], d["y"], d["region"]
    reg = json.load(open("data/regions.json"))
    meta = json.load(open("data/meta_cropharvest.json"))
    keep = [m for m in meta
            if m.get("crop_type") not in (None, "non_crop")
            and m.get("crop_type") in set(d["classes"])]
    assert len(keep) == len(X)
    latlons = np.array([[m["lat"] or 0.0, m["lon"] or 0.0] for m in keep],
                       dtype=np.float32)
    dev = a.device if torch.cuda.is_available() else "cpu"
    ks = [int(x) for x in a.ks.split(",")]

    F = np.load("data/l2_presto.npz", allow_pickle=True)
    x18 = X[:, :a.W, :]

    arms = {}
    arms["presto"] = F[f"presto_w{a.W}"]
    arms["random_s0"] = F[f"random_w{a.W}"]

    for s in [int(x) for x in a.draws.split(",")]:
        t0 = time.time()
        enc = build_random_encoder(seed=s, device=dev)
        arms[f"random_s{s}"] = extract(enc, x18, latlons, device=dev)
        print(f"  extracted random init seed={s} in {time.time()-t0:.0f}s",
              flush=True)

    res = {}
    for name, E in arms.items():
        mf = eval_arm(E, y, region, reg["viable"], ks, a.seeds)
        res[name] = {"n_runs": int(len(mf)), "mean_macro_f1": float(mf.mean()),
                     "sd": float(mf.std(ddof=1))}
        print(f"  {name:12s} mean macro-F1 = {mf.mean():.4f}  (n={len(mf)})",
              flush=True)

    pre = res["presto"]["mean_macro_f1"]
    print(f"\n=== pretraining advantage at w={a.W} (logreg) ===")
    for name in arms:
        if name == "presto":
            continue
        d_ = pre - res[name]["mean_macro_f1"]
        print(f"  presto - {name:12s} = {d_:+.4f}")
    draws = [k for k in res if k.startswith("random")]
    vals = np.array([res[k]["mean_macro_f1"] for k in draws])
    gaps = pre - vals
    print(f"\n  random-arm macro-F1 across {len(draws)} independent draws: "
          f"{vals.min():.4f} .. {vals.max():.4f}  (spread {vals.max()-vals.min():.4f})")
    print(f"  pretraining gap across draws: "
          f"{gaps.min():+.4f} .. {gaps.max():+.4f}  (spread {gaps.max()-gaps.min():.4f})")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"W": a.W, "ks": ks, "seeds": a.seeds, "arms": res}, open(a.out, "w"),
              indent=1)
    print(f"\nsaved {a.out}")


if __name__ == "__main__":
    main()
