"""L2 on BreizhCrops raw S2 time series: frozen Presto vs a random-init control.

Why this is worth running before eo_data lands: it tests the same hypothesis as
L2b -- that the tiny +0.036 pretraining gain on CropHarvest came from the input
being pre-aggregated to 17 effective dims -- but on REAL, un-aggregated Sentinel-2
time series.

HONEST LIMITATION: BreizhCrops ships only 10 S2 bands. Presto expects 17 channels
(S1 x2, S2 x10, ERA5 x2, SRTM x2, NDVI). The six absent channels are supplied as
zero and MASKED, so this is a partial-input test. Presto's mask mechanism is
exactly what it was pretrained with (MAE-style masked reconstruction), so this is
a valid forward pass, but it is weaker evidence than the full 17-channel CropHarvest
L2b.

Presto's positional table holds 24 timesteps, so windows are capped at w=24.
"""
import argparse
import collections
import json
import os
import time

import numpy as np
import torch

from extract_l2 import build_random_encoder
from presto_features import (ADD_BY, BANDS, DIVIDE_BY, NORMED_BANDS,
                             build_encoder)

# BreizhCrops band order -> Presto NORMED_BANDS slots
BR = ["B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B11", "B12"]


def build_presto_input(X, mask, w):
    """(N,36,11) BreizhCrops + bin mask -> (N,w,17) inputs, (N,w,17) mask, (N,2).

    BreizhCrops bands are already x1e4 reflectance, matching Presto's S2 scaling,
    so no rescale is needed. NDVI is appended as channel 16. Absent groups
    (S1/ERA5/SRTM) stay zero and permanently masked.
    """
    sub = X[:, :w, :]
    m = mask[:, :w]
    N, T, _ = sub.shape
    x = np.zeros((N, T, len(NORMED_BANDS)), dtype=np.float32)
    msk = np.ones((N, T, len(NORMED_BANDS)), dtype=np.float32)   # 1 = missing

    for b in BR:
        src = X.shape[2] - 1 if b == "NDVI" else BR.index(b)
        dst = NORMED_BANDS.index(b)
        x[:, :, dst] = sub[:, :, src]
        msk[:, :, dst] = (~m).astype(np.float32)   # observed where mask is True

    # NDVI recomputed from this window's B8/B4
    b4 = x[:, :, NORMED_BANDS.index("B4")]
    b8 = x[:, :, NORMED_BANDS.index("B8")]
    den = b8 + b4
    nd = np.where(den > 1e-6, (b8 - b4) / np.maximum(den, 1e-6), 0.0)
    nd_ok = ((den > 1e-6) & (x[:, :, NORMED_BANDS.index("B4")] > 0)).astype(np.float32)
    x[:, :, NORMED_BANDS.index("NDVI")] = nd
    msk[:, :, NORMED_BANDS.index("NDVI")] = 1.0 - nd_ok

    # scale the present S2 channels (Presto divides by 1e4); others stay zero
    s2 = [NORMED_BANDS.index(b) for b in BR]
    x[:, :, s2] = x[:, :, s2] / 1e4
    return x, msk


@torch.no_grad()
def extract(enc, X, mask, w, batch=256, device="cuda", month=1):
    """Frozen embeddings, batched by masked-token count.

    Presto's `mask_tokens` asserts that every item in a batch has the SAME number
    of masked tokens (official implementation, single_file_presto.py:327). Cloud
    gaps differ per parcel, so a naive batch trips that assert. Rather than dilute
    the masking (passing missing bins as unmasked zeros, which Presto would read
    as real reflectance), group samples by their masked-token count and batch
    within each group.
    """
    x, msk = build_presto_input(X, mask, w)
    N = len(x)
    emb_out = np.zeros((N, 128), dtype=np.float32)

    counts = msk.sum(axis=(1, 2)).astype(np.int64)
    order = np.argsort(counts, kind="stable")
    c_sorted = counts[order]
    # boundaries of equal-count runs
    starts = np.flatnonzero(np.r_[True, c_sorted[1:] != c_sorted[:-1]])
    ends = np.r_[starts[1:], len(order)]

    for s, e in zip(starts, ends):
        idx_all = order[s:e]
        for i in range(0, len(idx_all), batch):
            idx = idx_all[i:i + batch]
            xb = torch.from_numpy(x[idx]).to(device)
            mb = torch.from_numpy(msk[idx]).to(device)
            dw = torch.full((len(idx), w), 9, dtype=torch.long, device=device)
            # latlons carry no transferable signal here: BreizhCrops is four
            # adjacent regions in one French department. Pass zeros.
            lb = torch.zeros((len(idx), 2), dtype=torch.float32, device=device)
            emb = enc(x=xb, dynamic_world=dw, latlons=lb, mask=mb, month=month,
                      eval_task=True)
            emb_out[idx] = emb.float().cpu().numpy()
    return emb_out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="6,12,18,24")
    ap.add_argument("--ks", default="1,5,20")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--cap", type=int, default=1500)
    ap.add_argument("--out", default="results/breizh_l2.json")
    a = ap.parse_args()

    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    from breizh_exp import build_feats, load, macro_f1
    from sklearn.linear_model import LogisticRegression
    from experiment import standardize

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    X, mask, y, region, bands, keep = load(cap_per_cell=a.cap)
    cls_of = {c: i for i, c in enumerate(keep)}
    y = np.array([cls_of[v] for v in y])
    print(f"parcels {X.shape}  classes {len(keep)}  device {dev}")

    enc = build_encoder(device=dev)
    rnd = build_random_encoder(seed=0, device=dev)

    runs = []
    ws = [int(x) for x in a.windows.split(",")]
    embs = {}
    for w in ws:
        t0 = time.time()
        embs[("presto", w)] = extract(enc, X, mask, w, device=dev)
        embs[("random", w)] = extract(rnd, X, mask, w, device=dev)
        print(f"  w={w:2d} extracted both in {time.time()-t0:.1f}s", flush=True)

    for w in ws:
        for fam in ("presto", "random"):
            E = embs[(fam, w)]
            for test_r in sorted(set(region)):
                te = region == test_r
                tr = ~te
                Etr, Ete = standardize(E[tr], E[te])
                ytr, yte = y[tr], y[te]
                for k in [int(x) for x in a.ks.split(",")]:
                    for seed in range(a.seeds):
                        rng = np.random.default_rng(1000 * seed + k)
                        sup = np.concatenate([
                            rng.choice(np.where(yte == c)[0], k, replace=False)
                            for c in range(len(keep))])
                        q = np.setdiff1d(np.arange(len(yte)), sup)
                        Xs, ys = Ete[sup], yte[sup]
                        Xq, yq = Ete[q], yte[q]
                        M = np.stack([Xs[ys == c].mean(0)
                                      for c in range(len(keep))])
                        M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-8
                        Q = Xq / (np.linalg.norm(Xq, axis=1, keepdims=True) + 1e-8)
                        pp = (Q @ M.T).argmax(1)
                        clf = LogisticRegression(max_iter=1000, C=1.0, n_jobs=-1)
                        clf.fit(Xs, ys)
                        pl = clf.predict(Xq)
                        for name, p in (("proto", pp), ("logreg", pl)):
                            mf, _ = macro_f1(yq, p, list(range(len(keep))))
                            runs.append({"family": fam, "w": w, "region": test_r,
                                         "k": k, "seed": seed, "method": name,
                                         "oa": float((p == yq).mean()),
                                         "macro_f1": mf})
            print(f"  w={w:2d} {fam} protocol done ({len(runs)})", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(runs, open(a.out, "w"))
    print(f"saved {a.out}: {len(runs)} runs")


if __name__ == "__main__":
    main()
