"""Budget-order permutation, re-run on the SAME protocol as the main table.

The seventh review noticed that §4.5.2's permutation table reports a fixed-order
value (+0.603) that does not match Table 19's support arm at rho=100 (+0.408),
and asked whether the two use different correlation statistics.

They do not — both are the single-influential-class-removal (SICR) correlation.
The discrepancy is the protocol: the first permutation run drew ONE sample per
cell, while Table 19 averages five seeds.

This version reproduces Table 19's protocol exactly (seeds 0..4, rng seeded
1000*seed + rho, identical budget/availability handling) so the fixed-order row
equals the published table, then applies the same averaged protocol to the
permuted orderings. Both r (raw Pearson) and r2 (SICR) are recorded so the
reported statistic is explicit.

Outputs results/imbalance_permutation.json (overwrites the single-seed run).
"""
import argparse
import json
import os
import warnings

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from eurocropsml_exp import BATCH, build_feats, macro_f1
from eurocropsml_noncircular import ndvi_trajectories, separability
from eurocropsml_imbalance import MIN_TEST, MIN_SUP, skewed_counts

ARMS = ("balanced", "support", "test")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--W", type=int, default=240)
    ap.add_argument("--k", type=int, default=20)
    ap.add_argument("--test-base", type=int, default=100)
    ap.add_argument("--rhos", default="1,10,100")
    ap.add_argument("--perms", type=int, default=100)
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--out", default="results/imbalance_permutation.json")
    a = ap.parse_args()

    D = np.load(a.ds, allow_pickle=True)
    n_cls = len(D["classes"])
    yt, ys = D["test_label"], D[f"sup{a.k}_label"]
    tst_n = np.array([(yt == c).sum() for c in range(n_cls)])
    sup_n = np.array([(ys == c).sum() for c in range(n_cls)])
    cls = [c for c in range(n_cls)
           if tst_n[c] >= max(MIN_TEST, a.test_base) and sup_n[c] >= a.k]
    C = len(cls)
    print(f"fixed class set: {C} classes | seeds={a.seeds} perms={a.perms}")

    W = a.W
    tr = ndvi_trajectories(D["test_data"], D["test_doy"], D["test_valid"])
    nb = min(int(np.ceil(W / 10)), tr.shape[1])
    prof = np.full((n_cls, nb), np.nan)
    for c in cls:
        s = yt == c
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            prof[c] = np.nanmean(tr[s][:, :nb], axis=0)
    sep_by_cls = {c: s for c, s in zip(cls, separability(prof)[cls])}

    idx_t = {c: np.where(yt == c)[0] for c in cls}
    idx_s = {c: np.where(ys == c)[0] for c in cls}
    F_all = build_feats(D["test_data"], D["test_doy"], D["test_valid"], W)
    S_all = build_feats(D[f"sup{a.k}_data"], D[f"sup{a.k}_doy"],
                        D[f"sup{a.k}_valid"], W)
    Fsrc = build_feats(D["pretrain_data"], D["pretrain_doy"],
                       D["pretrain_valid"], W)

    def one_run(bud_t, bud_s, arm, rho, seed):
        """Exactly the main script's draw, so fixed ordering reproduces Table 19."""
        rng = np.random.default_rng(1000 * seed + rho)
        nt = np.minimum(np.array([bud_t[c] for c in cls]),
                        [len(idx_t[c]) for c in cls])
        ns = np.minimum(np.array([bud_s[c] for c in cls]),
                        [len(idx_s[c]) for c in cls])
        te, sup = [], []
        for i, c in enumerate(cls):
            te.extend(rng.choice(idx_t[c], nt[i], replace=False))
            sup.extend(rng.choice(idx_s[c], ns[i], replace=False))
        te, sup = np.array(te), np.array(sup)
        ssel = rng.choice(len(Fsrc), min(BATCH, len(Fsrc)), replace=False)
        mu = Fsrc[ssel].mean(0); sd = Fsrc[ssel].std(0) + 1e-8
        clf = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
        clf.fit(((S_all - mu) / sd)[sup], ys[sup])
        p = clf.predict(((F_all - mu) / sd)[te])
        _, per = macro_f1(yt[te], p, list(range(n_cls)))
        per = np.array(per)[cls]
        # Exactly the main script's statistic: no finite/positive filtering,
        # and the influential class is dropped from the full descending sort.
        sep = np.array([sep_by_cls[c] for c in cls])
        r, _ = stats.pearsonr(sep, per)
        o = np.argsort(-sep)[1:]
        r2, _ = stats.pearsonr(sep[o], per[o])
        return float(r), float(r2), float(np.mean(per))

    def averaged(bud_t_vec, bud_s_vec, rho, perm):
        """Fixed vs permuted differ ONLY in the budget->class mapping.

        The rng seed is held at exactly the main script's 1000*seed + rho, so
        the pair (fixed, permuted) shares its sample draw and isolates ordering.
        """
        order = list(perm) if perm is not None else list(range(C))
        R, R2, MF = [], [], []
        for seed in range(a.seeds):
            bt = {cls[order[i]]: bud_t_vec[i] for i in range(C)}
            bs = {cls[order[i]]: bud_s_vec[i] for i in range(C)}
            r, r2, mf = one_run(bt, bs, arm, rho, seed)
            R.append(r); R2.append(r2); MF.append(mf)
        return float(np.mean(R)), float(np.mean(R2)), float(np.mean(MF))

    rhos = [int(x) for x in a.rhos.split(",")]
    BUD_T = {rho: skewed_counts(C, rho, a.test_base) for rho in rhos}
    BUD_S = {rho: skewed_counts(C, rho, a.k) for rho in rhos}

    recs = []
    for rho in rhos:
        for arm in ARMS:
            bt = BUD_T[rho] if arm == "test" else np.full(C, a.test_base)
            bs = BUD_S[rho] if arm == "support" else np.full(C, a.k)
            if arm == "balanced":
                bt, bs = np.full(C, a.test_base), np.full(C, a.k)
            r, r2, mf = averaged(bt, bs, rho, None)
            recs.append({"rho": rho, "arm": arm, "perm": -1,
                         "r": r, "sicr": r2, "macro_f1": mf})
            for i in range(a.perms):
                perm = np.random.default_rng(90000 + i).permutation(C)
                r, r2, mf = averaged(bt, bs, rho, perm)
                recs.append({"rho": rho, "arm": arm, "perm": i,
                             "r": r, "sicr": r2, "macro_f1": mf})
            print(f"  rho={rho:3d} {arm:9s} done", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(recs, open(a.out, "w"), indent=1)
    print(f"\nsaved {a.out}: {len(recs)} records")

    print("\n" + "=" * 92)
    print("fixed order (same protocol as Table 19) vs permuted, both 5-seed averaged")
    print("=" * 92)
    for rho in rhos:
        print(f"\nrho={rho}")
        for arm in ARMS:
            per = [x for x in recs if x["rho"] == rho and x["arm"] == arm and x["perm"] >= 0]
            fix = [x for x in recs if x["rho"] == rho and x["arm"] == arm and x["perm"] == -1][0]
            for key, lab in (("sicr", "SICR r"), ("macro_f1", "macroF1")):
                v = np.array([x[key] for x in per])
                pct = float((v <= fix[key]).mean())
                print(f"  {arm:9s} {lab:8s} fixed={fix[key]:+.3f} | "
                      f"perm mean={v.mean():+.3f} "
                      f"[{np.percentile(v,2.5):+.3f},{np.percentile(v,97.5):+.3f}] "
                      f"pct={pct*100:5.1f}%")
    print("\n(Table 19 support/rho=100 should read +0.408 if the protocol matches.)")


if __name__ == "__main__":
    main()
