"""Direct test of the measurement-error mechanism behind test-set scarcity (§4.5).

The second-round review's #1 major comment: §4.5 argued that test skew is an
estimation artifact because "the correlation drops more than mean performance".
That is suggestive but not sufficient -- the test subset, the F1 estimates and
the correlation estimator all change together, so the argument is correlational.

The clean test holds EVERYTHING about the classifier fixed:

  1. Train ONE classifier on the fixed 24-class balanced set (W=240, k=20).
  2. Predict on the FULL test observations of those 24 classes.
  3. Freeze those predictions. Never retrain.
  4. Subsample n_c observations per class from the frozen predictions,
     n_c in {100, 50, 20, 10, 5}, many repetitions.
  5. Watch Var(F1_hat_c) and E[rho(separability, F1_hat)].

If test size falls, Var(F1) rises, and rho falls -- with the underlying
classifier provably unchanged -- then the relationship's decay under test
scarcity is measurement error, directly demonstrated rather than inferred.

Outputs results/testscarcity_subsample.json.
"""
import argparse
import json
import os
import warnings

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from eurocropsml_exp import BATCH, build_feats, macro_f1
from eurocropsml_noncircular import ndvi_trajectories, separability

MIN_TEST = 100
MIN_SUP = 20


def per_class_f1(y_true, y_pred, classes, n_cls):
    """Reuse the project's macro_f1 decomposition so the F1 definition matches."""
    _, per = macro_f1(y_true, y_pred, list(range(n_cls)))
    return np.array(per)[classes]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--W", type=int, default=240)
    ap.add_argument("--k", type=int, default=20)
    ap.add_argument("--ncs", default="100,50,20,10,5")
    ap.add_argument("--reps", type=int, default=500)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--out", default="results/testscarcity_subsample.json")
    a = ap.parse_args()

    D = np.load(a.ds, allow_pickle=True)
    n_cls = len(D["classes"])
    yt = D["test_label"]
    ys = D[f"sup{a.k}_label"]
    tst_n = np.array([(yt == c).sum() for c in range(n_cls)])
    sup_n = np.array([(ys == c).sum() for c in range(n_cls)])

    cls = [c for c in range(n_cls)
           if tst_n[c] >= MIN_TEST and sup_n[c] >= a.k]
    C = len(cls)
    print(f"fixed class set: {C} classes; per-class test counts "
          f"min={min(tst_n[c] for c in cls)} max={max(tst_n[c] for c in cls)}")

    W = a.W
    tr = ndvi_trajectories(D["test_data"], D["test_doy"], D["test_valid"])
    nb = min(int(np.ceil(W / 10)), tr.shape[1])
    prof = np.full((n_cls, nb), np.nan)
    for c in cls:
        s = yt == c
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            prof[c] = np.nanmean(tr[s][:, :nb], axis=0)
    sep = separability(prof)[cls]
    print(f"separability range: [{np.nanmin(sep):.3f}, {np.nanmax(sep):.3f}]")

    idx_t = {c: np.where(yt == c)[0] for c in cls}
    idx_s = {c: np.where(ys == c)[0] for c in cls}
    F_all = build_feats(D["test_data"], D["test_doy"], D["test_valid"], W)
    S_all = build_feats(D[f"sup{a.k}_data"], D[f"sup{a.k}_doy"],
                        D[f"sup{a.k}_valid"], W)
    Fsrc = build_feats(D["pretrain_data"], D["pretrain_doy"],
                       D["pretrain_valid"], W)

    ncs = [int(x) for x in a.ncs.split(",")]
    out = {"n_classes": C, "W": W, "k": a.k, "reps": a.reps,
           "class_test_counts": {str(c): int(tst_n[c]) for c in cls},
           "separability": [float(x) for x in sep], "per_seed": []}

    for seed in range(a.seeds):
        rng = np.random.default_rng(1000 * seed + 7)
        sup = np.concatenate([rng.choice(idx_s[c], a.k, replace=False)
                              for c in cls])
        ssel = rng.choice(len(Fsrc), min(BATCH, len(Fsrc)), replace=False)
        mu = Fsrc[ssel].mean(0); sd = Fsrc[ssel].std(0) + 1e-8
        clf = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
        clf.fit(((S_all - mu) / sd)[sup], ys[sup])

        # FROZEN predictions on every test observation of the 24 classes.
        # Nothing below ever touches the classifier again.
        all_idx = np.concatenate([idx_t[c] for c in cls])
        pred_all = clf.predict(((F_all - mu) / sd)[all_idx])
        true_all = yt[all_idx]
        by_cls = {c: (true_all[np.isin(all_idx, idx_t[c])],
                      pred_all[np.isin(all_idx, idx_t[c])]) for c in cls}

        rec = {"seed": seed, "levels": []}
        full_per = per_class_f1(true_all, pred_all, cls, n_cls)
        rec["full_test_rho"] = float(stats.pearsonr(sep, full_per)[0])
        rec["full_test_macro_f1"] = float(np.mean(full_per))
        print(f"  seed {seed}: full test  rho={rec['full_test_rho']:+.3f}  "
              f"mF1={rec['full_test_macro_f1']:.3f}")

        for nc in ncs:
            per_samples, macro = [], []
            for _ in range(a.reps):
                # Subsample each class, then pool into ONE joint sample. A
                # class's F1 needs false positives drawn from OTHER classes'
                # observations, so computing F1 per class in isolation would
                # silently collapse it to recall.
                tt, pp = [], []
                for c in cls:
                    t_c, p_c = by_cls[c]
                    m = len(t_c)
                    take = min(nc, m)
                    j = rng.choice(m, take, replace=False)
                    tt.append(t_c[j]); pp.append(p_c[j])
                tt = np.concatenate(tt); pp = np.concatenate(pp)
                f1 = per_class_f1(tt, pp, cls, n_cls)
                per_samples.append(f1)
                macro.append(f1.mean())
            per_samples = np.array(per_samples)          # (reps, C)
            rho_s = np.array([stats.pearsonr(sep, p)[0] for p in per_samples])
            rec["levels"].append({
                "n_c": int(nc),
                "mean_per_class_f1": float(per_samples.mean()),
                "mean_class_variance": float(per_samples.var(axis=0, ddof=1).mean()),
                "median_class_variance": float(
                    np.median(per_samples.var(axis=0, ddof=1))),
                "mean_macro_f1": float(np.mean(macro)),
                "sd_macro_f1": float(np.std(macro, ddof=1)),
                "E_rho": float(rho_s.mean()),
                "rho_ci_lo": float(np.percentile(rho_s, 2.5)),
                "rho_ci_hi": float(np.percentile(rho_s, 97.5)),
                "frac_rho_below_full": float(
                    (rho_s < rec["full_test_rho"]).mean()),
            })
            L = rec["levels"][-1]
            print(f"    n_c={nc:3d}: Var(F1)={L['mean_class_variance']:.5f}  "
                  f"E[rho]={L['E_rho']:+.3f} [{L['rho_ci_lo']:+.3f},"
                  f"{L['rho_ci_hi']:+.3f}]  mF1={L['mean_macro_f1']:.3f}")
        out["per_seed"].append(rec)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"\nsaved {a.out}")

    # headline summary across seeds
    print("\n=== summary (mean over classifier seeds) ===")
    print("  n_c   Var(F1_c)   E[rho]    mF1")
    for i, nc in enumerate(ncs):
        v = np.mean([r["levels"][i]["mean_class_variance"] for r in out["per_seed"]])
        e = np.mean([r["levels"][i]["E_rho"] for r in out["per_seed"]])
        m = np.mean([r["levels"][i]["mean_macro_f1"] for r in out["per_seed"]])
        print(f"  {nc:3d}   {v:.5f}     {e:+.3f}   {m:.3f}")


if __name__ == "__main__":
    main()
