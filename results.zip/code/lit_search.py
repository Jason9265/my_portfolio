"""Targeted literature search for the two directions the reviewer asked for.

Verified against OpenAlex and Crossref (both confirmed reachable from this
machine). Every returned record carries a DOI so it can be checked; nothing is
included on the strength of a search snippet alone.

Directions:
  A. phenology-based crop discrimination / phenological metrics as features
  B. class imbalance / long-tail learning in remote sensing & land cover
  C. (supporting) class separability as a measure of classification difficulty
"""
import json
import time
import urllib.parse
import urllib.request

UA = {"User-Agent": "lit-review/1.0 (mailto:research@example.org)"}


def oa(query, n=8, from_year=None):
    # OpenAlex accepts exactly ONE `filter` parameter; clauses are comma-joined.
    # Emitting a second `&filter=` silently REPLACES the first, which drops the
    # search term entirely and returns the all-time most-cited works instead of
    # matches -- exactly how the first run produced COVID/AlphaFold records.
    parts = [f"title_and_abstract.search:{urllib.parse.quote(query)}"]
    if from_year:
        parts.append(f"from_publication_date:{from_year}-01-01")
    u = ("https://api.openalex.org/works?per-page=%d&filter=%s"
         % (n, ",".join(parts)))
    req = urllib.request.Request(u, headers=UA)
    res = None
    last = None
    for attempt in range(3):          # this link drops reads under load
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                res = json.load(r)["results"]
            break
        except Exception as e:
            last = e
            time.sleep(3.0 * (attempt + 1))
    if res is None:
        return [("ERR", f"{type(last).__name__}: {str(last)[:60]}")]
    out = []
    for m in res:
        src = ((m.get("primary_location") or {}).get("source") or {})
        out.append({
            "title": (m.get("title") or "?")[:110],
            "venue": (src.get("display_name") or "?")[:52],
            "year": m.get("publication_year"),
            "doi": (m.get("doi") or "").replace("https://doi.org/", ""),
            "cites": m.get("cited_by_count"),
            "authors": ", ".join(a["author"]["display_name"]
                                 for a in m.get("authorships", [])[:3]),
        })
    return out


QUERIES = [
    ("A. phenology", "phenological metrics crop type classification Sentinel-2 time series"),
    ("A. phenology", "start of season SOS green-up onset crop mapping"),
    ("A. phenology", "crop phenology temporal features discrimination satellite"),
    ("A. phenology", "in-season early crop type mapping partial time series"),
    ("B. imbalance", "long-tailed class imbalance remote sensing land cover classification"),
    ("B. imbalance", "class imbalance crop type classification deep learning"),
    ("B. imbalance", "long-tail learning rare class remote sensing segmentation"),
    ("B. imbalance", "imbalanced learning Earth observation rare categories"),
    ("C. separability", "class separability measure classification difficulty Fisher discriminant"),
    ("C. separability", "inter-class distance prototype classification difficulty metric"),
    # Added 2026-09-26: three directions the review lists that the first pass
    # did not cover -- general time-series classification, uncertainty for rare
    # classes, and cross-region domain shift.
    ("D. timeseries", "time series classification deep learning survey benchmark"),
    ("D. timeseries", "random convolutional kernel transform time series classification"),
    ("E. uncertainty", "predictive uncertainty rare classes remote sensing classification"),
    ("E. uncertainty", "uncertainty quantification long-tailed classification deep learning"),
    ("F. domain shift", "domain adaptation cross-region crop type classification satellite transfer"),
    ("F. domain shift", "spatial domain shift generalization satellite image classification"),
    # Added 2026-09-27: the sixth review asks for adequate coverage of RECENT
    # (2023+) phenology-based crop classification and early/in-season mapping.
    ("G. recent phenology", "crop type classification phenological features 2024 Sentinel-2"),
    ("G. recent phenology", "phenology-based crop mapping deep learning recent"),
    ("H. in-season", "in-season crop mapping early season classification satellite 2024"),
]


def main():
    seen = {}
    for tag, q in QUERIES:
        print(f"\n=== [{tag}] {q}")
        res = oa(q, n=6, from_year=2019)
        if res and isinstance(res[0], tuple):
            print("    ERR", res[0][1]); continue
        for r in res:
            if not r["doi"]:
                continue
            key = r["doi"]
            if key in seen:
                continue
            seen[key] = r
            print(f"   {r['year']} | cites {str(r['cites']):>5} | {r['title'][:78]}")
            print(f"          {r['venue']}  |  {r['doi']}")
        time.sleep(0.4)
    json.dump(list(seen.values()), open("results/lit_candidates.json", "w"),
              indent=1)
    print(f"\n{len(seen)} unique DOI-bearing candidates saved")


if __name__ == "__main__":
    main()
