"""Frozen Presto features for CropHarvest (the L2 layer).

Source of truth: the official implementation, fetched from
nasaharvest/presto@main via a GitHub proxy (github.com is unreachable here) and
vendored into code/presto_ref/. `presto_ref/s1_s2_era5_srtm.py` defines the band
order and the normalisation constants; `presto_ref/single_file_presto.py` defines
the forward pass.

CropHarvest's 18-dim vector is `BANDS` verbatim (verified empirically: VV/VH in
dB, S2 at x1e4 reflectance, temperature in K, elevation in m, NDVI last), so the
only transformation Presto needs is dropping B9 -- `NORMED_BANDS = [b for b in
BANDS if b != "B9"]`, exactly as the official pipeline does.
"""
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "presto_ref"))
from single_file_presto import NUM_DYNAMIC_WORLD_CLASSES, Presto  # noqa: E402

# --- band layout (from presto_ref/s1_s2_era5_srtm.py) --------------------
BANDS = (["VV", "VH"]
         + ["B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9", "B11", "B12"]
         + ["temperature_2m", "total_precipitation", "elevation", "slope", "NDVI"])
ADD_BY = ([25.0, 25.0] + [0.0] * 11 + [-272.15, 0.0, 0.0, 0.0] + [0.0])
DIVIDE_BY = ([25.0, 25.0] + [1e4] * 11 + [35.0, 0.03, 2000.0, 50.0] + [1.0])
DROP = "B9"
NORMED_BANDS = [b for b in BANDS if b != DROP]
CROP_IDX = [BANDS.index(b) for b in NORMED_BANDS]     # 18 -> 17 selection

MODEL_KW = dict(encoder_embedding_size=128, channel_embed_ratio=0.25,
                month_embed_ratio=0.25, encoder_depth=2, mlp_ratio=4,
                encoder_num_heads=8, decoder_embedding_size=128,
                decoder_depth=2, decoder_num_heads=8, max_sequence_length=24)


def build_encoder(weights="models/presto.pth", device="cpu"):
    model = Presto.construct(**MODEL_KW)
    sd = torch.load(weights, map_location="cpu", weights_only=True)
    missing, unexpected = model.load_state_dict(sd, strict=False)
    enc_missing = [k for k in missing if k.startswith("encoder.")]
    if enc_missing:
        raise RuntimeError(f"encoder weights not loaded: {enc_missing[:5]}")
    model.eval().to(device)
    for p in model.encoder.parameters():
        p.requires_grad_(False)
    return model.encoder


def prepare(x18, add=True):
    """(N, T, 18) raw CropHarvest -> (N, T, 17) normalised in NORMED_BANDS order."""
    x = np.asarray(x18, dtype=np.float32)
    if add:
        x = (x + np.asarray(ADD_BY, dtype=np.float32)) / np.asarray(
            DIVIDE_BY, dtype=np.float32)
    return x[:, :, CROP_IDX]


@torch.no_grad()
def extract(encoder, x18, latlons, months=None, batch=256, device="cuda",
            normalize=True):
    """Frozen Presto embeddings -> (N, 128).

    x18      : (N, T, 18) CropHarvest features
    latlons  : (N, 2)
    months   : int start-month for all (Presto rolls months t..t+T-1 mod 12)
    """
    x = prepare(x18, add=normalize)
    n, T, _ = x.shape
    if months is None:
        months = 1                     # official cropharvest_eval default
    out = []
    for i in range(0, n, batch):
        xb = torch.from_numpy(x[i:i + batch]).to(device)
        lb = torch.from_numpy(np.asarray(latlons[i:i + batch],
                                         dtype=np.float32)).to(device)
        # dynamic_world is absent in CropHarvest -> index 9 is the mask slot,
        # which makes the encoder discard that token group entirely.
        dw = torch.full((xb.shape[0], T), NUM_DYNAMIC_WORLD_CLASSES,
                        dtype=torch.long, device=device)
        emb = encoder(x=xb, dynamic_world=dw, latlons=lb, mask=None,
                      month=months, eval_task=True)
        out.append(emb.float().cpu().numpy())
    return np.concatenate(out, axis=0)


if __name__ == "__main__":
    import time
    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    import json
    meta = json.load(open("data/meta_cropharvest.json"))
    latlons = np.array([[m["lat"] or 0.0, m["lon"] or 0.0] for m in meta
                        if m.get("crop_type") not in (None, "non_crop")],
                       dtype=np.float32)
    print("features:", d["X"].shape, " coords:", latlons.shape)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    enc = build_encoder(device=dev)
    n_params = sum(p.numel() for p in enc.parameters())
    print(f"presto encoder loaded on {dev}, {n_params/1e6:.2f}M params")
    t0 = time.time()
    E = extract(enc, d["X"][:512], latlons[:512], device=dev)
    print(f"embeddings {E.shape} in {time.time()-t0:.1f}s")
    print("  mean", E.mean().round(4), " std", E.std().round(4))
    assert not np.isnan(E).any(), "NaN in embeddings"
    print("  no NaNs")
