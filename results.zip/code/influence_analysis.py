"""Leave-one-class-out influence analysis, replacing the ad-hoc "drop the max
point" check the paper previously used.

Reviewer's point: reporting only r after removing the single highest-separability
class is a weak robustness statement, and cannot show WHICH classes drive the
relationship or whether the sign is stable. Removing every class in turn and
reporting the full distribution of r_{-c} is a standard influence analysis and
directly evidences whether a result rests on one class.

Also reports a cluster-aware view: because the per-class observations within a
region/window share samples and window structure, the effective number of
independent units is smaller than the nominal n. We report a cluster bootstrap
over CLASSES for the headline correlation, which is the relevant clustering at
the level the correlation is computed.
"""
import json
import sys
import warnings

import numpy as np
from scipy import stats

sys.path.insert(0, "code")
from breizh_exp import load  # noqa: E402


def loo(x, y):
    """Leave-one-out correlation. Returns array of r_{-c} and the full-set r."""
    n = len(x)
    rs = np.empty(n)
    for i in range(n):
        m = np.ones(n, bool); m[i] = False
        rs[i] = stats.pearsonr(x[m], y[m])[0]
    return rs, stats.pearsonr(x, y)[0]


def cluster_bootstrap(x, y, n_boot=5000, seed=0):
    """Bootstrap over the class axis (the unit the correlation is computed on)."""
    rng = np.random.default_rng(seed)
    n = len(x)
    out = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, n)
        if np.std(x[idx]) < 1e-12:
            out[b] = np.nan; continue
        out[b] = stats.pearsonr(x[idx], y[idx])[0]
    out = out[np.isfinite(out)]
    return np.percentile(out, [2.5, 97.5]), float((out > 0).mean())


def main():
    bz = json.load(open("results/breizh.json"))
    br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys])
    n = len(keep)
    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])

    def sepwin(P):
        C = len(P); o = np.full(C, np.nan)
        for c in range(C):
            b = np.inf
            for d in range(C):
                if d == c: continue
                v = ~np.isnan(P[c]) & ~np.isnan(P[d])
                if v.sum() < 2: continue
                b = min(b, np.sqrt(np.mean((P[c, v] - P[d, v]) ** 2)))
            o[c] = b if np.isfinite(b) else np.nan
        return o

    print("Leave-one-class-out influence (BreizhCrops, logreg k=20)")
    report = {}
    for W in (18, 24, 36):
        s = sepwin(prof[:, :W])
        f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                                if r["w"] == W and r["method"] == "logreg"
                                and r["k"] == 20]) for c in range(n)])
        ok = ~np.isnan(s) & ~np.isnan(f1)
        x, ff = s[ok], f1[ok]
        names = [keep[i] for i in np.where(ok)[0]]
        rs, r_full = loo(x, ff)
        # which class, when removed, moves r the most?
        worst = np.argmax(np.abs(rs - r_full))
        ci, frac_pos = cluster_bootstrap(x, ff)
        print(f"\n  w={W} (DOY {W*10})  n={len(x)}")
        print(f"    full r                = {r_full:+.3f}")
        print(f"    LOO r range           = {rs.min():+.3f} .. {rs.max():+.3f}")
        print(f"    LOO sign stability    = {int((np.sign(rs)==np.sign(r_full)).sum())}/{len(rs)} same sign")
        print(f"    most influential class= {names[worst]} (removing it -> {rs[worst]:+.3f})")
        print(f"    cluster bootstrap 95%CI of r = [{ci[0]:+.3f}, {ci[1]:+.3f}], P(r>0)={frac_pos:.3f}")
        report[f"w{W}"] = {"n": len(x), "r_full": r_full,
                           "loo_min": float(rs.min()), "loo_max": float(rs.max()),
                           "sign_stable": int((np.sign(rs) == np.sign(r_full)).sum()),
                           "ci": [float(ci[0]), float(ci[1])],
                           "p_r_gt_0": frac_pos,
                           "loo_per_class": {names[i]: float(rs[i]) for i in range(len(rs))}}
    json.dump(report, open("results/influence.json", "w"))
    print("\nsaved results/influence.json")


if __name__ == "__main__":
    main()
