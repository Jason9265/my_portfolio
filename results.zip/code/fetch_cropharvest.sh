#!/usr/bin/env bash
# Fetch CropHarvest (Zenodo 10251170). Small files first, then the 26.7GB raw EO long pole.
set -u
cd /d/rcessay/data || exit 1
Z=https://zenodo.org/api/records/10251170/files

python /d/rcessay/code/par_download.py "$Z/labels.geojson/content"      labels.geojson      16
python /d/rcessay/code/par_download.py "$Z/features.tar.gz/content"     features.tar.gz     16
python /d/rcessay/code/par_download.py "$Z/test_features.tar.gz/content" test_features.tar.gz 16
# long pole: raw Sentinel-1/2 time series, needed for learned-backbone features
python /d/rcessay/code/par_download.py "$Z/eo_data.tar.gz/content"      eo_data.tar.gz      16
echo "ALL_CROPHARVEST_DOWNLOADS_FINISHED"
