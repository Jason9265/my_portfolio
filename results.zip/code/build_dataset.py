"""Build the cached experimental dataset from CropHarvest features + labels.

Produces data/ds_cropharvest.npz with:
  X        (N, 12, 18)  float32
  y        (N,)         int64    class index into CLASSES
  region   (N,)         object   region string
  greenup  (N,)         int64    detected green-up timestep (for phenology-anchored windows)
  valid_t  (N, 12)      bool     timestep observed (NDVI present)

Task = crop-TYPE classification (9 classes, excluding non_crop).
"""
import collections
import json

import numpy as np

from regions import assign_region

CLASSES = ['beverage_spice', 'cereals', 'fruits_nuts', 'leguminous', 'oilseeds',
           'other', 'root_tuber', 'sugar', 'vegetables_melons']
NDVI_IDX = 17
T = 12


def detect_greenup(ndvi):
    """Green-up timestep per sample from a 12-step calendar-aligned NDVI curve.

    Threshold method on a circular series: baseline = 10th pct, peak = 90th pct;
    green-up = first t (searching from the calendar start) whose smoothed NDVI
    exceeds baseline + 0.35*(peak-baseline). Samples with no crossing get -1.
    Returns int array (N,).
    """
    N = ndvi.shape[0]
    out = np.full(N, -1, dtype=np.int64)
    # circular smoothing: wrap with 1 step on each side
    n_ext = np.concatenate([ndvi[:, -1:], ndvi, ndvi[:, :1]], axis=1)
    kernel = np.array([0.25, 0.5, 0.25])
    sm = np.stack([
        np.convolve(n_ext[i], kernel, mode="valid") for i in range(N)
    ])  # (N,12)

    # last valid index per sample (NDVI>0 marks observed)
    for i in range(N):
        v = sm[i]
        obs = ndvi[i] > 0.02
        if obs.sum() < 4:
            continue
        vals = v[obs]
        base, peak = np.percentile(vals, 10), np.percentile(vals, 90)
        if peak - base < 0.10:
            continue
        thr = base + 0.35 * (peak - base)
        # find first index where 3 consecutive (circularly) exceed thr
        for t in range(T):
            if all(obs[(t + d) % T] and v[(t + d) % T] > thr for d in range(3)):
                out[i] = t
                break
    return out


def main():
    X = np.load("data/X_cropharvest.npy").astype(np.float32)
    meta = json.load(open("data/meta_cropharvest.json"))
    assert len(X) == len(meta)

    keep, y, region = [], [], []
    cls_of = {c: i for i, c in enumerate(CLASSES)}
    for i, m in enumerate(meta):
        ct = m.get("crop_type")
        if ct is None or ct == "non_crop" or ct not in cls_of:
            continue
        keep.append(i)
        y.append(cls_of[ct])
        region.append(assign_region(m))

    keep = np.array(keep)
    X, y = X[keep], np.array(y, dtype=np.int64)
    region = np.array(region, dtype=object)

    greenup = detect_greenup(X[:, :, NDVI_IDX])
    valid_t = X[:, :, NDVI_IDX] > 0.02

    print(f"N = {len(X)}   classes = {len(CLASSES)}")
    print(f"green-up detected: {(greenup >= 0).sum()} / {len(X)} "
          f"({100*(greenup>=0).mean():.1f}%)")
    print("\ngreen-up timestep distribution:")
    gu = greenup[greenup >= 0]
    for t, c in sorted(collections.Counter(gu).items()):
        print(f"  t={t:2d}  {c:6d}  {'#' * int(60*c/len(gu))}")

    np.savez_compressed("data/ds_cropharvest.npz", X=X, y=y,
                        region=region, greenup=greenup, valid_t=valid_t,
                        classes=np.array(CLASSES))
    print("\nsaved data/ds_cropharvest.npz")


if __name__ == "__main__":
    main()
