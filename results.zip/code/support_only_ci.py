"""Paired uncertainty for the support-only vs oracle separability comparison.

The fifth-round review's Remaining Comment 2: §4.4.5b reports mean r, positive
counts and a retention ratio, but no uncertainty. To support any threshold-style
claim ("k>=20 approaches oracle") the paired difference

    dr = r_support - r_oracle

needs a CI. The runs are paired (same window, region, seed, classifier), so the
difference is computed within run and bootstrapped across runs.

Also reports the retention ratio r_support / r_oracle with a CI, since that is
what the paper currently quotes.

Outputs results/support_only_ci.json.
"""
import argparse
import collections
import io
import json
import os

import numpy as np
from scipy import stats


def pearson_ok(sep, f1):
    sep = np.asarray(sep, float)
    f1 = np.asarray(f1, float)
    ok = np.isfinite(sep) & np.isfinite(f1) & (f1 > 0)
    if ok.sum() < 6 or np.std(sep[ok]) < 1e-12 or np.std(f1[ok]) < 1e-12:
        return np.nan
    return float(stats.pearsonr(sep[ok], f1[ok])[0])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp",
                    default="results/separability_controls.json")
    ap.add_argument("--reps", type=int, default=10000)
    ap.add_argument("--out", default="results/support_only_ci.json")
    a = ap.parse_args()

    recs = json.load(open(a.inp))
    rng = np.random.default_rng(20260927)

    by = collections.defaultdict(list)
    for r in recs:
        f1 = r["models"]["full"]["per_class_f1"]      # the paper's readout
        ro = pearson_ok(r["sep_oracle"], f1)
        rs = pearson_ok(r["sep_support"], f1)
        by[(r["w"], r["k"])].append((ro, rs))

    rows = []
    print(f"{'w':>3s} {'k':>3s} {'n':>4s} {'r_oracle':>9s} {'r_support':>10s} "
          f"{'dr':>8s} {'dr 95% CI':>20s} {'retention':>10s} {'ret 95% CI':>18s}")
    for (w, k) in sorted(by):
        arr = np.array([x for x in by[(w, k)] if np.isfinite(x[0]) and np.isfinite(x[1])])
        if len(arr) < 5:
            continue
        ro, rs = arr[:, 0], arr[:, 1]
        dr = rs - ro
        # paired bootstrap over runs
        idx = rng.integers(0, len(dr), size=(a.reps, len(dr)))
        bdr = dr[idx].mean(1)
        ret = rs / np.where(np.abs(ro) < 1e-9, np.nan, ro)
        bret = np.nanmean(ret[idx], axis=1)
        dlo, dhi = np.percentile(bdr, [2.5, 97.5])
        rlo, rhi = np.nanpercentile(bret, [2.5, 97.5])
        print(f"{w:3d} {k:3d} {len(arr):4d} {ro.mean():+9.3f} {rs.mean():+10.3f} "
              f"{dr.mean():+8.3f} [{dlo:+.3f},{dhi:+.3f}]".ljust(60)
              + f" {np.nanmean(ret):9.0%} [{rlo:.0%},{rhi:.0%}]")
        rows.append({"w": w, "k": k, "n": int(len(arr)),
                     "r_oracle": float(ro.mean()), "r_support": float(rs.mean()),
                     "dr": float(dr.mean()), "dr_lo": float(dlo), "dr_hi": float(dhi),
                     "retention": float(np.nanmean(ret)),
                     "ret_lo": float(rlo), "ret_hi": float(rhi),
                     "dr_positive_share": float((dr > 0).mean())})

    # is k=20 distinguishable from k=5/10?
    print("\n=== pairwise k comparison within (w) : dr = r_support - r_oracle ===")
    for w in sorted({r["w"] for r in rows}):
        sub = {r["k"]: r for r in rows if r["w"] == w}
        if 20 in sub and 5 in sub:
            gap = sub[20]["dr"] - sub[5]["dr"]
            print(f"  w={w}: mean dr  k=20 {sub[20]['dr']:+.3f} vs k=5 {sub[5]['dr']:+.3f}"
                  f"  (difference {gap:+.3f}; k=20 CIs do not overlap k=5:"
                  f" {sub[20]['dr_lo'] > sub[5]['dr_hi']})")

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"reps": a.reps, "cells": rows}, open(a.out, "w"), indent=1)
    print(f"\nsaved {a.out}")


if __name__ == "__main__":
    main()
