"""Fig. 1 -- the conceptual figure the reviewer asked for.

One page that carries the whole argument:

  A  Timing view      -- the intuition everyone defaults to: a crop that greens
                         up later is harder early in the season. FALSIFIED (§4.3).
  B  Geometry view    -- the replacement: difficulty is how close a class sits to
                         its nearest competitor *inside the window*. The maize
                         counterexample is the reason A fails (§4.4).
  C  Boundary         -- the relationship decays under severe class imbalance,
                         and the decay has two separable causes (§4.5).

A and B are SCHEMATIC (illustrative NDVI shapes, no data). C re-plots the
dose-response of §4.5.2 at DOY 240 under the same palette as Fig. 5; the full
four-arm version, with the test/support decomposition, is Fig. 5.
"""
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import sys
sys.path.insert(0, "code")
from figures import AXIS, CAT3, GRID, INK, INK2, MUTED, SURFACE   # noqa: E402

W_CUT = 120.0          # the w=12 observation window, in DOY
HALO = dict(facecolor=SURFACE, edgecolor="none", pad=1.0)


def _clean(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_axisbelow(True)
    ax.grid(True, alpha=1.0, zorder=0, color=GRID)


def panel_a(ax):
    """The intuition, and its refutation."""
    _clean(ax)
    ax.grid(False, axis="x")
    doy = np.linspace(0, 365, 500)

    def seasonal(peak, width, lo, hi):
        return lo + (hi - lo) * np.exp(-((doy - peak) ** 2) / (2.0 * width ** 2))

    # (peak, width, lo, hi, colour, label, label-y-offset in points)
    crops = [(105, 26, 0.10, 0.80, CAT3[0], "winter cereal", 7),
             (150, 30, 0.12, 0.78, CAT3[2], "grassland", 20),
             (235, 24, 0.08, 0.84, CAT3[1], "maize", 7)]
    for peak, wid, lo, hi, col, lab, dy in crops:
        y = seasonal(peak, wid, lo, hi)
        ax.plot(doy, y, color=col, lw=2.2, zorder=3)
        ax.scatter([peak], [hi], s=26, color=col, zorder=4,
                   edgecolor=SURFACE, linewidth=1.4)
        ax.annotate(lab, (peak, hi), textcoords="offset points", xytext=(0, dy),
                    ha="center", fontsize=7.0, color=INK2)

    ax.axvspan(0, W_CUT, color=GRID, alpha=0.8, zorder=1)
    ax.annotate("window $w{=}12$", (62, 0.90), fontsize=7.2, color=MUTED,
                ha="center", bbox=HALO)

    # The assumed ordering, stated across the top where nothing overlaps it.
    ax.annotate("", xy=(300, 1.14), xytext=(45, 1.14),
                arrowprops=dict(arrowstyle="-|>", color=INK2, lw=1.5))
    ax.annotate("assumed:  later green-up  ⇒  harder", (172, 1.18),
                fontsize=8.2, color=INK2, ha="center", style="italic")

    ax.set_xlim(0, 330)
    ax.set_ylim(0, 1.30)
    ax.set_xticks([0, 120, 240])
    ax.set_xticklabels(["0", "120", "240"])
    ax.set_yticks([])
    ax.set_xlabel("day of year", fontsize=8.5)
    ax.set_title("A  Timing view — the intuition", fontsize=9.5, color=INK,
                 loc="left", pad=6)

    ax.annotate("not supported  (§4.3)\n"
                r"peak DOY vs per-class $F_1$:  $r = +0.09$, n.s.",
                (0.0, -0.26), xycoords="axes fraction", ha="left", va="top",
                fontsize=8.0, color=CAT3[1], fontweight="bold")


def panel_b(ax):
    """The replacement, with the maize counterexample."""
    _clean(ax)
    ax.grid(False)
    d = np.linspace(0, W_CUT, 300)

    def seg(lo, hi):
        return lo + (hi - lo) * (1.0 - np.exp(-d / 42.0))

    # maize is the LOW curve; the two winter cereals are the HIGH pair, and they
    # sit close to each other -- that pair is what makes them hard to separate.
    maize, cereal_b, cereal_a = seg(0.10, 0.20), seg(0.16, 0.575), seg(0.14, 0.715)
    ax.plot(d, cereal_a, color=CAT3[0], lw=2.4, zorder=4)
    ax.plot(d, cereal_b, color=CAT3[0], lw=2.4, zorder=4, ls="--")
    ax.plot(d, maize, color=CAT3[1], lw=2.4, zorder=4)

    # direct labels sit on the curves, so no two can collide
    ax.annotate("maize (bare soil)", (52, 0.208), fontsize=7.2, color=CAT3[1],
                bbox=HALO, zorder=6)
    ax.annotate("winter cereal A", (74, 0.500), fontsize=7.2, color=INK2,
                bbox=HALO, zorder=6)
    ax.annotate("winter cereal B", (86, 0.735), fontsize=7.2, color=INK2,
                bbox=HALO, zorder=6)

    # A's nearest competitor is B -> close;  maize's nearest is B -> far.
    def bracket(x, y0, y1):
        ax.annotate("", xy=(x, y1), xytext=(x, y0),
                    arrowprops=dict(arrowstyle="<->", color=INK2, lw=1.5),
                    zorder=5)

    bracket(110, 0.575, 0.715)
    ax.annotate("nearest competitor\nis close  →  hard",
                (106, 0.645), fontsize=7.4, color=INK2, ha="right", va="center",
                bbox=HALO, zorder=6)
    bracket(94, 0.200, 0.575)
    ax.annotate("nearest competitor\nis far  →  easy",
                (90, 0.385), fontsize=7.4, color=INK2, ha="right", va="center",
                bbox=HALO, zorder=6)

    ax.set_xlim(0, W_CUT)
    ax.set_ylim(0, 0.92)
    ax.set_xticks([0, 40, 80, 120])
    ax.set_yticks([])
    ax.set_xlabel("day of year (inside the window)", fontsize=8.5)
    ax.set_title("B  Relative-geometry view — the replacement",
                 fontsize=9.5, color=INK, loc="left", pad=6)

    # inside the axes: the whole strip above y=0.8 is clear of every curve
    ax.annotate("difficulty  ∝  1 / (distance to nearest competing class)",
                (6, 0.86), fontsize=8.0, color=INK, style="italic",
                va="center", ha="left")
    ax.annotate("maize peaks LATEST yet is among the EASIEST:\n"
                "bare soil against a closed canopy is itself a signal",
                (0.0, -0.26), xycoords="axes fraction", ha="left", va="top",
                fontsize=7.8, color=INK2)


def panel_c(ax):
    """Where the relationship stops holding."""
    _clean(ax)
    rho = np.array([1, 5, 10, 50, 100], float)
    balanced = np.array([0.517, 0.555, 0.546, 0.528, 0.533])
    support = np.array([0.517, 0.487, 0.383, 0.486, 0.408])
    test = np.array([0.517, 0.502, 0.462, 0.358, 0.356])

    # The two mechanisms are NOT equally identified (see §4.5.4), so they are
    # not drawn with equal weight: test-skew is directly verified by the
    # frozen-classifier experiment (solid); support-skew's own effect on this
    # correlation depends on the class->budget ordering (dashed, faded).
    for ys, col, lab, ls, al in ((balanced, CAT3[0], "balanced (placebo)", "-", 1.0),
                                 (test, CAT3[1], "test-skew (directly verified)", "-", 1.0),
                                 (support, CAT3[2], "support-skew (ordering-dependent)",
                                  (0, (4, 2)), 0.55)):
        ax.plot(rho, ys, color=col, lw=2.2, marker="o", ms=6, mfc=col,
                mec=SURFACE, mew=1.6, zorder=4, label=lab, ls=ls, alpha=al)

    ax.axhline(0, color=AXIS, lw=1.2, zorder=2)
    ax.set_xscale("log")
    ax.set_xticks(rho)
    ax.set_xticklabels([str(int(r)) for r in rho])
    ax.set_xlabel(r"imbalance ratio $\rho$", fontsize=8.5)
    ax.set_ylabel("separability–$F_1$ correlation", fontsize=8.5)
    ax.set_ylim(-0.03, 0.70)
    ax.legend(fontsize=7.0, loc="lower left", labelspacing=0.25)
    ax.set_title("C  Boundary — and how well each mechanism is identified",
                 fontsize=9.5, color=INK, loc="left", pad=6)

    ax.annotate("test-skew — accuracy barely moves while the correlation falls\n"
                r"(0.35 $\to$ 0.29): an artifact, DIRECTLY verified by the"
                "\nfrozen-classifier experiment",
                (0.0, -0.26), xycoords="axes fraction", ha="left", va="top",
                fontsize=7.4, color=CAT3[1])
    ax.annotate("support-skew — classes genuinely fail to learn\n"
                r"(macro-$F_1$ 0.35 $\to$ 0.11, robust); its effect on the"
                "\ncorrelation depends on the class-to-budget ordering",
                (0.0, -0.50), xycoords="axes fraction", ha="left", va="top",
                fontsize=7.4, color=CAT3[2])


def main():
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        fig, axs = plt.subplots(1, 3, figsize=(13.2, 4.1))
        panel_a(axs[0])
        panel_b(axs[1])
        panel_c(axs[2])
        fig.tight_layout()
        fig.savefig("figs/fig1_concept.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig1_concept.png")


if __name__ == "__main__":
    main()
