"""Fig. 3 -- the central evidence, across datasets and conditions.

A forest-style summary of the separability -> per-class-performance correlation,
with its leave-one-class-out range. This is the honest way to present the paper's
main claim: it shows (a) the effect is reliably positive where the class space is
workable, and (b) it collapses on EuroCropsML in its natural imbalanced state --
so the reader sees the boundary condition in the same figure as the effect.

Every statistic is computed from the saved run files; nothing is re-estimated by
eye. Drop-one-out ranges come from the same leave-one-class-out procedure used in
the text.
"""
import collections
import json
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

from figures import AXIS, GRID, INK, INK2, MUTED, SURFACE

CAT4 = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]


def loo_range(x, y):
    """Leave-one-out correlations -> (min, max)."""
    n = len(x)
    rs = []
    for i in range(n):
        m = np.ones(n, bool); m[i] = False
        if np.std(x[m]) < 1e-12:
            continue
        rs.append(stats.pearsonr(x[m], y[m])[0])
    rs = np.array(rs)
    return float(rs.min()), float(rs.max()), float(stats.pearsonr(x, y)[0]), n


def main():
    rows = []          # (label, r, lo, hi, n, colour, note)

    # ---- BreizhCrops: NDVI-trajectory separability -> per-class F1
    import sys
    sys.path.insert(0, "code")
    from breizh_exp import load
    bz = json.load(open("results/breizh.json")); br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys]); n = len(keep)
    nd = X[:, :, X.shape[2] - 1].copy(); nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])
    for W in (18, 24, 36):
        P = prof[:, :W]; C = len(P); sep = np.full(C, np.nan)
        for c in range(C):
            b = np.inf
            for d in range(C):
                if d == c: continue
                v = ~np.isnan(P[c]) & ~np.isnan(P[d])
                if v.sum() < 2: continue
                b = min(b, np.sqrt(np.mean((P[c, v] - P[d, v]) ** 2)))
            sep[c] = b if np.isfinite(b) else np.nan
        f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                                if r["w"] == W and r["method"] == "logreg"
                                and r["k"] == 20]) for c in range(n)])
        ok = np.isfinite(sep) & np.isfinite(f1) & (f1 > 0)
        lo, hi, r, nn = loo_range(sep[ok], f1[ok])
        rows.append((f"BreizhCrops (DOY {W*10})", r, lo, hi, nn, CAT4[0], ""))

    # ---- CropHarvest: per-sample accuracy across the 30 region x window cells
    from sep_replication import class_profiles, separability
    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    Xc, yc, reg = d["X"], d["y"], d["region"]; nc = len(d["classes"])
    ps = json.load(open("results/per_sample.json"))
    by = collections.defaultdict(list)
    for rr in ps:
        by[(rr["region"], rr["w"])].append(rr)
    allr = []
    for (rg, w), v in sorted(by.items()):
        cl = np.array([x["cls"] for x in v]); ac = np.array([x["acc"] for x in v])
        prof2 = class_profiles(Xc[reg == rg], yc[reg == rg], w, nc)
        s = separability(prof2)
        pa = np.array([ac[cl == c].mean() if (cl == c).sum() >= 10 else np.nan
                       for c in range(nc)])
        ok = ~np.isnan(s) & ~np.isnan(pa)
        if ok.sum() < 6:
            continue
        allr.append(stats.pearsonr(s[ok], pa[ok])[0])
    allr = np.array(allr)
    rows.append((f"CropHarvest ({len(allr)} cells)", float(allr.mean()),
                 float(np.percentile(allr, 5)), float(np.percentile(allr, 95)),
                 len(allr), CAT4[0], "cell-level, not class-level"))

    # ---- EuroCropsML, natural state (the failure) and balanced state
    ej = json.load(open("results/eurocropsml.json"))
    er = [r for r in ej["runs"] if r["w"] == 240 and r["k"] == 20
          and r["method"] == "logreg"]
    if er:
        per = np.array(er[0]["per_class_f1"])
        sep = np.array([np.nan if x is None else x for x in er[0]["sep"]],
                       dtype=float)
        ok = np.isfinite(sep) & (per > 0)
        lo, hi, r, nn = loo_range(sep[ok], per[ok])
        rows.append((f"EuroCropsML, natural ({nn} cls)", r, lo, hi, nn,
                     CAT4[1], "one class drives it"))

    # The balanced arm of the §4.5 fixed-24-class intervention (W=240, all rho).
    # This replaces the earlier test-side balancing run, whose causal reading
    # §4.5 retracts -- the boundary row must rest on the controlled design.
    ei = json.load(open("results/eurocropsml_imbalance.json"))
    bal = np.array([x["drop1"] for x in ei
                    if x["W"] == 240 and x["arm"] == "balanced"])
    rows.append((f"EuroCropsML, balanced 24-class set ({len(bal)} runs)",
                 float(bal.mean()),
                 float(np.percentile(bal, 5)), float(np.percentile(bal, 95)),
                 len(bal), CAT4[2], "fixed class set, placebo arm"))

    # ---------------- plot ----------------
    fig, ax = plt.subplots(figsize=(8.2, 4.4))
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, axis="x", alpha=1.0, zorder=0, color=GRID)
    ax.set_axisbelow(True)
    ax.tick_params(labelsize=8)

    ypos = np.arange(len(rows))[::-1]
    for yp, (lab, r, lo, hi, nn, col, note) in zip(ypos, rows):
        ax.plot([lo, hi], [yp, yp], color=col, lw=2.4, alpha=0.55, zorder=2)
        ax.scatter([r], [yp], s=95, color=col, edgecolor=SURFACE,
                   linewidth=2, zorder=4)
        txt = f"{r:+.2f}"
        ax.annotate(txt, (r, yp), textcoords="offset points", xytext=(0, 11),
                    ha="center", fontsize=7.6, color=INK2)
    ax.axvline(0, color=AXIS, lw=1.4, zorder=1)
    ax.set_yticks(ypos)
    ax.set_yticklabels([r[0] for r in rows], fontsize=8.2)
    ax.set_xlabel("separability → per-class performance\n"
                  "point = correlation;  bar = leave-one-class-out range,\n"
                  "or 5–95 percentile across cells/runs",
                  fontsize=8.5)
    ax.set_xlim(-0.45, 1.0)
    ax.set_title("The effect holds where the class space is workable —\n"
                 "and collapses in a natural long-tailed one",
                 fontsize=10, color=INK, loc="left", pad=8)

    fig.tight_layout()
    fig.savefig("figs/fig3_forest.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig3_forest.png")
    for lab, r, lo, hi, nn, _, _ in rows:
        print(f"  {lab:36s} r={r:+.3f}  LOO [{lo:+.3f}, {hi:+.3f}]  n={nn}")


if __name__ == "__main__":
    main()
