"""Parallel, resumable HTTP downloader for Zenodo (which throttles per-connection).

Usage:  python par_download.py <url> <outfile> [n_conn]
Resumes from a .part file + .state json so long downloads survive restarts.
"""
import hashlib
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

CHUNK = 512 * 1024
UA = {"User-Agent": "Mozilla/5.0 (research data fetch)"}


def head(url, retries=6):
    """Content-Length, with the same 429 backoff as the range fetches -- the
    initial HEAD is just as rate-limitable as the data requests."""
    last = None
    for a in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA, method="HEAD")
            with urllib.request.urlopen(req, timeout=60) as r:
                return int(r.headers["Content-Length"])
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 429:
                ra = e.headers.get("Retry-After") if e.headers else None
                wait = float(ra) if (ra and ra.isdigit()) else min(30 * 2 ** a, 600)
                print(f"    [429 on HEAD, waiting {wait:.0f}s]", flush=True)
                time.sleep(wait)
            else:
                time.sleep(min(2 ** a, 30))
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(min(2 ** a, 30))
    raise RuntimeError(f"HEAD failed: {last}")


def fetch_range(url, off, end, retries=8):
    last = None
    for a in range(retries):
        try:
            req = urllib.request.Request(
                url, headers={**UA, "Range": f"bytes={off}-{end}"}
            )
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 429:
                # rate limited: honour Retry-After when present, else back off
                # hard. Hammering makes it worse, so this sleeps far longer
                # than a generic transient error.
                ra = e.headers.get("Retry-After") if e.headers else None
                wait = float(ra) if (ra and ra.isdigit()) else min(15 * 2 ** a, 300)
                time.sleep(wait)
            else:
                time.sleep(min(2 ** a * 0.5, 15))
        except Exception as e:  # noqa: BLE001 - network layer, retry all
            last = e
            time.sleep(min(2 ** a * 0.5, 15))
    raise RuntimeError(f"range {off}-{end} failed: {last}")


def md5_of(path, chunk=1 << 22):
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def download(url, out, n_conn=16, expect_md5=None):
    total = head(url)
    part = f"{out}.part"
    state_f = f"{out}.state.json"

    if os.path.exists(out) and os.path.getsize(out) == total:
        print(f"[skip] {out} already complete ({total} bytes)")
        return True

    done = set()
    if os.path.exists(state_f) and os.path.exists(part):
        try:
            done = set(json.load(open(state_f))["done"])
        except Exception:  # noqa: BLE001
            done = set()

    n_chunks = (total + CHUNK - 1) // CHUNK
    pending = [i for i in range(n_chunks) if i not in done]
    print(f"[start] {out}  {total/1e6:.1f} MB  {n_chunks} chunks  "
          f"({len(done)} already done, {len(pending)} to go)  conns={n_conn}")

    lock = threading.Lock()
    idx = {"i": 0}
    written = {"n": 0}
    attempts = {}
    failed = []
    t0 = time.time()

    def worker():
        f = open(part, "r+b")
        while True:
            with lock:
                if idx["i"] >= len(pending):
                    break
                ci = pending[idx["i"]]
                idx["i"] += 1
            off = ci * CHUNK
            end = min(off + CHUNK - 1, total - 1)
            want = end - off + 1
            try:
                # ranges may come back short at EOF; retry until we have the span
                buf = b""
                while len(buf) < want:
                    got = fetch_range(url, off + len(buf), end)
                    if not got:
                        raise RuntimeError("empty range body")
                    buf += got
                f.seek(off)
                f.write(buf)
                f.flush()
            except Exception as e:  # noqa: BLE001 - never lose a chunk silently
                with lock:
                    attempts[ci] = attempts.get(ci, 0) + 1
                    n = attempts[ci]
                    if n <= 4:
                        pending.append(ci)  # requeue for another worker
                    else:
                        failed.append((ci, str(e)[:80]))  # left for a later resume
                if n > 4:
                    print(f"    [chunk {ci} FAILED after {n} attempts, "
                          f"left for resume] {str(e)[:60]}", flush=True)
                time.sleep(min(2 ** n, 20))
                continue
            with lock:
                done.add(ci)
                written["n"] += len(buf)
                if len(done) % 40 == 0:
                    json.dump({"done": sorted(done)}, open(state_f, "w"))
                    el = time.time() - t0
                    rate = written["n"] / max(el, 1e-9)  # bytes/s
                    left_s = (total - written["n"]) / max(rate, 1e-9)
                    print(f"    {len(done)}/{n_chunks} chunks  "
                          f"{written['n']/1e6:.0f}/{total/1e6:.0f} MB  "
                          f"{rate/1e6:.2f} MB/s  "
                          f"ETA {left_s/60:.0f} min", flush=True)
        f.close()

    # Create/extend the .part to full size WITHOUT destroying existing bytes.
    # Opening "wb" truncates to zero first, so a resumed run would silently wipe
    # everything already downloaded -- leaving a full-size file of nulls that
    # still passes the len(done)==n_chunks check. Use O_RDWR|O_CREAT and only
    # grow the file.
    fd = os.open(part, os.O_RDWR | os.O_CREAT)
    try:
        if os.fstat(fd).st_size < total:
            os.ftruncate(fd, total)
    finally:
        os.close(fd)

    ts = [threading.Thread(target=worker, daemon=True) for _ in range(n_conn)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()

    json.dump({"done": sorted(done)}, open(state_f, "w"))
    if len(done) == n_chunks:
        if expect_md5:
            got = md5_of(part)
            if got.lower() != expect_md5.lower():
                print(f"[CHECKSUM MISMATCH] {out}\n"
                      f"    expected {expect_md5}\n"
                      f"    got      {got}\n"
                      f"    .part kept for inspection; NOT promoted.")
                return False
            print(f"[checksum ok] md5 {got}")
        os.replace(part, out)
        os.remove(state_f)
        el = time.time() - t0
        print(f"[done] {out}  {total/1e6:.1f} MB in {el/60:.1f} min "
              f"({total/1e6/el:.2f} MB/s)")
        return True
    print(f"[incomplete] {len(done)}/{n_chunks}"
          + (f"  failed={failed}" if failed else ""))
    return False


if __name__ == "__main__":
    u, o = sys.argv[1], sys.argv[2]
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 16
    md5 = sys.argv[4] if len(sys.argv) > 4 else None
    ok = download(u, o, n, md5)
    sys.exit(0 if ok else 1)
