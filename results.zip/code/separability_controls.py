"""Two controls the review requires on the central separability construct.

MAJOR 1 -- "non-circular" is too strong. The outcome classifier is trained on
L1 temporal statistics over ALL bands, NDVI included, so the NDVI-trajectory
geometry and the classifier's decision geometry are not fully independent
information sources. This re-runs the outcome classifier with NDVI removed, and
again with NDVI + B4 + B8 removed (B4/B8 are the bands NDVI is computed from,
so dropping NDVI alone leaves it reconstructible). If NDVI-trajectory
separability still predicts the per-class F1 of a classifier that cannot see
NDVI, the claim is much stronger; if not, the paper must be relabelled
"reduced-circularity" rather than "non-circular".

MAJOR 2 -- where do the class-mean trajectories come from? The paper computes
them from ALL ground-truth samples of the test region, i.e. from the very
labels being predicted. That makes it a post-hoc explanatory construct, not an
operational predictor. This also computes support-only separability, built from
the same k support samples the classifier sees, and compares the two.

Outputs results/separability_controls.json.
"""
import argparse
import json
import os
import warnings

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from breizh_exp import build_feats, load, macro_f1
from experiment import standardize


def separability_of(prof):
    """Distance from each class-mean trajectory to its nearest competitor."""
    C = len(prof)
    sep = np.full(C, np.nan)
    for c in range(C):
        best = np.inf
        for d in range(C):
            if d == c:
                continue
            v = ~np.isnan(prof[c]) & ~np.isnan(prof[d])
            if v.sum() < 2:
                continue
            best = min(best, np.sqrt(np.mean((prof[c, v] - prof[d, v]) ** 2)))
        sep[c] = best if np.isfinite(best) else np.nan
    return sep


def drop_bands(F, B, idxs):
    """F is (N, 6*B) laid out stat-major: [mean_b0..mean_b{B-1}, std_b0..]."""
    keep = [i for i in range(F.shape[1]) if (i % B) not in idxs]
    return F[:, keep]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="18,24,36")
    ap.add_argument("--ks", default="5,10,20")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--cap", type=int, default=1500)
    ap.add_argument("--out", default="results/separability_controls.json")
    a = ap.parse_args()

    X, mask, y, region, bands, keep_cls = load(cap_per_cell=a.cap)
    cls_of = {c: i for i, c in enumerate(keep_cls)}
    y = np.array([cls_of[v] for v in y])
    regs = sorted(set(region))
    B = len(bands)
    i_ndvi = bands.index("NDVI")
    i_b4, i_b8 = bands.index("B4"), bands.index("B8")
    print(f"bands={B}  NDVI idx={i_ndvi}  B4={i_b4} B8={i_b8}  classes={len(keep_cls)}")

    nd = X[:, :, i_ndvi].copy()
    nd[~mask] = np.nan

    VARIANTS = {
        "full": [],
        "no_ndvi": [i_ndvi],
        "no_ndvi_bands": [i_ndvi, i_b4, i_b8],
    }

    out = []
    for w in [int(x) for x in a.windows.split(",")]:
        F_all = build_feats(X, mask, w)
        ndw = nd[:, :w]
        for test_r in regs:
            te = region == test_r
            tr = ~te
            for k in [int(x) for x in a.ks.split(",")]:
                for seed in range(a.seeds):
                    rng = np.random.default_rng(1000 * seed + k)
                    yte = y[te]
                    sup = np.concatenate([
                        rng.choice(np.where(yte == c)[0], k, replace=False)
                        for c in range(len(keep_cls))])
                    q = np.setdiff1d(np.arange(len(yte)), sup)

                    # --- oracle class-mean trajectory: ALL ground-truth parcels
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", RuntimeWarning)
                        prof_oracle = np.stack([
                            np.nanmean(ndw[te][yte == c], axis=0)
                            for c in range(len(keep_cls))])
                        # --- support-only: the same k parcels the classifier gets
                        prof_support = np.stack([
                            np.nanmean(ndw[te][sup][yte[sup] == c], axis=0)
                            for c in range(len(keep_cls))])
                    sep_oracle = separability_of(prof_oracle)
                    sep_support = separability_of(prof_support)

                    rec = {"w": w, "region": test_r, "k": k, "seed": seed,
                           "sep_oracle": [None if not np.isfinite(v) else float(v)
                                          for v in sep_oracle],
                           "sep_support": [None if not np.isfinite(v) else float(v)
                                           for v in sep_support],
                           "models": {}}
                    for name, drop in VARIANTS.items():
                        Fa = drop_bands(F_all, B, drop) if drop else F_all
                        Etr, Ete = standardize(Fa[tr], Fa[te])
                        clf = LogisticRegression(max_iter=1000, C=1.0, n_jobs=-1)
                        clf.fit(Ete[sup], yte[sup])
                        p = clf.predict(Ete[q])
                        mf, per = macro_f1(yte[q], p, list(range(len(keep_cls))))
                        rec["models"][name] = {
                            "macro_f1": float(mf),
                            "per_class_f1": [float(x) for x in per]}
                    out.append(rec)
                print(f"  w={w:2d} {test_r:9s} k={k:2d} done", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"))
    print(f"\nsaved {a.out}: {len(out)} records")

    # ---------------- summary ----------------
    print("\n" + "=" * 78)
    print("PAIRED correlations over (w, region, k, seed), pooled across the grid")
    print("=" * 78)
    for w in [int(x) for x in a.windows.split(",")]:
        for k in [int(x) for x in a.ks.split(",")]:
            sel = [r for r in out if r["w"] == w and r["k"] == k]
            if not sel:
                continue
            so = np.array([r["sep_oracle"] for r in sel], float)
            ss = np.array([r["sep_support"] for r in sel], float)
            print(f"\nw={w} k={k}  ({len(sel)} runs)")
            for mname in VARIANTS:
                f1 = np.array([r["models"][mname]["per_class_f1"] for r in sel])
                mf1 = np.mean([r["models"][mname]["macro_f1"] for r in sel])
                row = []
                for sname, S in (("oracle", so), ("support", ss)):
                    rs = []
                    for i in range(len(sel)):
                        ok = np.isfinite(S[i]) & np.isfinite(f1[i]) & (f1[i] > 0)
                        if ok.sum() < 6:
                            continue
                        rs.append(stats.pearsonr(S[i][ok], f1[i][ok])[0])
                    rs = np.array(rs)
                    row.append(f"{sname}: r={rs.mean():+.3f} "
                               f"pos={int((rs>0).sum())}/{len(rs)}")
                print(f"   {mname:15s} mF1={mf1:.3f} | " + " | ".join(row))


if __name__ == "__main__":
    main()
