"""Extract frozen Presto embeddings for CropHarvest, one set per observation window.

Also extracts a RANDOM-INIT control with the identical architecture. Without that
control a "frozen features work" result is unfalsifiable: if an untrained encoder
scores as well, the signal is coming from something other than the pretrained
representation (bad normalization, a leaked identifier, a degenerate readout).

Run:  python code/extract_l2.py [--windows 2,4,6,8,10,12] [--device cuda]
"""
import argparse
import copy
import json
import os
import time

import numpy as np
import torch

from presto_features import MODEL_KW, build_encoder, extract
from single_file_presto import Presto


def build_random_encoder(seed=0, device="cpu"):
    torch.manual_seed(seed)
    m = Presto.construct(**MODEL_KW)
    m.eval().to(device)
    for p in m.encoder.parameters():
        p.requires_grad_(False)
    return m.encoder


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="2,4,6,8,10,12")
    ap.add_argument("--out", default="data/l2_presto.npz")
    ap.add_argument("--device", default="cuda")
    a = ap.parse_args()
    windows = [int(x) for x in a.windows.split(",")]
    dev = a.device if torch.cuda.is_available() else "cpu"

    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    X = d["X"]
    meta = json.load(open("data/meta_cropharvest.json"))
    # meta is the unfiltered list; keep only rows that survived the crop-type filter
    keep = [m for m in meta
            if m.get("crop_type") not in (None, "non_crop")
            and m.get("crop_type") in set(d["classes"])]
    assert len(keep) == len(X), f"meta {len(keep)} vs X {len(X)}"
    latlons = np.array([[m["lat"] or 0.0, m["lon"] or 0.0] for m in keep],
                       dtype=np.float32)
    print(f"samples {X.shape}  coords {latlons.shape}  device {dev}")

    enc = build_encoder(device=dev)
    rnd = build_random_encoder(seed=0, device=dev)

    out = {}
    for w in windows:
        t0 = time.time()
        out[f"presto_w{w}"] = extract(enc, X[:, :w, :], latlons, device=dev)
        out[f"random_w{w}"] = extract(rnd, X[:, :w, :], latlons, device=dev)
        print(f"  w={w:2d}  presto+random done in {time.time()-t0:.1f}s",
              flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    np.savez_compressed(a.out, **out)
    print("saved", a.out, "keys:", sorted(out))


if __name__ == "__main__":
    main()
