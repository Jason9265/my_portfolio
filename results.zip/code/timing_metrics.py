"""H_timing with genuine phenological metrics, not just NDVI-peak DOY.

Reviewer's point (correct): the paper claims "phenological timing does not
predict difficulty" but tested only NDVI *peak* timing. Green-up onset / SOS
and peak are different events, and can even rank crops differently. A title
about phenological timing needs a family of timing metrics, not one proxy.

Metrics computed per class from its mean NDVI trajectory (BreizhCrops, 36
10-day bins with real acquisition dates):
  peak      -- DOY of maximum NDVI
  SOS       -- first DOY where NDVI rises past baseline + 20% of amplitude and
               stays above it for 2 consecutive bins (standard threshold method)
  SOS50     -- same with a 50% threshold (later, more conservative onset)
  gslope    -- green-up rate: mean NDVI gain per bin over the 3 bins following SOS
  centre    -- DOY of the trajectory's centre of mass (an integral timing measure,
               robust to which single extreme is picked)

If ALL of these fail to predict per-class F1, the claim becomes about absolute
phenological timing as a family rather than about one arbitrary proxy.
"""
import json
import sys
import warnings

import numpy as np
from scipy import stats

sys.path.insert(0, "code")
from breizh_exp import load  # noqa: E402

BIN_DOY = 10


def metrics_from_profile(prof):
    """prof: (n_bins,) mean NDVI trajectory. Returns dict of timing metrics."""
    v = np.asarray(prof, dtype=float)
    ok = ~np.isnan(v)
    if ok.sum() < 6:
        return None
    base = np.nanpercentile(v, 10)
    peakv = np.nanpercentile(v, 90)
    amp = peakv - base
    if amp < 0.05:
        return None
    peak_bin = int(np.nanargmax(v))

    out = {"peak": peak_bin * BIN_DOY + BIN_DOY // 2,
           "centre": float(np.nansum(np.arange(len(v)) * np.nan_to_num(v, nan=0.0))
                           / max(np.nansum(np.nan_to_num(v, nan=0.0)), 1e-9))
           * BIN_DOY + BIN_DOY // 2}

    for tag, frac in (("SOS", 0.20), ("SOS50", 0.50)):
        thr = base + frac * amp
        found = None
        for b in range(len(v) - 2):
            if not (ok[b] and ok[b + 1]):
                continue
            if v[b] > thr and v[b + 1] > thr:
                found = b
                break
        out[tag] = float("nan") if found is None else found * BIN_DOY + BIN_DOY // 2
        if tag == "SOS" and found is not None:
            seg = v[found:found + 4]
            out["gslope"] = float(np.nanmean(np.diff(seg))) if len(seg) > 1 else float("nan")
        elif tag == "SOS":
            out["gslope"] = float("nan")
    return out


def main():
    bz = json.load(open("results/breizh.json"))
    br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys])
    n = len(keep)

    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])

    met = {}
    for c in range(n):
        m = metrics_from_profile(prof[c])
        if m:
            met[c] = m
    print(f"metrics computed for {len(met)}/{n} classes")
    print()

    W = 24   # the window where the replace-construct is strongest
    key = f"w{W}"
    f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                            if r["w"] == W and r["method"] == "logreg"
                            and r["k"] == 20]) for c in range(n)])

    print(f"H_timing with a FAMILY of phenological metrics (BreizhCrops, w={W}, k=20)")
    print(f"{'metric':>10}{'n':>5}{'pearson r':>12}{'p':>11}{'spearman':>11}{'p':>11}")
    for name in ("peak", "SOS", "SOS50", "gslope", "centre"):
        cs = [c for c in met if np.isfinite(met[c].get(name, np.nan))
              and np.isfinite(f1[c]) and f1[c] > 0]
        if len(cs) < 6:
            print(f"{name:>10}{len(cs):5d}   too few")
            continue
        x = np.array([met[c][name] for c in cs])
        yy = np.array([f1[c] for c in cs])
        r, p = stats.pearsonr(x, yy)
        rho, pr = stats.spearmanr(x, yy)
        print(f"{name:>10}{len(cs):5d}{r:+12.3f}{p:11.3f}{rho:+11.3f}{pr:11.3f}")

    print()
    print("all-class timing values (sanity):")
    for name in ("peak", "SOS", "SOS50"):
        v = [met[c][name] for c in met if np.isfinite(met[c][name])]
        print(f"  {name:>6}: median DOY {np.median(v):.0f}  range {min(v):.0f}-{max(v):.0f}")
    json.dump({str(c): met[c] for c in met}, open("results/timing_metrics.json", "w"))


if __name__ == "__main__":
    main()
