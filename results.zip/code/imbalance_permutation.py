"""Does the §4.5 imbalance effect depend on WHICH class gets which budget?

The fifth-round review's Remaining Comment 1: §4.5 assigns the geometric budget
decay by position in the fixed class list, i.e. by ascending HCAT code. If the
codes happen to correlate with difficulty, then the observed decay of the
separability-F1 correlation under growing rho confounds

    scarcity  +  class identity

The suggested check: randomly permute the 24-class imbalance rank, repeat, and
report the mean and CI of the decay. This does exactly that, reusing the same
data, classes, features and readouts as eurocropsml_imbalance.py.

For each permutation the SAME geometric budget vector is used; only the
mapping budget -> class changes.

Outputs results/imbalance_permutation.json.
"""
import argparse
import json
import os
import warnings

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from eurocropsml_exp import BATCH, build_feats, macro_f1
from eurocropsml_noncircular import ndvi_trajectories, separability
from eurocropsml_imbalance import MIN_TEST, MIN_SUP, skewed_counts

ARMS = ("balanced", "support", "test")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--W", type=int, default=240)
    ap.add_argument("--k", type=int, default=20)
    ap.add_argument("--test-base", type=int, default=100)
    ap.add_argument("--rhos", default="1,10,100")
    ap.add_argument("--perms", type=int, default=100)
    ap.add_argument("--out", default="results/imbalance_permutation.json")
    a = ap.parse_args()

    D = np.load(a.ds, allow_pickle=True)
    n_cls = len(D["classes"])
    yt = D["test_label"]
    ys = D[f"sup{a.k}_label"]
    tst_n = np.array([(yt == c).sum() for c in range(n_cls)])
    sup_n = np.array([(ys == c).sum() for c in range(n_cls)])
    cls = [c for c in range(n_cls)
           if tst_n[c] >= max(MIN_TEST, a.test_base) and sup_n[c] >= a.k]
    C = len(cls)
    print(f"fixed class set: {C} classes")

    W = a.W
    tr = ndvi_trajectories(D["test_data"], D["test_doy"], D["test_valid"])
    nb = min(int(np.ceil(W / 10)), tr.shape[1])
    prof = np.full((n_cls, nb), np.nan)
    for c in cls:
        s = yt == c
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            prof[c] = np.nanmean(tr[s][:, :nb], axis=0)
    sep_by_cls = {c: s for c, s in zip(cls, separability(prof)[cls])}

    idx_t = {c: np.where(yt == c)[0] for c in cls}
    idx_s = {c: np.where(ys == c)[0] for c in cls}
    F_all = build_feats(D["test_data"], D["test_doy"], D["test_valid"], W)
    S_all = build_feats(D[f"sup{a.k}_data"], D[f"sup{a.k}_doy"],
                        D[f"sup{a.k}_valid"], W)
    Fsrc = build_feats(D["pretrain_data"], D["pretrain_doy"],
                       D["pretrain_valid"], W)

    def run(bud_t, bud_s, rng):
        te, sup = [], []
        for c in cls:
            te.extend(rng.choice(idx_t[c], min(bud_t[c], len(idx_t[c])),
                                 replace=False))
            sup.extend(rng.choice(idx_s[c], min(bud_s[c], len(idx_s[c])),
                                  replace=False))
        te, sup = np.array(te), np.array(sup)
        ssel = rng.choice(len(Fsrc), min(BATCH, len(Fsrc)), replace=False)
        mu = Fsrc[ssel].mean(0); sd = Fsrc[ssel].std(0) + 1e-8
        clf = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
        clf.fit(((S_all - mu) / sd)[sup], ys[sup])
        p = clf.predict(((F_all - mu) / sd)[te])
        _, per = macro_f1(yt[te], p, list(range(n_cls)))
        per = np.array(per)[cls]
        sep = np.array([sep_by_cls[c] for c in cls])
        ok = np.isfinite(sep) & np.isfinite(per) & (per > 0)
        r, _ = stats.pearsonr(sep[ok], per[ok])
        o = np.argsort(-sep[ok])[1:]          # drop the largest, within the ok subset
        r2, _ = stats.pearsonr(sep[ok][o], per[ok][o])
        return float(r), float(r2), float(np.mean(per))

    rhos = [int(x) for x in a.rhos.split(",")]
    recs = []
    base_budgets = {rho: skewed_counts(C, rho, a.test_base) for rho in rhos}
    base_sup = {rho: skewed_counts(C, rho, a.k) for rho in rhos}

    for rho in rhos:
        for arm in ARMS:
            # fixed (current) ordering for reference
            bt = base_budgets[rho] if arm in ("test",) else np.full(C, a.test_base)
            bs = base_sup[rho] if arm == "support" else np.full(C, a.k)
            if arm == "balanced":
                bt, bs = np.full(C, a.test_base), np.full(C, a.k)
            rng = np.random.default_rng(4242)
            r, r2, mf = run(dict(zip(cls, bt)), dict(zip(cls, bs)), rng)
            recs.append({"rho": rho, "arm": arm, "perm": -1,
                         "r": r, "drop1": r2, "macro_f1": mf})
            # permuted orderings
            for i in range(a.perms):
                rng = np.random.default_rng(90000 + i)
                perm = rng.permutation(C)
                bt_p = np.empty(C, int); bs_p = np.empty(C, int)
                bt_p[perm] = bt
                bs_p[perm] = bs
                r, r2, mf = run(dict(zip(cls, bt_p)), dict(zip(cls, bs_p)), rng)
                recs.append({"rho": rho, "arm": arm, "perm": i,
                             "r": r, "drop1": r2, "macro_f1": mf})
            print(f"  rho={rho:3d} {arm:9s} done "
                  f"({a.perms} permutations)", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(recs, open(a.out, "w"), indent=1)
    print(f"\nsaved {a.out}: {len(recs)} records")

    print("\n" + "=" * 86)
    print("permuted-rank distributions (fixed ordering shown for reference)")
    print("=" * 86)
    for rho in rhos:
        print(f"\nrho={rho}")
        for arm in ARMS:
            per = [x for x in recs if x["rho"] == rho and x["arm"] == arm
                   and x["perm"] >= 0]
            fix = [x for x in recs if x["rho"] == rho and x["arm"] == arm
                   and x["perm"] == -1][0]
            d1 = np.array([x["drop1"] for x in per])
            mf = np.array([x["macro_f1"] for x in per])
            print(f"  {arm:9s} fixed drop1={fix['drop1']:+.3f} mF1={fix['macro_f1']:.3f}"
                  f" | permuted drop1 mean={d1.mean():+.3f} "
                  f"[{np.percentile(d1, 2.5):+.3f},{np.percentile(d1, 97.5):+.3f}]"
                  f"  mF1 mean={mf.mean():.3f} "
                  f"[{np.percentile(mf, 2.5):.3f},{np.percentile(mf, 97.5):.3f}]")

    print("\n=== does the fixed ordering sit outside the permuted distribution? ===")
    for rho in rhos:
        for arm in ARMS:
            per = [x for x in recs if x["rho"] == rho and x["arm"] == arm
                   and x["perm"] >= 0]
            fix = [x for x in recs if x["rho"] == rho and x["arm"] == arm
                   and x["perm"] == -1][0]
            d1 = np.array([x["drop1"] for x in per])
            pct = float((d1 <= fix["drop1"]).mean())
            print(f"  rho={rho:3d} {arm:9s} fixed drop1 percentile = {pct*100:5.1f}%")


if __name__ == "__main__":
    main()
