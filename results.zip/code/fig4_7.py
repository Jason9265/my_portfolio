"""Fig. 4 (long tail + influence) and Fig. 7 (Presto vs random effect size).

Fig. 4 shows WHY EuroCropsML fails in its natural state: per-class test
population predicts per-class F1 far better than separability does. The influence
panel shows that no single class rescues the separability relationship there.

Fig. 7 is the secondary representation analysis: the pretraining advantage over a
randomly initialised encoder of identical architecture, on pre-aggregated vs raw
inputs. The falsified prediction is visible as the narrower bar.
"""
import collections
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

from figures import AXIS, GRID, INK, INK2, MUTED, SURFACE

CAT4 = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]


def _clean(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, alpha=1.0, zorder=0, color=GRID)
    ax.set_axisbelow(True)
    ax.tick_params(labelsize=8)


def fig4():
    J = json.load(open("results/eurocropsml.json"))
    DS = np.load("data/ds_eurocropsml.npz", allow_pickle=True)
    n_cls = len(DS["classes"])
    yt = DS["test_label"]
    tst = np.array([(yt == c).sum() for c in range(n_cls)], dtype=float)

    rs = [r for r in J["runs"] if r["w"] == 240 and r["k"] == 20
          and r["method"] == "logreg"][0]
    per = np.array(rs["per_class_f1"])
    sep = np.array([np.nan if x is None else x for x in rs["sep"]], dtype=float)
    ok = np.isfinite(sep) & (per > 0)

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(13.0, 4.0))
    for ax in (ax1, ax2, ax3):
        _clean(ax)

    # A: test population vs F1
    ax1.scatter(tst[ok], per[ok], s=54, color=CAT4[1], edgecolor=SURFACE,
                linewidth=1.6, zorder=3)
    ax1.set_xscale("log")
    rho, prho = stats.spearmanr(tst[ok], per[ok])
    ax1.annotate(f"Spearman ρ = {rho:+.2f}\n(p = {prho:.1e})", (0.04, 0.94),
                 xycoords="axes fraction", fontsize=8, color=INK2, va="top")
    ax1.set_xlabel("test parcels in the class", fontsize=8.5)
    ax1.set_ylabel("per-class $F_1$", fontsize=8.5)
    ax1.set_title("A  what actually predicts difficulty\n     in the long-tailed state",
                  fontsize=9, color=INK, loc="left", pad=6)

    # B: separability vs F1 (same classes)
    ax2.scatter(sep[ok], per[ok], s=54, color=CAT4[1], edgecolor=SURFACE,
                linewidth=1.6, zorder=3)
    r, p = stats.pearsonr(sep[ok], per[ok])
    rho2, pr2 = stats.spearmanr(sep[ok], per[ok])
    ax2.annotate(f"Pearson r = {r:+.2f} (p = {p:.2f})\nSpearman ρ = {rho2:+.2f} (n.s.)",
                 (0.04, 0.94), xycoords="axes fraction", fontsize=8,
                 color=INK2, va="top")
    ax2.set_xlabel("separability", fontsize=8.5)
    ax2.set_title("B  separability, for the same classes", fontsize=9,
                  color=INK, loc="left", pad=6)

    # C: Pearson vs Spearman across cells -- the actual finding is that the
    # rank correlation is null while Pearson stays positive, i.e. the apparent
    # association is not monotone. (The leave-one-class-out range stays positive
    # in 31/32 cases, so it is NOT single-class-driven -- an earlier draft of
    # this figure said it was, and that was wrong.)
    cells = []
    for w in (180, 240, 300, 365):
        for k in (1, 20):
            rr = [x for x in J["runs"] if x["w"] == w and x["k"] == k
                  and x["method"] == "logreg"]
            if not rr:
                continue
            pp = np.array(rr[0]["per_class_f1"])
            ss = np.array([np.nan if v is None else v for v in rr[0]["sep"]],
                          dtype=float)
            o = np.isfinite(ss) & (pp > 0)
            if o.sum() < 6:
                continue
            cells.append((f"DOY {w}\nk={k}",
                          stats.pearsonr(ss[o], pp[o])[0],
                          stats.spearmanr(ss[o], pp[o])[0]))
    xs = np.arange(len(cells)); h = 0.38
    ax3.bar(xs - h / 2, [c[1] for c in cells], width=h, color=CAT4[1],
            zorder=3, label="Pearson $r$")
    ax3.bar(xs + h / 2, [c[2] for c in cells], width=h, color=CAT4[0],
            zorder=3, label=r"Spearman $\rho$ (rank)")
    ax3.axhline(0, color=AXIS, lw=1.4, zorder=4)
    ax3.set_xticks(xs)
    ax3.set_xticklabels([c[0] for c in cells], fontsize=6.6)
    ax3.set_ylabel("correlation with per-class $F_1$", fontsize=8.5)
    ax3.set_title("C  Pearson is positive,\n     but the RANK correlation is null",
                  fontsize=9, color=INK, loc="left", pad=6)
    ax3.legend(fontsize=7.2, loc="upper right", labelspacing=0.3)
    ax3.grid(True, axis="y", alpha=1.0, zorder=0, color=GRID)
    ax3.grid(False, axis="x")

    fig.tight_layout()
    fig.savefig("figs/fig4_longtail.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig4_longtail.png")
    print(f"  test-size vs F1: rho={rho:+.3f} p={prho:.1e}")
    print(f"  separability   : r={r:+.3f} p={p:.3f}  rho={rho2:+.3f} p={pr2:.3f}")
    print(f"  LOO: {int((loo<0).sum())}/{len(loo)} negative, range "
          f"[{loo.min():+.3f}, {loo.max():+.3f}]")


def fig7():
    fig, ax = plt.subplots(figsize=(6.6, 3.6))
    _clean(ax)
    ax.grid(False, axis="x")
    ax.grid(True, axis="y", alpha=1.0, zorder=0, color=GRID)

    bars = []
    for lab, path in (("pre-aggregated\n(18 dims)", "results/l2.json"),
                      ("raw time series\n(S1/S2)", "results/l2b.json")):
        R = json.load(open(path))
        p = np.mean([x["macro_f1"] for x in R if x["family"] == "presto"
                     and x["method"] == "logreg"])
        q = np.mean([x["macro_f1"] for x in R if x["family"] == "random"
                     and x["method"] == "logreg"])
        bars.append((lab, q, p - q))

    ypos = np.arange(len(bars))[::-1]
    for yp, (lab, base, delta) in zip(ypos, bars):
        ax.barh(yp, base, height=0.5, color=CAT4[0], zorder=3,
                label="random-init encoder" if yp == ypos[0] else None)
        ax.barh(yp, delta, left=base, height=0.5, color=CAT4[1], zorder=3,
                label="advantage from pretraining" if yp == ypos[0] else None)
        ax.annotate(f"+{delta:.3f}", (base + delta, yp),
                    textcoords="offset points", xytext=(5, 0), fontsize=8.5,
                    color=INK2, va="center")
    ax.set_yticks(ypos)
    ax.set_yticklabels([b[0] for b in bars], fontsize=8.5)
    ax.set_xlabel("macro-$F_1$ (logreg, all $w$ and $k$)", fontsize=8.5)
    ax.set_xlim(0, 0.42)
    ax.legend(fontsize=7.6, loc="lower right", labelspacing=0.3)
    ax.set_title("Pretraining helps LESS on raw time series —\n"
                 "the opposite of what we predicted",
                 fontsize=9.5, color=INK, loc="left", pad=6)
    fig.tight_layout()
    fig.savefig("figs/fig7_presto.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig7_presto.png")
    for lab, base, d in bars:
        print(f"  {lab.replace(chr(10),' '):34s} random={base:.3f} delta={d:+.3f}")


if __name__ == "__main__":
    fig4()
    fig7()
