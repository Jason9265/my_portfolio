"""Two robustness checks the review asked for that the paper did not yet run.

  (1) FDR correction across the families of correlation tests. The review's
      point is that several tests are reported per table without any
      multiplicity control, so a "significant" window may be one of many.
      Benjamini-Hochberg over each family, reported as q-values.

  (2) Leave-one-region-out for CropHarvest. cluster_inference.py already tests
      the regional means as the independent unit; LORO asks the complementary
      question -- is the regional result carried by any single region? For
      n=6 that is the difference between "5/5 positive" and "still positive
      without canada".

Writes results/robustness_extras.json.
"""
import collections
import json
import sys
import warnings

import numpy as np
from scipy import stats

sys.path.insert(0, "code")

ALPHA = 0.05


def bh(pvals):
    """Benjamini-Hochberg q-values, order preserved."""
    p = np.asarray(pvals, float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order] * n / (np.arange(n) + 1.0)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]   # enforce monotone
    q = np.empty(n)
    q[order] = np.clip(ranked, 0.0, 1.0)
    return q


def timing_family_fdr():
    fam = json.load(open("results/timing_family.json"))
    labels, ps = [], []
    for rec in fam:
        for stat_key, p_key in (("pearson", "p"), ("spearman", "p_spearman"),
                                ("drop1", "p_drop1")):
            labels.append(f"{rec['metric']}:{stat_key}")
            ps.append(rec[p_key])
    q = bh(ps)
    return labels, np.array(ps), q


def breizh_windows_fdr():
    """Separability -> per-class F1 at each BreizhCrops window."""
    from breizh_exp import load
    bz = json.load(open("results/breizh.json"))
    br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys])
    n = len(keep)
    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])

    rows = []
    for W in (12, 18, 24, 36):
        P = prof[:, :W]
        C = len(P)
        sep = np.full(C, np.nan)
        for c in range(C):
            best = np.inf
            for d in range(C):
                if d == c:
                    continue
                v = ~np.isnan(P[c]) & ~np.isnan(P[d])
                if v.sum() < 2:
                    continue
                best = min(best, np.sqrt(np.mean((P[c, v] - P[d, v]) ** 2)))
            sep[c] = best if np.isfinite(best) else np.nan
        f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                                if r["w"] == W and r["method"] == "logreg"
                                and r["k"] == 20]) for c in range(n)])
        ok = np.isfinite(sep) & np.isfinite(f1) & (f1 > 0)
        r, p = stats.pearsonr(sep[ok], f1[ok])
        rho, p_rho = stats.spearmanr(sep[ok], f1[ok])
        rows.append(dict(w=W, doy=W * 10, n=int(ok.sum()),
                         r=float(r), p=float(p),
                         rho=float(rho), p_rho=float(p_rho)))
    ps = np.array([x["p"] for x in rows] + [x["p_rho"] for x in rows])
    q = bh(ps)
    for i, row in enumerate(rows):
        row["q_pearson"] = float(q[i])
        row["q_spearman"] = float(q[len(rows) + i])
    row_ps = np.array([x["p"] for x in rows])
    row_q = bh(row_ps)
    for i, row in enumerate(rows):
        row["q_pearson_only"] = float(row_q[i])
    return rows


def leave_one_region_out():
    from cluster_inference import crop_harvest_by_region
    pr = crop_harvest_by_region()
    names = sorted(pr)
    means = {k: float(np.mean(v)) for k, v in pr.items()}
    out = []
    for drop in names:
        kept = np.array([means[k] for k in names if k != drop])
        t, p2 = stats.ttest_1samp(kept, 0.0)
        p_one = p2 / 2 if t > 0 else 1 - p2 / 2
        try:
            _, p_w = stats.wilcoxon(kept, alternative="greater")
        except ValueError:
            p_w = float("nan")
        out.append(dict(dropped=drop, n=len(kept),
                        mean_r=float(kept.mean()),
                        min_r=float(kept.min()),
                        positive=int((kept > 0).sum()),
                        p_t=float(p_one), p_wilcoxon=float(p_w)))
    return names, means, out


def main():
    res = {}

    labels, ps, q = timing_family_fdr()
    res["timing_family"] = [dict(label=l, p=float(p), q=float(qq))
                            for l, p, qq in zip(labels, ps, q)]
    print("=" * 70)
    print("(1a) TIMING FAMILY -- BH-FDR over 18 tests")
    for l, p, qq in sorted(zip(labels, ps, q), key=lambda x: x[1]):
        flag = "survives" if qq < ALPHA else "n.s."
        print(f"   {l:22s} p={p:.4f}  q={qq:.4f}  {flag}")
    print(f"   -> {int((q < ALPHA).sum())}/{len(q)} survive FDR")

    rows = breizh_windows_fdr()
    res["breizh_windows"] = rows
    print("\n(1b) BREIZHCROPS SEPARABILITY BY WINDOW -- BH-FDR over 8 tests")
    for x in rows:
        print(f"   w={x['w']:2d} (DOY {x['doy']:3d}) n={x['n']:2d}  "
              f"r={x['r']:+.3f} p={x['p']:.4f} q={x['q_pearson']:.4f} | "
              f"rho={x['rho']:+.3f} p={x['p_rho']:.4f} q={x['q_spearman']:.4f}")

    names, means, loro = leave_one_region_out()
    res["loro"] = dict(regions=names, means=means, folds=loro)
    print("\n(2) CROPHARVEST LEAVE-ONE-REGION-OUT (independent unit = region)")
    for k in sorted(means, key=lambda k: -means[k]):
        print(f"   {k:22s} mean r = {means[k]:+.3f}")
    print(f"   full sample: {len(means)} regions, "
          f"{(np.array(list(means.values()))>0).sum()}/{len(means)} positive")
    print("   drop-one:")
    for f in loro:
        print(f"     without {f['dropped']:22s} mean r={f['mean_r']:+.3f} "
              f"min={f['min_r']:+.3f} positive={f['positive']}/{f['n']} "
              f"p_t={f['p_t']:.4f} p_wilcoxon={f['p_wilcoxon']:.4f}")
    lo = min(f["mean_r"] for f in loro)
    hi = max(f["mean_r"] for f in loro)
    worst_p = max(f["p_wilcoxon"] for f in loro)
    print(f"   -> mean r stays in [{lo:+.3f}, {hi:+.3f}]; "
          f"worst-case Wilcoxon p = {worst_p:.4f}; "
          f"positive in every fold: {all(f['positive']==f['n'] for f in loro)}")

    json.dump(res, open("results/robustness_extras.json", "w"), indent=1)
    print("\nwrote results/robustness_extras.json")


if __name__ == "__main__":
    main()
