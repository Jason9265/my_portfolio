"""BreizhCrops: k x w under a TRUE calendar window, with ground-truth crop calendars.

Why this dataset earns its place in the study:
  * real acquisition dates (DOA) -> windows are real date cuts, not abstract
    timestep indices; "w = first N 10-day bins" has an actual DOY meaning.
  * 19 crop codes present in all 4 regions, and their sowing calendars are known
    agronomy rather than something inferred from a noisy NDVI green-up detector.

That gives a PRE-REGISTERED prediction, unlike the CropHarvest analysis:
  winter-sown crops (BTH/ORH/TTH/AVH) peak ~DOY 105, so a short calendar window
  should already separate them;
  spring-sown crops (MIE/MIS = maize) peak ~DOY 205, so the same window should see
  almost nothing of them.
If phenological misalignment is real, per-class recall must track class peak-DOY.

NDVI is recomputed from B8/B4 and added as an 11th band (CropHarvest carries NDVI;
BreizhCrops does not).
"""
import argparse
import collections
import json
import os

import numpy as np

BIN_DOY = 10          # each bin is a 10-day period
MIN_CLASS = 500


def load(region_keep=None, min_class=MIN_CLASS, cap_per_cell=None, seed=0):
    b = np.load("data/ds_breizh_all.npz", allow_pickle=True)
    X, mask, y, region = b["X"], b["mask"], b["y"], b["region"]
    bands = list(b["bands"])

    # add NDVI as an extra band
    b4 = X[:, :, bands.index("B4")]
    b8 = X[:, :, bands.index("B8")]
    den = b8 + b4
    ndvi = np.where(den > 1e-6, (b8 - b4) / np.maximum(den, 1e-6), np.nan)
    ndvi[~mask] = np.nan
    X = np.concatenate([X, ndvi[:, :, None]], axis=2)
    bands = bands + ["NDVI"]

    # classes present with >= min_class in EVERY region (leave-one-region-out)
    regs = sorted(set(region))
    by = {r: collections.Counter(y[region == r]) for r in regs}
    keep_cls = sorted(c for c in set(y) if all(by[r].get(c, 0) >= min_class
                                               for r in regs))
    sel = np.isin(y, keep_cls)
    if region_keep is not None:
        sel &= region in region_keep

    if cap_per_cell:
        # Stratified cap on (region, class) cells: keeps every cell represented
        # while making the logistic-regression fits tractable. 700k parcels is
        # far more than the protocol needs -- query sets stay in the thousands.
        keep = np.zeros(len(y), dtype=bool)
        rng = np.random.default_rng(seed)
        for r in regs:
            for c in keep_cls:
                idx = np.where(sel & (region == r) & (y == c))[0]
                if len(idx) == 0:
                    continue
                take = min(len(idx), cap_per_cell)
                keep[rng.choice(idx, take, replace=False)] = True
        sel = keep

    return X[sel], mask[sel], y[sel], region[sel], bands, keep_cls


def build_feats(X, mask, w):
    """Temporal statistics over the first w bins, at observed timesteps only."""
    sub = X[:, :w, :]
    m = mask[:, :w][:, :, None] & ~np.isnan(sub)
    cnt = np.maximum(m.sum(1), 1)
    mean = np.nan_to_num(np.where(m, sub, np.nan).sum(1)) / cnt
    sq = np.nan_to_num(np.where(m, sub ** 2, np.nan).sum(1)) / cnt
    std = np.sqrt(np.maximum(sq - mean ** 2, 0))
    big = np.where(m, sub, -np.inf)
    sml = np.where(m, sub, np.inf)
    mx = np.where(np.isfinite(big).any(1), big.max(1), 0.0)
    mn = np.where(np.isfinite(sml).any(1), sml.min(1), 0.0)
    # slope over observed timesteps
    t = np.arange(w, dtype=np.float32)[None, :, None]
    mt = np.where(m, t, np.nan)
    tb = np.nanmean(mt, axis=1, keepdims=True)
    tv = np.nanmean((mt - tb) ** 2, axis=1, keepdims=True)
    slope = np.nan_to_num(np.nanmean((mt - tb) * np.where(m, sub, np.nan), axis=1)
                          / np.maximum(tv[:, 0, :], 1e-6))
    cov = m.mean(1)                       # observation coverage per band
    F = np.concatenate([mean, std, mn, mx, slope, cov], axis=1).astype(np.float32)
    return np.nan_to_num(F)


def macro_f1(y, p, classes):
    f1 = []
    for c in classes:
        tp = ((p == c) & (y == c)).sum()
        fp = ((p == c) & (y != c)).sum()
        fn = ((p != c) & (y == c)).sum()
        if tp == 0:
            f1.append(0.0); continue
        pr = tp / (tp + fp + 1e-12); rc = tp / (tp + fn + 1e-12)
        f1.append(2 * pr * rc / (pr + rc + 1e-12))
    return float(np.mean(f1)), [float(x) for x in f1]


def class_peak_doy(X, mask, y, bins=36):
    """Ground-truth-ish peak DOY per class from its own NDVI climatology."""
    ni = X.shape[2] - 1                    # NDVI is last
    nd = X[:, :, ni].copy()
    nd[~mask] = np.nan
    out = {}
    for c in np.unique(y):
        m = y == c
        if m.sum() < 100:
            continue
        prof = np.nanmean(nd[m], axis=0)
        if np.all(np.isnan(prof)):
            continue
        out[int(c)] = int(np.nanargmax(prof) * BIN_DOY + BIN_DOY // 2)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="6,12,18,24,30,36")
    ap.add_argument("--ks", default="1,5,20")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--out", default="results/breizh.json")
    ap.add_argument("--cap", type=int, default=1500,
                    help="max parcels per (region,class) cell")
    a = ap.parse_args()

    from sklearn.linear_model import LogisticRegression
    from experiment import standardize

    X, mask, y, region, bands, keep_cls = load(cap_per_cell=a.cap)
    cls_of = {c: i for i, c in enumerate(keep_cls)}
    y = np.array([cls_of[v] for v in y])
    regs = sorted(set(region))
    print(f"parcels {X.shape}  regions {regs}  classes {len(keep_cls)}")

    peak = class_peak_doy(X, mask, y)
    print("class peak DOY:", {keep_cls[k]: v for k, v in sorted(peak.items(),
                                                              key=lambda kv: kv[1])})

    runs = []
    for w in [int(x) for x in a.windows.split(",")]:
        F = build_feats(X, mask, w)
        for test_r in regs:
            te = region == test_r
            tr = ~te
            Etr, Ete = standardize(F[tr], F[te])
            ytr, yte = y[tr], y[te]
            for k in [int(x) for x in a.ks.split(",")]:
                for seed in range(a.seeds):
                    rng = np.random.default_rng(1000 * seed + k)
                    sup = np.concatenate([rng.choice(np.where(yte == c)[0], k,
                                                     replace=False)
                                          for c in range(len(keep_cls))])
                    q = np.setdiff1d(np.arange(len(yte)), sup)
                    Xs, ys = Ete[sup], yte[sup]
                    Xq, yq = Ete[q], yte[q]
                    M = np.stack([Xs[ys == c].mean(0) for c in range(len(keep_cls))])
                    M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-8
                    Q = Xq / (np.linalg.norm(Xq, axis=1, keepdims=True) + 1e-8)
                    pr = (Q @ M.T).argmax(1)
                    clf = LogisticRegression(max_iter=1000, C=1.0, n_jobs=-1)
                    clf.fit(Xs, ys)
                    pl = clf.predict(Xq)
                    for name, p in (("proto", pr), ("logreg", pl)):
                        mf, per = macro_f1(yq, p, list(range(len(keep_cls))))
                        runs.append({"w": w, "region": test_r, "k": k,
                                     "seed": seed, "method": name,
                                     "oa": float((p == yq).mean()),
                                     "macro_f1": mf, "per_class_f1": per})
                print(f"  w={w:2d} {test_r} k={k:2d} done ({len(runs)})", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"runs": runs, "classes": keep_cls,
               "peak_doy": {str(k): v for k, v in peak.items()}},
              open(a.out, "w"))
    print(f"saved {a.out}: {len(runs)} runs")


if __name__ == "__main__":
    main()
