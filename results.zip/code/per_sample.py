"""Per-sample test of the phenological-misalignment hypothesis.

The region-level test (n=6 regions) is hopelessly underpowered -- nothing reaches
p<0.05 there. This re-runs the protocol and records PER-SAMPLE correctness, giving
N~37k units, then asks whether a sample's difficulty depends on how much of its
own growing season actually falls inside the fixed calendar window.

Key construct -- seasonal coverage:
    season(sample) = timesteps where NDVI exceeds the sample's own
                     midpoint between 10th and 90th percentile
    coverage_w     = |season & [0, w)| / |season|
A sample whose season sits late in the calendar (e.g. a northern-hemisphere crop
whose growing season starts in April) has low coverage at small w even though w
counts more months -- that is the misalignment the study is about.
"""
import argparse
import json

import numpy as np
from sklearn.linear_model import LogisticRegression

import experiment as E


def seasonal_mask(X):
    """(N,12) bool: timesteps inside each sample's own growing season."""
    ndvi = X[:, :, 17]
    lo = np.percentile(ndvi, 10, axis=1, keepdims=True)
    hi = np.percentile(ndvi, 90, axis=1, keepdims=True)
    thr = lo + 0.5 * (hi - lo)
    m = ndvi >= thr
    # degenerate (flat) samples: treat all observed timesteps as in-season
    flat = (hi - lo).ravel() < 0.10
    m[flat] = ndvi[flat] > 0.02
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=20)
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--out", default="results/per_sample.json")
    a = ap.parse_args()

    ds = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    X, y, region = ds["X"], ds["y"], ds["region"]
    reg = json.load(open("data/regions.json"))

    season = seasonal_mask(X)
    season_len = season.sum(1).astype(np.float32)
    season_centre = np.where(season_len > 0,
                             (season * np.arange(12)).sum(1) /
                             np.maximum(season_len, 1), np.nan)

    rows = []
    for r in reg["viable"]:
        te = region == r
        cnt = np.bincount(y[te])
        shared = np.array(sorted(
            c for c in set(np.unique(y[~te]).tolist()) & set(np.where(cnt > 0)[0].tolist())
            if cnt[c] >= max(30, a.k + 10)))
        if len(shared) < 3:
            continue
        te_sel = te & np.isin(y, shared)
        tr_sel = (~te) & np.isin(y, shared)
        gidx = np.where(te_sel)[0]
        yte_full = y[gidx]

        for w in [2, 4, 6, 8, 10, 12]:
            F = E.build_feats(X, w)
            mu, sd = F[tr_sel].mean(0), F[tr_sel].std(0) + 1e-8
            Xte = (F[gidx] - mu) / sd
            cov = (season[gidx, :w].sum(1) /
                   np.maximum(season_len[gidx], 1)).astype(np.float32)
            for seed in range(a.seeds):
                rng = np.random.default_rng(1000 * seed + a.k)
                sup = np.concatenate([
                    rng.choice(np.where(yte_full == c)[0], a.k, replace=False)
                    for c in shared])
                q = np.setdiff1d(np.arange(len(yte_full)), sup)
                clf = LogisticRegression(max_iter=2000, C=1.0, n_jobs=-1)
                clf.fit(Xte[sup], yte_full[sup])
                pred = clf.predict(Xte[q])
                correct = (pred == yte_full[q])
                rows.append({
                    "region": r, "w": w, "seed": seed,
                    "q": q, "correct": correct, "y": yte_full[q],
                    "cov": cov[q], "centre": season_centre[gidx][q],
                    "slen": season_len[gidx][q],
                })
            print(f"  {r:22s} w={w:2d} done", flush=True)

    # flatten to per-(sample,w) records, averaging correctness over seeds
    rec = {}
    for r in rows:
        key_prefix = (r["region"], r["w"])
        for j, qi in enumerate(r["q"]):
            k2 = (r["region"], int(qi), r["w"])
            if k2 not in rec:
                rec[k2] = [0, 0.0, float(r["cov"][j]), float(r["centre"][j]),
                           float(r["slen"][j]), int(r["y"][j])]
            rec[k2][0] += int(r["correct"][j])
            rec[k2][1] += float(r["cov"][j])
    out = [{"region": k[0], "sample": k[1], "w": k[2],
            "n_seed": v[0], "acc": v[0] / a.seeds, "cov": v[2], "centre": v[3],
            "slen": v[4], "cls": v[5]} for k, v in rec.items()]
    json.dump(out, open(a.out, "w"))
    print(f"\nsaved {a.out}: {len(out)} (sample, w) records")


if __name__ == "__main__":
    main()
