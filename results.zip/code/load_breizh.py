"""Load BreizhCrops (L2A CSVs inside the Zenodo zips) into a binned tensor.

Why this dataset matters for this study: unlike CropHarvest's abstract 12 monthly
steps, BreizhCrops ships a real acquisition date (`doa`) per observation. That gives
a genuine DOY/calendar axis, so "early season" can be defined as a real date cut
rather than an arbitrary timestep index.

CSV columns: Tile,doa,id,code_cultu,B2,B3,B4,B5,B6,B7,B8,B8A,B11,B12,CLD,EDG,SAT
"""
import argparse
import collections
import io
import json
import os
import zipfile

import numpy as np

BANDS = ["B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B11", "B12"]
N_BIN = 36                      # 10-day periods across the year
BIN_DAYS = 365.0 / N_BIN


def _parse(raw):
    """Parse one parcel CSV -> (doys, bands[n,10], code)."""
    lines = raw.strip().split("\n")
    if len(lines) < 3:
        return None
    hdr = lines[0].split(",")
    try:
        i_doa = hdr.index("doa")
        i_code = hdr.index("code_cultu")
        i_band = [hdr.index(b) for b in BANDS]
    except ValueError:
        return None

    doys, vals, code = [], [], None
    for ln in lines[1:]:
        p = ln.split(",")
        if len(p) < len(hdr):
            continue
        d = p[i_doa]
        try:
            mo, dd = int(d[5:7]), int(d[8:10])
        except (ValueError, IndexError):
            continue
        # day-of-year without needing a datetime object
        cum = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
        try:
            row = [float(p[i]) for i in i_band]
        except ValueError:
            continue                      # blank band -> treat observation as missing
        if not all(np.isfinite(row)):
            continue
        doys.append(cum[mo - 1] + dd)
        vals.append(row)
        if code is None:
            code = p[i_code]
    if not doys:
        return None
    return np.array(doys, dtype=np.float32), np.array(vals, dtype=np.float32), code


def _bin(doys, vals):
    """Average into N_BIN 10-day periods. Returns (N_BIN, 10) and mask."""
    out = np.zeros((N_BIN, len(BANDS)), dtype=np.float32)
    cnt = np.zeros(N_BIN, dtype=np.int32)
    idx = np.clip((doys / BIN_DAYS).astype(int), 0, N_BIN - 1)
    np.add.at(out, idx, vals)
    np.add.at(cnt, idx, 1)
    nz = cnt > 0
    out[nz] /= cnt[nz, None]
    return out, nz


def load_region(zip_path, cap=None, verbose=True):
    X, mask, y, pids = [], [], [], []
    codes = collections.Counter()
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if n.endswith(".csv")]
        if cap:
            names = names[:cap]
        for i, n in enumerate(names):
            if verbose and i and i % 20000 == 0:
                print(f"    {i}/{len(names)}", flush=True)
            with z.open(n) as f:
                raw = f.read().decode("utf-8", errors="ignore")
            r = _parse(raw)
            if r is None:
                continue
            doys, vals, code = r
            arr, m = _bin(doys, vals)
            X.append(arr)
            mask.append(m)
            y.append(code)
            codes[code] += 1
            pids.append(os.path.basename(n)[:-4])
    return (np.stack(X), np.stack(mask), np.array(y), np.array(pids), codes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zips", default="data/breizh_l2a_frh01.zip")
    ap.add_argument("--cap", type=int, default=None)
    ap.add_argument("--out", default="data/ds_breizh.npz")
    a = ap.parse_args()

    allX, allM, allY, allR = [], [], [], []
    for zp in a.zips.split(","):
        zp = zp.strip()
        if not os.path.exists(zp):
            print(f"missing {zp}, skipping"); continue
        reg = os.path.basename(zp).replace("breizh_l2a_", "").replace(".zip", "")
        print(f"loading {zp} (region {reg}) ...", flush=True)
        X, M, y, pids, codes = load_region(zp, a.cap)
        print(f"  parcels: {len(X)}   shape {X.shape}")
        print(f"  classes: {len(codes)}")
        for c, n in codes.most_common(12):
            print(f"     {c:8s} {n:7d}")
        allX.append(X); allM.append(M); allY.append(y)
        allR.append(np.array([reg] * len(X)))

    X = np.concatenate(allX); M = np.concatenate(allM)
    y = np.concatenate(allY); region = np.concatenate(allR)
    mask_frac = M.mean(axis=1)
    print(f"\ntotal parcels {len(X)}  tensor {X.shape}")
    print(f"per-parcel observed-bin fraction: mean {mask_frac.mean():.3f} "
          f"p10 {np.percentile(mask_frac,10):.3f}")

    np.savez_compressed(a.out, X=X, mask=M, y=y, region=region,
                        n_bin=N_BIN, bands=np.array(BANDS))
    print("saved", a.out)


if __name__ == "__main__":
    main()
