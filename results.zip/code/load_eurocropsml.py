"""Load EuroCropsML into a cached tensor for the third-dataset replication.

Verified facts (from the official repo dida-do/eurocropsml, not guessed):
  * files: preprocess/<region>_<parcelid>_<HCAT>.npz
  * data:  (T, 13) int64 reflectance x1e4, T VARIES per sample (34-43 in a sample)
  * dates: (T,) real acquisition dates
  * S2_BANDS = ["01","02","03","04","05","06","07","08","8A","09","10","11","12"]
    (acquisition/config.py, "order is important"); confirmed by find_clouds(band4_idx=3)
  * the -999 missing sentinel defined in code does not appear in the released
    preprocess data (0/37726 cells in a 60-file sample)

T varies, so windows are cut by DAY-OF-YEAR rather than by timestep index.
Series are padded to the max length with a separate validity mask.
"""
import argparse
import io
import json
import os
import zipfile

import numpy as np

TASK = "latvia_vs_estonia"
BANDS = ["01", "02", "03", "04", "05", "06", "07", "08", "8A",
         "09", "10", "11", "12"]


def cls_of(name):
    return name.split("_")[-1].replace(".npz", "")


def load_subset(zf, names, label_map):
    """-> data (N,Tmax,13) f4, doy (N,Tmax) i2, valid (N,Tmax) bool, label (N,) i4"""
    tmp = []
    tmax = 0
    for n in names:
        with zf.open("preprocess/" + n) as f:
            d = np.load(io.BytesIO(f.read()))
        doy = (d["dates"].astype("datetime64[D]").astype(int) % 365 + 1).astype(np.int16)
        tmp.append((d["data"].astype(np.float32), doy))
        tmax = max(tmax, len(doy))
    N = len(tmp)
    data = np.zeros((N, tmax, 13), dtype=np.float32)
    doy = np.zeros((N, tmax), dtype=np.int16)
    valid = np.zeros((N, tmax), dtype=bool)
    lab = np.zeros(N, dtype=np.int32)
    for i, (a, dd) in enumerate(tmp):
        t = len(dd)
        data[i, :t] = a
        doy[i, :t] = dd
        valid[i, :t] = True
    for i, n in enumerate(names):
        lab[i] = label_map[cls_of(n)]
    return data, doy, valid, lab


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split-zip", default="data/eurocropsml_split.zip")
    ap.add_argument("--prep-zip", default="data/eurocropsml_preprocess.zip")
    ap.add_argument("--task", default=TASK)
    ap.add_argument("--out", default="data/ds_eurocropsml.npz")
    ap.add_argument("--ks", default="1,5,10,20")
    a = ap.parse_args()

    zs = zipfile.ZipFile(a.split_zip)
    zp = zipfile.ZipFile(a.prep_zip)
    have = {n.split("/")[-1] for n in zp.namelist() if n.endswith(".npz")}

    def read(fn):
        return json.loads(zs.read(f"split/{a.task}/{fn}"))

    pre = read("pretrain/region_split.json")["train"]
    fin = {k: read(f"finetune/region_split_{k}.json") for k in a.ks.split(",")}
    test = read("finetune/region_split_all.json")["test"]

    # label space = classes appearing in the finetune support (the task's class set)
    sup_all = sorted({cls_of(e) for k in fin for e in fin[k]["train"]})
    label_map = {c: i for i, c in enumerate(sup_all)}
    print(f"task={a.task}  classes(label space)={len(label_map)}")
    for k in fin:
        print(f"  k={k:>3}: support n={len(fin[k]['train'])}  "
              f"classes={len({cls_of(e) for e in fin[k]['train']})}")
    print(f"  pretrain n={len(pre)}  test n={len(test)}")

    # The source region has classes absent from the target's label space. A
    # cross-region classifier needs a SHARED label space, so source samples
    # outside the target's class set are dropped (and the drop is reported).
    pre_all = [n for n in pre if n in have]
    pre = [n for n in pre_all if cls_of(n) in label_map]
    print(f"pretrain kept {len(pre)}/{len(pre_all)} "
          f"(dropped {len(pre_all)-len(pre)} samples of classes absent in target)")

    # The released test split also contains classes outside the k-shot support.
    # A readout fit on the support can only predict the support's classes, so
    # evaluation is restricted to that shared space (drop reported).
    test_all = [n for n in test if n in have]
    test = [n for n in test_all if cls_of(n) in label_map]
    print(f"test kept {len(test)}/{len(test_all)} "
          f"(dropped {len(test_all)-len(test)} samples outside the support "
          f"class set)")

    cache = {}
    for tag, names in (("pretrain", pre), ("test", test)):
        names = [n for n in names if n in have]
        print(f"loading {tag}: {len(names)} files ...", flush=True)
        cache[tag] = load_subset(zp, names, label_map)
        print(f"  -> {cache[tag][0].shape}", flush=True)

    # each k's support set, kept separate so the official split is honoured exactly
    for k in fin:
        names = [n for n in fin[k]["train"] if n in have]
        cache[f"sup{k}"] = load_subset(zp, names, label_map)

    out = {}
    for tag, (d, dd, v, l) in cache.items():
        out[f"{tag}_data"] = d
        out[f"{tag}_doy"] = dd
        out[f"{tag}_valid"] = v
        out[f"{tag}_label"] = l
    out["classes"] = np.array(sup_all)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    np.savez_compressed(a.out, **out)
    print("saved", a.out)


if __name__ == "__main__":
    main()
