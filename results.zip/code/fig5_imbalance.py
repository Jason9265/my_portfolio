"""Fig. 5 -- the fixed-class-set imbalance intervention (the reviewer's #1 concern).

Replaces the table in §4.5.2. The point the figure has to make: support skew and
test skew break the relationship in DIFFERENT ways, which is why the paper can
separate a genuine learning effect from an estimation artifact.

Panel A: separability-F1 correlation (drop-one-out) vs imbalance ratio, one line
         per arm. The balanced arm is flat -- the placebo check.
Panel B: macro-F1 vs imbalance ratio for the same arms. Support skew destroys
         performance; test skew barely moves it while the correlation still falls.
         That divergence is the evidence that test skew is an artifact.
"""
import collections
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from figures import AXIS, GRID, INK, INK2, MUTED, SURFACE, CAT3

# `arm` is CATEGORICAL (four distinct conditions), not ordered, so the
# ordinal ramp was wrong here and made the lines indistinguishable.
# Line charts use the adjacent pairlist, so slots 1-4 are within gate.
CAT4 = CAT3 + ["#eda100"]

ARMS = [("balanced", "balanced (placebo)", CAT4[0]),
        ("test", "test-skew", CAT4[1]),
        ("support", "support-skew", CAT4[2]),
        ("both", "both (natural state)", CAT4[3])]


def main():
    D = json.load(open("results/eurocropsml_imbalance.json"))
    g = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in D:
        g[(r["W"], r["arm"])][r["rho"]].append(r)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.6, 4.0))
    for ax in (ax1, ax2):
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, alpha=1.0, zorder=0, color=GRID)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=8)

    W = 240
    rhos = sorted({r["rho"] for r in D})
    for arm, lab, col in ARMS:
        ys1, ys2 = [], []
        for rho in rhos:
            rs = g[(W, arm)][rho]
            if not rs:
                ys1.append(np.nan); ys2.append(np.nan); continue
            ys1.append(np.mean([x["drop1"] for x in rs]))
            ys2.append(np.mean([x["macro_f1"] for x in rs]))
        ax1.plot(rhos, ys1, color=col, lw=2.4, marker="o", ms=8,
                 mfc=col, mec=SURFACE, mew=2, zorder=3, label=lab)
        ax2.plot(rhos, ys2, color=col, lw=2.4, marker="o", ms=8,
                 mfc=col, mec=SURFACE, mew=2, zorder=3, label=lab)

    ax1.axhline(0, color=AXIS, lw=1.2, zorder=2)
    ax1.set_xscale("log")
    ax1.set_xticks(rhos); ax1.set_xticklabels([str(r) for r in rhos])
    ax1.set_xlabel("imbalance ratio ρ  (max class ÷ min class)", fontsize=8.5)
    ax1.set_ylabel("separability–$F_1$ correlation\n(drop-one-out $r$)",
                   fontsize=8.5)
    ax1.set_title("A  the balanced arm is flat — the placebo check",
                  fontsize=9.5, color=INK, loc="left", pad=6)
    ax1.set_ylim(-0.15, 0.65)
    ax1.legend(fontsize=7.4, loc="lower left", labelspacing=0.3)

    ax2.set_xscale("log")
    ax2.set_xticks(rhos); ax2.set_xticklabels([str(r) for r in rhos])
    ax2.set_xlabel("imbalance ratio ρ  (max class ÷ min class)", fontsize=8.5)
    ax2.set_ylabel("macro-$F_1$", fontsize=8.5)
    ax2.set_title("B  but only support-skew destroys accuracy",
                  fontsize=9.5, color=INK, loc="left", pad=6)
    ax2.set_ylim(0.05, 0.40)
    ax2.legend(fontsize=7.4, loc="lower left", labelspacing=0.3)

    fig.suptitle(f"Fixed 24-class set, DOY {W}: only the sample distribution changes",
                 fontsize=10.5, color=INK, x=0.01, ha="left", y=0.995)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig("figs/fig5_imbalance.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig5_imbalance.png")
    for arm, lab, _ in ARMS:
        r1 = np.nanmean([np.mean([x["drop1"] for x in g[(W, arm)][rho]])
                         for rho in rhos])
        r2 = np.nanmean([np.mean([x["macro_f1"] for x in g[(W, arm)][rho]])
                         for rho in rhos])
        print(f"  {lab:24s} mean drop1 r = {r1:+.3f}   mean macroF1 = {r2:.3f}")


if __name__ == "__main__":
    main()
