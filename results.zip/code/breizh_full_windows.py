"""Complete the BreizhCrops window grid (§4.3.1 and §4.4.1).

The second-round review noticed that §3.3.2 defines six windows
(w in {6,12,18,24,30,36}) while the timing table reports five and the
separability table four, with no stated reason. All six windows exist in
results/breizh.json, so the omissions were a reporting choice, not a data
limitation. This computes the missing cells so the tables can be complete.

Reports, for every window:
  * peak-DOY vs per-class F1  (§4.3.1)
  * window-truncated separability vs per-class F1  (§4.4.1)
and a Benjamini-Hochberg FDR over the resulting family.

Outputs results/breizh_full_windows.json.
"""
import io
import json
import sys
import warnings

import numpy as np
from scipy import stats

sys.path.insert(0, "code")


def bh(pvals):
    p = np.asarray(pvals, float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order] * n / (np.arange(n) + 1.0)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    q = np.empty(n)
    q[order] = np.clip(ranked, 0.0, 1.0)
    return q


def main():
    from breizh_exp import load
    bz = json.load(open("results/breizh.json"))
    br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys])
    n = len(keep)
    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])

    peak_doy = np.array([np.nanargmax(prof[c]) * 10 + 5 for c in range(n)])

    rows = []
    for W in (6, 12, 18, 24, 30, 36):
        f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                                if r["w"] == W and r["method"] == "logreg"
                                and r["k"] == 20]) for c in range(n)])
        ok = np.isfinite(f1) & (f1 > 0)

        # --- §4.3.1: the single timing proxy
        r_t, p_t = stats.pearsonr(peak_doy[ok], f1[ok])

        # --- §4.4.1: window-truncated separability
        P = prof[:, :W]
        C = len(P)
        sep = np.full(C, np.nan)
        for c in range(C):
            best = np.inf
            for d in range(C):
                if d == c:
                    continue
                v = ~np.isnan(P[c]) & ~np.isnan(P[d])
                if v.sum() < 2:
                    continue
                best = min(best, np.sqrt(np.mean((P[c, v] - P[d, v]) ** 2)))
            sep[c] = best if np.isfinite(best) else np.nan
        ok_s = ok & np.isfinite(sep)
        r_s, p_s = stats.pearsonr(sep[ok_s], f1[ok_s])
        rho_s, p_rho = stats.spearmanr(sep[ok_s], f1[ok_s])
        loo = []
        for i in range(int(ok_s.sum())):
            m = np.ones(int(ok_s.sum()), bool); m[i] = False
            if np.std(sep[ok_s][m]) < 1e-12:
                continue
            loo.append(stats.pearsonr(sep[ok_s][m], f1[ok_s][m])[0])
        loo = np.array(loo)

        rows.append(dict(w=W, doy=W * 10, n=int(ok_s.sum()),
                         timing_r=float(r_t), timing_p=float(p_t),
                         sep_r=float(r_s), sep_p=float(p_s),
                         sep_rho=float(rho_s), sep_p_rho=float(p_rho),
                         loo_min=float(loo.min()), loo_max=float(loo.max()),
                         loo_positive=int((loo > 0).sum()), loo_n=int(len(loo))))

    # FDR over both families
    tp = [x["timing_p"] for x in rows]
    sp = [x["sep_p"] for x in rows] + [x["sep_p_rho"] for x in rows]
    qt = bh(tp)
    qs = bh(sp)
    for i, x in enumerate(rows):
        x["timing_q"] = float(qt[i])
        x["sep_q_pearson"] = float(qs[i])
        x["sep_q_spearman"] = float(qs[len(rows) + i])

    print("=== §4.3.1  peak DOY vs per-class F1  (all six windows) ===")
    print("  w   DOY      r        p        q")
    for x in rows:
        print(f"  {x['w']:2d}  {x['doy']:3d}  {x['timing_r']:+.3f}  "
              f"{x['timing_p']:.3f}   {x['timing_q']:.3f}")
    print(f"  -> {sum(1 for x in rows if x['timing_q'] < 0.05)}/{len(rows)} survive FDR")

    print("\n=== §4.4.1  separability vs per-class F1  (all six windows) ===")
    print("  w   DOY   r        p       q_r    rho     p_rho   q_rho   "
          "LOO range          sign")
    for x in rows:
        print(f"  {x['w']:2d}  {x['doy']:3d}  {x['sep_r']:+.3f}  {x['sep_p']:.4f}  "
              f"{x['sep_q_pearson']:.4f}  {x['sep_rho']:+.3f}  {x['sep_p_rho']:.4f}  "
              f"{x['sep_q_spearman']:.4f}  [{x['loo_min']:+.3f},{x['loo_max']:+.3f}]  "
              f"{x['loo_positive']}/{x['loo_n']}")
    sig = sum(1 for x in rows if x["sep_q_pearson"] < 0.05)
    sig2 = sum(1 for x in rows if x["sep_q_spearman"] < 0.05)
    print(f"  -> Pearson q<0.05: {sig}/{len(rows)};  "
          f"Spearman q<0.05: {sig2}/{len(rows)}")
    io.open("results/breizh_full_windows.json", "w", encoding="utf-8").write(
        json.dumps(rows, indent=1))
    print("\nwrote results/breizh_full_windows.json")


if __name__ == "__main__":
    main()
