"""Direction A: label budget (k) x observation window (w) for cross-region crop
type classification on CropHarvest.

Protocol: leave-one-region-out K-shot adaptation (the standard for spatial transfer,
cf. EuroCropsML), NOT episodic N-way K-shot.

Observation windows are CALENDAR-aligned [0, w) -- verified empirically that
CropHarvest's 12 timesteps are calendar-aligned, not phenology-aligned
(north temp peaks t=5, south peaks t=0).

Method note: "pre-train on source then fine-tune on k target samples" is NOT a
valid distinct method for a linear probe. L2-regularised logistic regression is
strictly convex, so it has a unique optimum; warm-starting from the source
solution only changes the optimiser path, not the destination (verified: warm-start
and fresh fits give identical predictions). Genuine transfer baselines must ADD
target data to the objective -- see `logreg_transfer` (support upweighted to carry
comparable mass to the source pool) and `logreg_src_only` (0-shot, no target labels).
"""
import argparse
import collections
import json
import os
import time

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

RNG = np.random.default_rng(0)
NDVI_IDX = 17


# ---------------------------------------------------------------- features

def build_feats(X, w):
    """Fixed-dimension temporal statistics for window t in [0, w).

    Returns (N, 18*5) = [mean, std, min, max, slope] per band.
    Dimension is independent of w so window length is not confounded with
    feature dimension.
    """
    sub = X[:, :w, :]
    mean = sub.mean(1)
    std = sub.std(1)
    mn = sub.min(1)
    mx = sub.max(1)
    if w >= 2:
        t = np.arange(w, dtype=np.float32)
        t = (t - t.mean()) / (t.std() + 1e-8)
        slope = (sub * t[None, :, None]).mean(1)
    else:
        slope = np.zeros_like(sub[:, 0, :])
    return np.concatenate([mean, std, mn, mx, slope], axis=1).astype(np.float32)


def standardize(tr, te):
    mu, sd = tr.mean(0), tr.std(0) + 1e-8
    return (tr - mu) / sd, (te - mu) / sd


# ---------------------------------------------------------------- methods

def _sub(Xsrc, ysrc, cap):
    """Deterministic subsample of the source pool (keeps runtime bounded)."""
    if Xsrc is None or len(Xsrc) <= cap:
        return Xsrc, ysrc
    sel = RNG.choice(len(Xsrc), cap, replace=False)
    return Xsrc[sel], ysrc[sel]


def fit_predict(method, Xsup, ysup, Xq, Xsrc=None, ysrc=None, seed=0):
    if method == "proto":
        # nearest class mean, cosine distance
        cs = np.unique(ysup)
        M = np.stack([Xsup[ysup == c].mean(0) for c in cs])
        M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-8
        Q = Xq / (np.linalg.norm(Xq, axis=1, keepdims=True) + 1e-8)
        return cs[(Q @ M.T).argmax(1)]

    if method == "logreg":
        clf = LogisticRegression(max_iter=2000, C=1.0, n_jobs=-1)
        clf.fit(Xsup, ysup)
        return clf.predict(Xq)

    if method == "logreg_transfer":
        # transfer + adapt by joint training with the k target samples upweighted
        # to carry comparable mass to the source pool. Robust when k is tiny.
        Xa, ya = _sub(Xsrc, ysrc, 6000)
        w = len(Xa) / max(len(Xsup), 1)
        Xj = np.vstack([Xa, Xsup])
        yj = np.concatenate([ya, ysup])
        sw = np.concatenate([np.ones(len(Xa)), np.full(len(Xsup), w)])
        clf = LogisticRegression(max_iter=2000, C=1.0, n_jobs=-1)
        clf.fit(Xj, yj, sample_weight=sw)
        return clf.predict(Xq)

    if method == "logreg_src_only":
        # 0-shot transfer: source pool only, no target labels at all
        Xa, ya = _sub(Xsrc, ysrc, 6000)
        clf = LogisticRegression(max_iter=1000, C=1.0, n_jobs=-1)
        clf.fit(Xa, ya)
        return clf.predict(Xq)

    if method == "rf":
        clf = RandomForestClassifier(
            n_estimators=200, n_jobs=-1, random_state=seed)
        clf.fit(Xsup, ysup)
        return clf.predict(Xq)

    raise ValueError(method)


# ---------------------------------------------------------------- metrics

def macro_f1(y, p):
    f1s = []
    for c in np.unique(y):
        tp = ((p == c) & (y == c)).sum()
        fp = ((p == c) & (y != c)).sum()
        fn = ((p != c) & (y == c)).sum()
        if tp == 0:
            f1s.append(0.0)
            continue
        prec = tp / (tp + fp + 1e-12)
        rec = tp / (tp + fn + 1e-12)
        f1s.append(2 * prec * rec / (prec + rec + 1e-12))
    return float(np.mean(f1s))


def metrics(y, p):
    return {"oa": float((y == p).mean()), "macro_f1": macro_f1(y, p)}


# ---------------------------------------------------------------- runner

def run(ds, regions, windows, ks, methods, seeds, out_path,
        min_class=30, min_query=10):
    """min_class: a class enters a region's FIXED evaluation set only if it has at
    least this many samples. Fixing the set (rather than per-k filtering) keeps the
    task constant across k and w, which is what makes the k x w interaction readable.
    """
    X, y, region = ds["X"], ds["y"], ds["region"]
    results, skips = [], []

    for test_r in regions:
        te_mask = region == test_r
        tr_mask = ~te_mask
        if te_mask.sum() < 100:
            skips.append({"region": test_r, "reason": "too_few_samples",
                          "n": int(te_mask.sum())})
            continue

        # FIXED class set for this region: present in region, in source pool,
        # and large enough to sustain the largest k.
        kmax = max(ks)
        cnt = collections.Counter(y[te_mask].tolist())
        shared = np.array(sorted(
            c for c in set(np.unique(y[tr_mask]).tolist()) & set(cnt)
            if cnt[c] >= max(min_class, kmax + min_query)
        ))
        if len(shared) < 3:
            skips.append({"region": test_r, "reason": "too_few_classes",
                          "n_classes": int(len(shared))})
            continue

        print(f"[{test_r}] fixed class set: {[list(ds['classes'])[c] for c in shared]}"
              f"  n={int((te_mask & np.isin(y, shared)).sum())}", flush=True)
        te_sel = te_mask & np.isin(y, shared)
        tr_sel = tr_mask & np.isin(y, shared)
        F_cache = {}

        for w in windows:
            if w not in F_cache:
                F_cache[w] = build_feats(X, w)
            F = F_cache[w]
            Xtr, ytr = F[tr_sel], y[tr_sel]
            Xte, yte = F[te_sel], y[te_sel]
            Xtr, Xte = standardize(Xtr, Xte)

            for k in ks:
                for seed in range(seeds):
                    rng = np.random.default_rng(1000 * seed + k)
                    sup_idx = []
                    for c in shared:
                        pool = np.where(yte == c)[0]
                        sup_idx.extend(rng.choice(pool, k, replace=False))
                    sup_idx = np.array(sup_idx)
                    q_idx = np.setdiff1d(np.arange(len(yte)), sup_idx)
                    if len(q_idx) < 50:
                        continue
                    Xs, ys = Xte[sup_idx], yte[sup_idx]
                    Xq, yq = Xte[q_idx], yte[q_idx]
                    for m in methods:
                        if m == "logreg_src_only" and k != ks[0]:
                            continue          # independent of k -> run once
                        t0 = time.time()
                        p = fit_predict(m, Xs, ys, Xq, Xtr, ytr, seed)
                        mt = metrics(yq, p)
                        results.append({
                            "region": test_r, "w": w, "k": k, "seed": seed,
                            "method": m, "n_query": int(len(yq)),
                            "n_support": int(len(ys)),
                            "n_classes": int(len(shared)),
                            "fit_s": round(time.time() - t0, 3), **mt,
                        })
                print(f"  {test_r:20s} w={w:2d} k={k:2d} done "
                      f"({len(results)} runs)", flush=True)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w") as f:
        json.dump({"runs": results, "skips": skips,
                   "config": {"windows": windows, "ks": ks, "methods": methods,
                              "seeds": seeds, "min_class": min_class}}, f)
    if skips:
        print(f"\nSKIPPED: {skips}")
    print(f"saved {out_path}: {len(results)} runs")
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="2,4,6,8,10,12")
    ap.add_argument("--ks", default="1,5,10,20,50")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--methods", default="proto,logreg,logreg_src,rf")
    ap.add_argument("--out", default="results/main.json")
    a = ap.parse_args()

    ds = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    reg = json.load(open("data/regions.json"))
    test_regions = reg["viable"]

    run(ds, test_regions,
        [int(x) for x in a.windows.split(",")],
        [int(x) for x in a.ks.split(",")],
        a.methods.split(","), a.seeds, a.out)


if __name__ == "__main__":
    main()
