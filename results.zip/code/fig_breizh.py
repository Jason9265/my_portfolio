"""Figure 4: BreizhCrops -- a failed phenology predictor and the one that works.

Panel A: macro-F1 peaks at DOY 180 and then DEGRADES as the window grows.
Panel B: per-class F1 vs class NDVI-peak DOY -- the pre-registered predictor,
         and it does not hold.
Panel C: per-class F1 vs profile SEPARABILITY (distance to the nearest competing
         class within the window) -- this predicts well.

Palette: ordinal blue ramp for the window axis (w is ordered); single hue with
direct labels for the class scatter.
"""
import json
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

sys.path.insert(0, "code")
from breizh_exp import load                                    # noqa: E402
from figures import AXIS, GRID, INK, INK2, K_RAMP, SURFACE     # noqa: E402


def sep_in_window(prof, w):
    P = prof[:, :w]
    C = len(P)
    out = np.full(C, np.nan)
    for c in range(C):
        best = np.inf
        for d in range(C):
            if d == c:
                continue
            v = ~np.isnan(P[c]) & ~np.isnan(P[d])
            if v.sum() < 2:
                continue
            best = min(best, np.sqrt(np.mean((P[c, v] - P[d, v]) ** 2)))
        out[c] = best if np.isfinite(best) else np.nan
    return out


def main():
    d = json.load(open("results/breizh.json"))
    runs, cls = d["runs"], d["classes"]
    peak = {int(k): v for k, v in d["peak_doy"].items()}
    ws = sorted({r["w"] for r in runs})

    X, mask, y, region, bands, keep = load(cap_per_cell=1500)
    cls_of = {c: i for i, c in enumerate(keep)}
    y = np.array([cls_of[v] for v in y])
    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(len(cls))])

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(13.2, 4.0))
    for ax in (ax1, ax2, ax3):
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, alpha=1.0, zorder=0, color=GRID)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=8)

    # A: macro-F1 vs window
    for j, (m, k, lab) in enumerate((("logreg", 20, "logreg, k=20"),
                                     ("logreg", 5, "logreg, k=5"),
                                     ("proto", 20, "proto, k=20"),
                                     ("logreg", 1, "logreg, k=1"))):
        v = [np.mean([r["macro_f1"] for r in runs
                      if r["w"] == w and r["method"] == m and r["k"] == k])
             for w in ws]
        ax1.plot([w * 10 for w in ws], v, color=K_RAMP[j], lw=2, marker="o",
                 ms=8, mfc=K_RAMP[j], mec=SURFACE, mew=2, zorder=3)
        ax1.annotate(lab, ([w * 10 for w in ws][-1], v[-1]),
                     textcoords="offset points", xytext=(7, 0), fontsize=7,
                     color=INK2, va="center", ha="left")
    best = max(ws, key=lambda w: np.mean(
        [r["macro_f1"] for r in runs
         if r["w"] == w and r["method"] == "logreg" and r["k"] == 20]))
    ax1.axvline(best * 10, color=AXIS, lw=1.2, ls="--", zorder=2)
    ax1.annotate(f"peak at DOY {best*10}", (best * 10, ax1.get_ylim()[1] * 0.97),
                 fontsize=7.5, color=INK2, ha="center", va="top")
    ax1.set_xlabel("observation window: data through DOY", fontsize=8.5)
    ax1.set_ylabel("macro-F1", fontsize=8.5)
    ax1.set_title("A  more window is not monotonically better",
                  fontsize=9.5, color=INK, loc="left", pad=6)
    ax1.set_xlim(0, 470)

    f1_24 = np.array([np.mean([r["per_class_f1"][c] for r in runs
                               if r["w"] == 24 and r["method"] == "logreg"
                               and r["k"] == 20])
                      for c in range(len(cls))])
    pd_ = np.array([peak[c] for c in range(len(cls))])

    # B: the failed predictor
    ax2.scatter(pd_, f1_24, s=52, color="#eb6834", edgecolor=SURFACE,
                linewidth=1.6, zorder=3)
    rr = stats.pearsonr(pd_, f1_24)
    ax2.annotate(f"r = {rr[0]:+.2f}\np = {rr[1]:.2f}  (n.s.)", (0.03, 0.95),
                 xycoords="axes fraction", fontsize=8, color=INK2, va="top")
    ax2.set_xlabel("class NDVI-peak DOY (pre-registered predictor)", fontsize=8.5)
    ax2.set_ylabel("per-class F1  (w=24, logreg k=20)", fontsize=8.5)
    ax2.set_title("B  phenological TIMING does not predict it",
                  fontsize=9.5, color=INK, loc="left", pad=6)

    # C: the working predictor
    sep = sep_in_window(prof, 24)
    v = ~np.isnan(sep)
    ax3.scatter(sep[v], f1_24[v], s=52, color=K_RAMP[3], edgecolor=SURFACE,
                linewidth=1.6, zorder=3)
    rs = stats.pearsonr(sep[v], f1_24[v])
    z = np.polyfit(sep[v], f1_24[v], 1)
    xs = np.linspace(sep[v].min(), sep[v].max(), 10)
    ax3.plot(xs, np.polyval(z, xs), color=AXIS, lw=1.5, ls="--", zorder=2)
    ax3.annotate(f"r = {rs[0]:+.2f}\np = {rs[1]:.2e}", (0.03, 0.95),
                 xycoords="axes fraction", fontsize=8, color=INK2, va="top")
    ax3.set_xlabel("profile separability (min distance to another class)",
                   fontsize=8.5)
    ax3.set_title("C  trajectory SHAPE does", fontsize=9.5, color=INK,
                  loc="left", pad=6)

    fig.tight_layout()
    fig.savefig("figs/fig4_breizh.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig4_breizh.png")
    print(f"  peak window w={best} (DOY {best*10})")
    print(f"  peak-DOY predictor: r={rr[0]:+.3f} p={rr[1]:.3f}")
    print(f"  separability      : r={rs[0]:+.3f} p={rs[1]:.2e}")


if __name__ == "__main__":
    main()
