"""Aggregate experiment results: k x w interaction, with seed-level CIs and
paired tests. Also computes the region-level phenology explanatory variable.
"""
import argparse
import collections
import json

import numpy as np


def load_results(path):
    d = json.load(open(path))
    return d["runs"], d.get("skips", [])


def agg(runs, keys=("region", "w", "k", "method"), metric="macro_f1"):
    """mean / std / n over seeds, grouped by keys."""
    g = collections.defaultdict(list)
    for r in runs:
        g[tuple(r[k] for k in keys)].append(r[metric])
    out = {}
    for kk, v in g.items():
        v = np.array(v)
        out[kk] = {
            "mean": float(v.mean()),
            "std": float(v.std(ddof=1)) if len(v) > 1 else 0.0,
            "n": len(v),
            "se": float(v.std(ddof=1) / np.sqrt(len(v))) if len(v) > 1 else 0.0,
        }
    return out


def ci95(a):
    a = np.asarray(a)
    if len(a) < 2:
        return (float(a.mean()), float(a.mean()))
    bs = [np.random.default_rng(i).choice(a, len(a), replace=True).mean()
          for i in range(2000)]
    return float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))


def region_phenology(ds_path="data/ds_cropharvest.npz"):
    """Robust region-level phenological phase: median NDVI-peak timestep.

    Region-level aggregation averages over many samples, so it does not depend on
    the (unreliable) per-sample green-up detector.
    """
    d = np.load(ds_path, allow_pickle=True)
    X, region = d["X"], d["region"]
    ndvi = X[:, :, 17]
    out = {}
    for r in sorted(set(region)):
        m = region == r
        if m.sum() < 50:
            continue
        sub = ndvi[m]
        # circular-safe peak: use argmax of the sample mean curve (averaging
        # suppresses noise), plus per-sample peak median
        mean_curve = sub.mean(0)
        per_sample_peak = sub.argmax(1)
        out[r] = {
            "n": int(m.sum()),
            "mean_curve_peak_t": int(mean_curve.argmax()),
            "median_sample_peak_t": float(np.median(per_sample_peak)),
            "ndvi_amplitude": float(np.percentile(sub, 90) - np.percentile(sub, 10)),
        }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="results/main.json")
    ap.add_argument("--metric", default="macro_f1")
    a = ap.parse_args()

    runs, skips = load_results(a.inp)
    print(f"runs: {len(runs)}   skips: {skips}\n")

    A = agg(runs, metric=a.metric)
    regions = sorted({k[0] for k in A})
    ws = sorted({k[1] for k in A})
    ks = sorted({k[2] for k in A})
    methods = sorted({k[3] for k in A})

    # ---- main table: proto, macro-F1, rows = (region,w), cols = k
    for m in methods:
        print(f"=== {m}  ({a.metric}) ===")
        hdr = "region".ljust(22) + "w".rjust(4) + "".join(f"k={k}".rjust(10) for k in ks)
        print(hdr)
        for r in regions:
            for w in ws:
                cells = []
                for k in ks:
                    v = A.get((r, w, k, m))
                    cells.append(f"{v['mean']:.3f}" if v else "  -  ")
                print(f"{r:22s}{w:4d}" + "".join(c.rjust(10) for c in cells))
        print()

    # ---- H1: does w matter at low k vs high k?  (k x w interaction)
    m = "proto"
    print("=== H1: window sensitivity by label budget (proto) ===")
    print(f"{'region':22s}{'k':>4s}{'w=2':>9s}{'w=12':>9s}{'drop':>9s}{'rel_drop':>10s}")
    for r in regions:
        for k in ks:
            lo = A.get((r, 2, k, m))
            hi = A.get((r, max(ws), k, m))
            if not (lo and hi):
                continue
            drop = hi["mean"] - lo["mean"]
            rel = drop / max(hi["mean"], 1e-9)
            print(f"{r:22s}{k:4d}{lo['mean']:9.3f}{hi['mean']:9.3f}"
                  f"{drop:9.3f}{rel:10.1%}")
        print()

    # ---- H2: region phenology as explanatory variable
    print("=== region phenology (explanatory variable) ===")
    ph = region_phenology()
    for r, v in ph.items():
        print(f"  {r:26s} n={v['n']:6d}  peak_t={v['mean_curve_peak_t']:2d}  "
              f"median_sample_peak={v['median_sample_peak_t']:4.1f}  "
              f"ndvi_amp={v['ndvi_amplitude']:.3f}")

    # correlate phenology with short-window performance loss
    print("\n=== H2: peak_t vs short-window penalty (proto, k=20) ===")
    xs, ys = [], []
    for r in regions:
        lo, hi = A.get((r, 2, 20, m)), A.get((r, max(ws), 20, m))
        if not (lo and hi) or r not in ph:
            continue
        pen = hi["mean"] - lo["mean"]
        xs.append(ph[r]["median_sample_peak_t"])
        ys.append(pen)
        print(f"  {r:26s} peak_t={xs[-1]:4.1f}  penalty={pen:+.3f}")
    if len(xs) >= 3:
        rho = np.corrcoef(xs, ys)[0, 1]
        print(f"\n  Pearson r(peak_t, short-window penalty) = {rho:+.3f}  (n={len(xs)})")

    json.dump({str(k): v for k, v in A.items()},
              open("results/agg.json", "w"), indent=1)
    json.dump(ph, open("results/phenology.json", "w"), indent=1)
    print("\nsaved results/agg.json + results/phenology.json")


if __name__ == "__main__":
    main()
