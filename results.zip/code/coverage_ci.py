"""Cluster-aware uncertainty for the §4.6 per-sample coverage analysis.

The second-round review's #2 major comment: §4.6 reports per-sample correlations
with p-values like 8e-164 computed as if the 159,924 records were IID. They are
not -- records share region, crop class, geography and time series. The effect
size (r~0.36) is meaningful; the astronomical p is not, and it invites exactly
the pseudo-replication objection that §4.4.4 already answered for the
separability analysis.

This recomputes every §4.6 cell with a CLASS-CLUSTERED two-stage bootstrap:

  * resample crop classes with replacement (the cluster unit);
  * within each resampled class, resample its records with replacement;
  * recompute the within-class-demeaned correlation on the replicate.

Reports a percentile 95% CI and a cluster-aware one-sided bootstrap p
(fraction of replicates at or below zero). No astronomical p-values.

Outputs results/coverage_ci.json.
"""
import argparse
import collections
import json
import os

import numpy as np
from scipy import stats

# the cells quoted in §4.6, as (region, windows)
CELLS = [
    ("ile-de-france", [4]),
    ("jecam:south_america", [6, 8, 10]),
    ("canada", [6, 8, 10]),
    ("martinique-france", [4, 6, 8, 10]),
    ("reunion-france", [6, 8]),
    ("jecam:africa", [2, 4]),
]
MIN_PER_CLASS = 5


def demeaned_r(cov, acc, cls):
    """Pearson r between cov and acc after removing each class's own mean."""
    cd = np.zeros_like(cov)
    ad = np.zeros_like(acc)
    for c in np.unique(cls):
        m = cls == c
        if m.sum() < MIN_PER_CLASS:
            continue
        cd[m] = cov[m] - cov[m].mean()
        ad[m] = acc[m] - acc[m].mean()
    if cd.std() < 1e-12 or ad.std() < 1e-12:
        return np.nan
    return float(stats.pearsonr(cd, ad)[0])


def raw_r(cov, acc):
    if cov.std() < 1e-12 or acc.std() < 1e-12:
        return np.nan
    return float(stats.pearsonr(cov, acc)[0])


def cluster_bootstrap(cov, acc, cls, reps, rng):
    """Two-stage: resample classes, then resample records inside each."""
    classes = [c for c in np.unique(cls) if (cls == c).sum() >= MIN_PER_CLASS]
    if len(classes) < 3:
        return None
    pos = {c: np.where(cls == c)[0] for c in classes}
    out = []
    for _ in range(reps):
        draw = rng.choice(classes, len(classes), replace=True)
        idx = np.concatenate([rng.choice(pos[c], len(pos[c]), replace=True)
                              for c in draw])
        cc, aa, ll = cov[idx], acc[idx], cls[idx]
        # relabel duplicated classes so demeaning treats each draw separately
        ll = np.concatenate([np.full(len(pos[c]), i)
                             for i, c in enumerate(draw)])
        r = demeaned_r(cc, aa, ll)
        if np.isfinite(r):
            out.append(r)
    return np.array(out) if out else None


def delete_one_class_jackknife(cov, acc, cls):
    """Cluster jackknife over classes -> (est, se, ci_lo, ci_hi).

    The cluster bootstrap is over-conservative when there are few clusters
    (here G=5..8), so this cross-checks it with the standard delete-one-cluster
    jackknife and a t(G-1) reference distribution.
    """
    classes = [c for c in np.unique(cls) if (cls == c).sum() >= MIN_PER_CLASS]
    G = len(classes)
    if G < 3:
        return None
    keep = np.isin(cls, classes)
    est = demeaned_r(cov[keep], acc[keep], cls[keep])
    reps = []
    for c in classes:
        m = keep & (cls != c)
        r = demeaned_r(cov[m], acc[m], cls[m])
        if np.isfinite(r):
            reps.append(r)
    reps = np.array(reps)
    if len(reps) < 3 or not np.isfinite(est):
        return None
    mean_jk = reps.mean()
    se = np.sqrt((len(reps) - 1) / len(reps) * ((reps - mean_jk) ** 2).sum())
    tcrit = stats.t.ppf(0.975, len(reps) - 1)
    # centre the interval on the full-sample estimate, jackknife SE
    return est, float(se), float(est - tcrit * se), float(est + tcrit * se)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-sample", default="results/per_sample.json")
    ap.add_argument("--reps", type=int, default=2000)
    ap.add_argument("--out", default="results/coverage_ci.json")
    a = ap.parse_args()

    ps = json.load(open(a.per_sample))
    by = collections.defaultdict(list)
    for r in ps:
        by[(r["region"], r["w"])].append(r)

    rng = np.random.default_rng(20260926)
    res = []
    print(f"{'region':22s} {'w':>3s} {'n':>7s} {'G':>3s} "
          f"{'r_within':>9s} {'boot 95% CI':>20s} {'p_boot':>8s} "
          f"{'jackknife 95% CI':>22s} {'r_raw':>7s}")
    for region, ws in CELLS:
        for w in ws:
            v = by.get((region, w))
            if not v:
                continue
            cov = np.array([x["cov"] for x in v], float)
            acc = np.array([x["acc"] for x in v], float)
            cls = np.array([x["cls"] for x in v])
            rw = demeaned_r(cov, acc, cls)
            rr = raw_r(cov, acc)
            bs = cluster_bootstrap(cov, acc, cls, a.reps, rng)
            if bs is None:
                lo = hi = pb = float("nan")
            else:
                lo, hi = np.percentile(bs, [2.5, 97.5])
                pb = float((bs <= 0).mean())
            n_cls = len(set(cls.tolist()))
            jk = delete_one_class_jackknife(cov, acc, cls)
            jlo, jhi = (jk[2], jk[3]) if jk else (float("nan"), float("nan"))
            print(f"{region:22s} {w:3d} {len(v):7d} {n_cls:3d} "
                  f"{rw:+9.3f} [{lo:+.3f}, {hi:+.3f}] {pb:8.4f} "
                  f"     [{jlo:+.3f}, {jhi:+.3f}] {rr:+7.3f}")
            res.append({"region": region, "w": w, "n": len(v), "n_classes": n_cls,
                        "r_within": rw, "ci_lo": float(lo), "ci_hi": float(hi),
                        "p_boot_one_sided": pb, "r_raw": rr,
                        "jk_se": (jk[1] if jk else None),
                        "jk_lo": float(jlo), "jk_hi": float(jhi)})

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"reps": a.reps, "cells": res}, open(a.out, "w"), indent=1)
    print(f"\nsaved {a.out}")

    n_sig = sum(1 for r in res
                if np.isfinite(r["ci_lo"]) and r["ci_lo"] > 0)
    n_zero = sum(1 for r in res
                 if np.isfinite(r["ci_hi"]) and r["ci_lo"] <= 0 <= r["ci_hi"])
    n_neg = sum(1 for r in res
                if np.isfinite(r["ci_hi"]) and r["ci_hi"] < 0)
    print(f"cells with CI entirely > 0 : {n_sig}/{len(res)}")
    print(f"cells with CI spanning 0   : {n_zero}/{len(res)}")
    print(f"cells with CI entirely < 0 : {n_neg}/{len(res)}")


if __name__ == "__main__":
    main()
