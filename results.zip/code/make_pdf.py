"""Render 02_论文_全稿.md -> 论文.pdf via Markdown -> HTML -> headless Chrome.

No pandoc / no LaTeX on this machine, so the route is:
  1. protect $...$ and $$...$$ from the Markdown pass with placeholders
  2. Python-Markdown (tables extension) -> HTML
  3. restore the math, hand it to KaTeX (loaded from jsDelivr) for typesetting
  4. headless Chrome/Edge --print-to-pdf

The math protection matters: without it Markdown would read the underscores in
$F_1$ as emphasis and mangle the equations.
"""
import argparse
import io
import os
import re
import subprocess
import sys

import markdown

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

TEMPLATE = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<title>__TITLE__</title>
<link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script defer
  src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script defer
  src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"
  onload="renderMathInElement(document.body,{delimiters:[
     {left:'$$',right:'$$',display:true},
     {left:'$',right:'$',display:false}],throwOnError:false});"></script>
<style>
  @page { size: A4; margin: 20mm 18mm 18mm 18mm; }
  html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  body {
    font-family: Georgia, "Times New Roman", "SimSun", "Microsoft YaHei", serif;
    font-size: 10.5pt; line-height: 1.62; color: #111;
    max-width: 100%; margin: 0;
  }
  h1 { font-size: 17pt; line-height: 1.35; margin: 0 0 4pt 0;
       font-family: "Microsoft YaHei", "SimHei", sans-serif; }
  h1 + p em { font-size: 11.5pt; color: #333; }
  h2 { font-size: 13pt; margin: 16pt 0 6pt; padding-bottom: 2pt;
       border-bottom: 0.7pt solid #999;
       font-family: "Microsoft YaHei", "SimHei", sans-serif;
       page-break-after: avoid; }
  h3 { font-size: 11.5pt; margin: 12pt 0 4pt;
       font-family: "Microsoft YaHei", "SimHei", sans-serif;
       page-break-after: avoid; }
  h4 { font-size: 10.5pt; margin: 10pt 0 3pt; color: #222;
       font-family: "Microsoft YaHei", "SimHei", sans-serif;
       page-break-after: avoid; }
  p  { margin: 0 0 6pt; text-align: justify; }
  table { border-collapse: collapse; width: 100%; margin: 2pt 0 10pt;
          font-size: 8.6pt; page-break-inside: avoid; }
  th, td { border: 0.5pt solid #bbb; padding: 3pt 4pt; text-align: left;
           vertical-align: top; }
  th { background: #f2f2f0; font-weight: 600; }
  img { max-width: 100%; display: block; margin: 6pt auto 10pt;
        page-break-inside: avoid; }
  code { font-family: Consolas, "Courier New", monospace; font-size: 9pt;
         background: #f5f5f3; padding: 0 2pt; border-radius: 2pt; }
  pre { background: #f5f5f3; padding: 6pt; border-radius: 3pt;
        font-size: 8.8pt; overflow-x: auto; }
  blockquote { margin: 6pt 0 6pt 0; padding: 4pt 0 4pt 8pt;
               border-left: 2.5pt solid #ccc; color: #333;
               background: #fafafa; }
  blockquote p { margin: 0 0 4pt; }
  hr { border: none; border-top: 0.5pt solid #ccc; margin: 14pt 0; }
  a { color: #14417a; text-decoration: none; }
  strong { font-weight: 700; }
</style>
</head>
<body>
__BODY__
</body>
</html>
"""


def protect_math(text):
    """Swap $...$ / $$...$$ for placeholders so Markdown cannot touch them."""
    store = []

    def stash(m):
        store.append(m.group(0))
        return f"@@MATH{len(store) - 1}@@"

    text = re.sub(r"\$\$.+?\$\$", stash, text, flags=re.S)
    text = re.sub(r"(?<!\$)\$(?!\$)(.+?)(?<!\$)\$(?!\$)", stash, text, flags=re.S)
    return text, store


def restore_math(html, store):
    for i, m in enumerate(store):
        html = html.replace(f"@@MATH{i}@@", m)
    return html


def find_chrome():
    for c in CHROME_CANDIDATES:
        if os.path.exists(c):
            return c
    raise SystemExit("no Chrome/Edge found")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--md", default="02_论文_全稿.md")
    ap.add_argument("--html", default="论文.html")
    ap.add_argument("--pdf", default="论文.pdf")
    a = ap.parse_args()

    src = io.open(a.md, encoding="utf-8").read()
    protected, store = protect_math(src)
    body = markdown.markdown(
        protected, extensions=["tables", "fenced_code", "sane_lists", "attr_list"])
    body = restore_math(body, store)

    title = src.split("\n")[0].lstrip("# ").strip()

    # local image paths -> they sit next to the HTML, so leave them relative
    html = TEMPLATE.replace("__TITLE__", title).replace("__BODY__", body)
    io.open(a.html, "w", encoding="utf-8", newline="\n").write(html)
    print(f"wrote {a.html}  ({len(html)} bytes, {len(store)} math spans)")

    chrome = find_chrome()
    html_abs = os.path.abspath(a.html)
    pdf_abs = os.path.abspath(a.pdf)
    # Chrome silently writes <name>-01.pdf when the target exists but is locked,
    # which leaves a stale manuscript behind. Clear both first.
    for stale in (pdf_abs, pdf_abs[:-4] + "-01.pdf"):
        if os.path.exists(stale):
            os.remove(stale)
    cmd = [chrome, "--headless=new", "--disable-gpu", "--no-sandbox",
           "--virtual-time-budget=30000",
           "--no-pdf-header-footer",
           f"--print-to-pdf={pdf_abs}", f"file:///{html_abs.replace(os.sep, '/')}"]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if not os.path.exists(pdf_abs):
        print(r.stdout[-2000:]); print(r.stderr[-2000:])
        raise SystemExit("PDF not produced")
    print(f"wrote {a.pdf}  ({os.path.getsize(pdf_abs)} bytes)")


if __name__ == "__main__":
    main()
