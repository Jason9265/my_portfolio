"""EuroCropsML: a clean imbalance intervention with the class set HELD FIXED.

Why the earlier version was invalid (reviewer's point, and it is correct):
  * It advertised "123-class space held constant" but the class count actually
    went 123 -> 30 -> 24 -> 18, i.e. class subset, taxonomy difficulty, class
    count and nearest-competitor structure all changed at once.
  * Worse, for every class with >=50 test parcels the official k=20 support is
    exactly 20. So changing the test population changes NOTHING about training;
    a macro-F1 rise from 0.057 to 0.398 could only mean "the retained classes
    are the easy, common ones" -- not "balancing helped the model learn".

This version fixes all of that:
  * ONE class set, fixed for every condition (classes with enough supply).
  * Imbalance is applied as a controlled geometric decay in per-class sample
    count, ratio rho in {1,5,10,50,100}.
  * Support-skew and test-skew are separated, because they test different
    mechanisms: support skew is a genuine learning effect, test skew can only
    be an estimation artifact.
  * Separability is again the non-circular NDVI-trajectory construct.
"""
import argparse
import json
import os
import warnings

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from eurocropsml_exp import BATCH, build_feats, class_profiles, macro_f1
from eurocropsml_noncircular import ndvi_trajectories, separability

# minimum supply each retained class must offer in EVERY condition
MIN_TEST = 50
MIN_SUP = 20


def skewed_counts(C, rho, base):
    """Per-class sample budget: geometric decay from base down to base/rho.

    Rank 0 (most sampled) gets `base`, the last gets `base/rho`. Used for both
    the support and the test manipulation so the two are directly comparable.
    """
    if rho <= 1:
        return np.full(C, base, dtype=int)
    frac = rho ** (-np.arange(C) / max(C - 1, 1))
    return np.maximum((base * frac).astype(int), 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--windows", default="180,240")
    ap.add_argument("--k", type=int, default=20, help="support budget (<=20)")
    ap.add_argument("--test-base", type=int, default=100)
    ap.add_argument("--rhos", default="1,5,10,50,100")
    ap.add_argument("--arms", default="balanced,support,test,both")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--out", default="results/eurocropsml_imbalance.json")
    a = ap.parse_args()

    D = np.load(a.ds, allow_pickle=True)
    n_cls = len(D["classes"])
    yt = D["test_label"]
    ys = D[f"sup{a.k}_label"]
    tst_n = np.array([(yt == c).sum() for c in range(n_cls)])
    sup_n = np.array([(ys == c).sum() for c in range(n_cls)])

    # ONE class set, fixed for every arm and every rho
    cls = [c for c in range(n_cls)
           if tst_n[c] >= max(MIN_TEST, a.test_base) and sup_n[c] >= a.k]
    C = len(cls)
    print(f"fixed class set: {C} classes "
          f"(test>={max(MIN_TEST,a.test_base)}, support>={a.k})")
    if C < 8:
        raise SystemExit("too few classes")

    out = []
    for W in [int(x) for x in a.windows.split(",")]:
        tr = ndvi_trajectories(D["test_data"], D["test_doy"], D["test_valid"])
        nb = min(int(np.ceil(W / 10)), tr.shape[1])
        prof = np.full((n_cls, nb), np.nan)
        for c in cls:
            s = yt == c
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                prof[c] = np.nanmean(tr[s][:, :nb], axis=0)
        sep = separability(prof)[cls]

        idx_t = {c: np.where(yt == c)[0] for c in cls}
        idx_s = {c: np.where(ys == c)[0] for c in cls}
        F_all = build_feats(D["test_data"], D["test_doy"], D["test_valid"], W)
        S_all = build_feats(D[f"sup{a.k}_data"], D[f"sup{a.k}_doy"],
                            D[f"sup{a.k}_valid"], W)
        Fsrc = build_feats(D["pretrain_data"], D["pretrain_doy"],
                           D["pretrain_valid"], W)

        for rho in [int(x) for x in a.rhos.split(",")]:
            for arm in a.arms.split(","):
                for seed in range(a.seeds):
                    rng = np.random.default_rng(1000 * seed + rho)
                    nt = skewed_counts(C, rho, a.test_base) \
                        if arm in ("test", "both") else np.full(C, a.test_base)
                    ns = skewed_counts(C, rho, a.k) \
                        if arm in ("support", "both") else np.full(C, a.k)
                    nt = np.minimum(nt, [len(idx_t[c]) for c in cls])
                    ns = np.minimum(ns, [len(idx_s[c]) for c in cls])

                    te, sup = [], []
                    for i, c in enumerate(cls):
                        te.extend(rng.choice(idx_t[c], nt[i], replace=False))
                        sup.extend(rng.choice(idx_s[c], ns[i], replace=False))
                    te = np.array(te); sup = np.array(sup)

                    ssel = rng.choice(len(Fsrc), min(BATCH, len(Fsrc)),
                                      replace=False)
                    mu = Fsrc[ssel].mean(0); sd = Fsrc[ssel].std(0) + 1e-8
                    clf = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
                    clf.fit(((S_all - mu) / sd)[sup], ys[sup])
                    p = clf.predict(((F_all - mu) / sd)[te])

                    _, per = macro_f1(yt[te], p, list(range(n_cls)))
                    per = np.array(per)[cls]
                    r, pv = stats.pearsonr(sep, per)
                    rho_, prho = stats.spearmanr(sep, per)
                    o = np.argsort(-sep)[1:]
                    r2, p2 = stats.pearsonr(sep[o], per[o])
                    out.append({"W": W, "rho": rho, "arm": arm, "seed": seed,
                                "n_classes": C, "r": r, "p": pv,
                                "spearman": rho_, "p_spearman": prho,
                                "drop1": r2, "p_drop1": p2,
                                "macro_f1": float(np.mean(per)),
                                "test_min": int(nt.min()), "test_max": int(nt.max()),
                                "sup_min": int(ns.min()), "sup_max": int(ns.max())})
                print(f"  W={W} rho={rho:3d} {arm:8s} done", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"))
    print(f"saved {a.out}: {len(out)} records")


if __name__ == "__main__":
    main()
