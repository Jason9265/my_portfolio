"""EuroCropsML, balanced + NON-CIRCULAR separability.

The first balanced run had a circularity: separability was computed from class
mean profiles over the SAME 13 bands the classifier was fit on. On BreizhCrops
and on the CropHarvest replication the predictor was deliberately restricted to
the NDVI channel alone, predicting the output of a full-feature classifier, so
it was not merely reading back the classifier's own geometry.

This repeats the balanced experiment with the same discipline:
  predictor  = separability of class mean NDVI TRAJECTORIES, DOY-binned
  predicted  = per-class F1 of a 65-dim (13 bands x 5 temporal statistics) readout

Still controls per-class test population (the balance manipulation).

B4 = index 3, B8 = index 7 in S2_BANDS = ["01","02",...,"08","8A","09",...].
"""
import argparse
import json
import os
import warnings

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from eurocropsml_exp import BATCH, build_feats, macro_f1
from experiment import standardize

B4, B8 = 3, 7
N_BIN = 36           # 10-day periods, matching the BreizhCrops design


def ndvi_trajectories(dat, doy, valid):
    """Class-mean NDVI trajectory per sample, binned into N_BIN 10-day periods."""
    b4 = dat[:, :, B4].astype(np.float64)
    b8 = dat[:, :, B8].astype(np.float64)
    den = b8 + b4
    with np.errstate(invalid="ignore", divide="ignore"):
        nd = np.where(den > 1e-6, (b8 - b4) / np.where(den > 1e-6, den, 1), np.nan)
    nd[~valid] = np.nan
    bin_idx = np.clip((doy.astype(np.int32) - 1) // 10, 0, N_BIN - 1)
    out = np.full((len(dat), N_BIN), np.nan)
    for b in range(N_BIN):
        m = valid & (bin_idx == b)
        arr = np.where(m, nd, np.nan)
        with np.errstate(invalid="ignore"), warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            # nanmean, not mean: a plain mean propagates NaN and would blank the
            # whole trajectory wherever a single timestep is missing
            out[:, b] = np.nanmean(arr, axis=1)
    return out


def separability(prof):
    C = len(prof); o = np.full(C, np.nan)
    for c in range(C):
        best = np.inf
        for d in range(C):
            if d == c: continue
            v = ~np.isnan(prof[c]) & ~np.isnan(prof[d])
            if v.sum() < 2: continue
            best = min(best, np.sqrt(np.mean((prof[c, v] - prof[d, v]) ** 2)))
        o[c] = best if np.isfinite(best) else np.nan
    return o


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--windows", default="180,240")
    ap.add_argument("--ks", default="5,20")
    ap.add_argument("--ns", default="50,100,200")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--out", default="results/eurocropsml_noncircular.json")
    a = ap.parse_args()

    D = np.load(a.ds, allow_pickle=True)
    n_cls = len(D["classes"])

    # NDVI trajectories are window-independent; build once
    tr_tst = ndvi_trajectories(D["test_data"], D["test_doy"], D["test_valid"])
    out = []

    for W in [int(x) for x in a.windows.split(",")]:
        nb = int(np.ceil(W / 10))          # bins covering DOY <= W
        nb = min(nb, N_BIN)
        prof = np.full((n_cls, nb), np.nan)
        yt = D["test_label"]
        for c in range(n_cls):
            s = yt == c
            if s.sum() < 10:
                continue
            with np.errstate(invalid="ignore"):
                prof[c] = np.nanmean(tr_tst[s][:, :nb], axis=0)
        sep = separability(prof)

        Fsrc_all = build_feats(D["pretrain_data"], D["pretrain_doy"],
                               D["pretrain_valid"], W)
        Ftst_all = build_feats(D["test_data"], D["test_doy"], D["test_valid"], W)
        ytst_all = yt

        for k in [int(x) for x in a.ks.split(",")]:
            ys = D[f"sup{k}_label"]
            Fs_all = build_feats(D[f"sup{k}_data"], D[f"sup{k}_doy"],
                                 D[f"sup{k}_valid"], W)
            for N in [int(x) for x in a.ns.split(",")]:
                ok_cls = [c for c in range(n_cls)
                          if (ys == c).sum() >= k and (ytst_all == c).sum() >= N
                          and np.isfinite(sep[c])]
                if len(ok_cls) < 8:
                    print(f"  W={W} k={k} N={N}: {len(ok_cls)} classes, skip")
                    continue
                for seed in range(a.seeds):
                    rng = np.random.default_rng(1000 * seed + N)
                    te, sup = [], []
                    for c in ok_cls:
                        te.extend(rng.choice(np.where(ytst_all == c)[0], N,
                                             replace=False))
                        sup.extend(rng.choice(np.where(ys == c)[0], k,
                                              replace=False))
                    te = np.array(te); sup = np.array(sup)
                    ssel = rng.choice(len(Fsrc_all), min(BATCH, len(Fsrc_all)),
                                      replace=False)
                    mu = Fsrc_all[ssel].mean(0); sd = Fsrc_all[ssel].std(0) + 1e-8
                    clf = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
                    clf.fit(((Fs_all - mu) / sd)[sup], ys[sup])
                    p = clf.predict(((Ftst_all - mu) / sd)[te])

                    _, per = macro_f1(ytst_all[te], p, list(range(n_cls)))
                    per = np.array(per)
                    x = sep[ok_cls]; f = per[ok_cls]
                    r, pv = stats.pearsonr(x, f)
                    rho, prho = stats.spearmanr(x, f)
                    o = np.argsort(-x)[1:]
                    r2, p2 = stats.pearsonr(x[o], f[o])
                    out.append({"W": W, "k": k, "N": N, "seed": seed,
                                "n_classes": len(ok_cls), "r": r, "p": pv,
                                "rho": rho, "p_rho": prho, "drop1": r2,
                                "p_drop1": p2,
                                "macro_f1": float(np.mean(f))})
                print(f"  W={W} k={k} N={N}: {len(ok_cls)} classes done",
                      flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"))
    print(f"saved {a.out}: {len(out)} records")


if __name__ == "__main__":
    main()
