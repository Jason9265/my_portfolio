#!/usr/bin/env bash
# Frozen-backbone weights via hf-mirror (huggingface.co itself is unreachable here).
set -u
cd /d/rcessay/models || exit 1
export HF_ENDPOINT=https://hf-mirror.com
M=https://hf-mirror.com
for spec in \
  "wangyi111/SSL4EO-S12/resolve/main/B13_vitb16_mae_ep99_enc.pth|ssl4eo_vitb16_b13_enc.pth" \
  "torchgeo/presto/resolve/main/model-e5e57c68.pth|presto.pth" \
  ; do
  path="${spec%%|*}"; out="${spec##*|}"
  if [ -s "$out" ]; then echo "[skip] $out"; continue; fi
  echo "[get ] $out"
  curl -sL --retry 3 -o "$out" "$M/$path" -w "       %{http_code}  %{size_download} bytes\n"
done
echo "MODELS_DONE"
