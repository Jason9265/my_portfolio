"""Third-dataset replication of the separability construct, on EuroCropsML.

This is the test that closes the paper's biggest gap: the timing hypothesis was
preregistered on BreizhCrops (19 classes), and the replacement construct was
chosen only afterwards. Here the construct is evaluated on an independent
dataset with the OFFICIAL published splits and a much larger class space
(123 classes in the support), which is both a stronger test and directly
comparable to the EuroCropsML benchmark.

Task: latvia_vs_estonia. Source = Latvia (pretrain), target = Estonia
(finetune support + test). Windows are cut by day-of-year, matching the
BreizhCrops design, since EuroCropsML ships real acquisition dates.

Two protocols:
  logreg          -- fit on the k-shot support only (matches the BreizhCrops
                     analysis, so the three datasets are on one footing)
  logreg_transfer -- fit on Latvia pretrain + the support upweighted to carry
                     comparable mass (comparable to the published benchmark,
                     which pretrains on the source region)
"""
import argparse
import collections
import json
import os

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from experiment import standardize

BATCH = 6000

# A per-class F1 estimated from a handful of test parcels is noise, and this
# dataset's class distribution is heavily skewed (30 classes hold 98.6% of the
# test samples). The separability correlation is therefore restricted to classes
# with a minimum test population, and the restriction is reported.
MIN_CLASS_TEST = 30


def build_feats(dat, doy, valid, D):
    """Temporal statistics over observations with DOY <= D.  -> (N, 13*6)."""
    m = valid & (doy <= D)
    sub = np.where(m[:, :, None], dat, np.nan)
    cnt = np.maximum(m.sum(1), 1)[:, None]
    with np.errstate(invalid="ignore"):
        mean = np.nan_to_num(np.nansum(sub, 1)) / cnt
        sq = np.nan_to_num(np.nansum(sub ** 2, 1)) / cnt
    std = np.sqrt(np.maximum(sq - mean ** 2, 0))
    big = np.where(m[:, :, None], dat, -np.inf)
    sml = np.where(m[:, :, None], dat, np.inf)
    mx = np.where(np.isfinite(big).any(1), big.max(1), 0.0)
    mn = np.where(np.isfinite(sml).any(1), sml.min(1), 0.0)
    t = np.arange(dat.shape[1], dtype=np.float32)[None, :]
    tt = np.where(m, t, np.nan)
    tb = np.nanmean(tt, axis=1, keepdims=True)
    tv = np.nanmean((tt - tb) ** 2, axis=1, keepdims=True)
    with np.errstate(invalid="ignore"):
        slope = np.nan_to_num(
            np.nanmean((tt - tb)[:, :, None] * np.where(m[:, :, None], dat, np.nan),
                       axis=1)
            / np.maximum(tv, 1e-6))
    # No per-band coverage term: EuroCropsML observes all 13 bands together,
    # so coverage is a per-sample scalar and would contribute 13 identical
    # columns. Features are therefore 13 bands x 5 temporal statistics = 65.
    return np.nan_to_num(np.concatenate([mean, std, mn, mx, slope], 1)).astype(np.float32)


def macro_f1(y, p, classes):
    f1 = []
    for c in classes:
        tp = ((p == c) & (y == c)).sum(); fp = ((p == c) & (y != c)).sum()
        fn = ((p != c) & (y == c)).sum()
        if tp == 0:
            f1.append(0.0); continue
        pr = tp / (tp + fp + 1e-12); rc = tp / (tp + fn + 1e-12)
        f1.append(2 * pr * rc / (pr + rc + 1e-12))
    return float(np.mean(f1)), [float(x) for x in f1]


def class_profiles(dat, doy, valid, label, D, n_classes):
    m = valid & (doy <= D)
    sub = np.where(m[:, :, None], dat, np.nan)
    prof = np.full((n_classes, dat.shape[2]), np.nan)
    for c in range(n_classes):
        s = label == c
        if s.sum() < MIN_CLASS_TEST:
            continue
        with np.errstate(invalid="ignore"):
            prof[c] = np.nanmean(sub[s], axis=(0, 1))
    return prof


def separability(prof):
    C = len(prof); out = np.full(C, np.nan)
    for c in range(C):
        best = np.inf
        for d in range(C):
            if d == c: continue
            v = ~np.isnan(prof[c]) & ~np.isnan(prof[d])
            if v.sum() < 2: continue
            best = min(best, np.sqrt(np.mean((prof[c, v] - prof[d, v]) ** 2)))
        out[c] = best if np.isfinite(best) else np.nan
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--windows", default="120,180,240,300,365")
    ap.add_argument("--ks", default="1,5,10,20")
    ap.add_argument("--out", default="results/eurocropsml.json")
    a = ap.parse_args()

    d = np.load(a.ds, allow_pickle=True)
    n_cls = len(d["classes"])
    ks = [int(x) for x in a.ks.split(",")]
    runs = []

    for D in [int(x) for x in a.windows.split(",")]:
        # Subsample the source FIRST: build_feats on all 170k padded series
        # would allocate several 1.3 GB temporaries, and the transfer fit only
        # ever uses BATCH of them.
        rng0 = np.random.default_rng(0)
        ssel = rng0.choice(len(d["pretrain_label"]),
                           min(BATCH, len(d["pretrain_label"])), replace=False)
        Fsrc = build_feats(d["pretrain_data"][ssel], d["pretrain_doy"][ssel],
                           d["pretrain_valid"][ssel], D)
        ysrc = d["pretrain_label"][ssel]
        Ftst = build_feats(d["test_data"], d["test_doy"], d["test_valid"], D)
        ytst = d["test_label"]
        # standardise on the (subsampled) source's statistics
        _, Ftst_s = standardize(Fsrc, Ftst)
        Fsrc_s, _ = standardize(Fsrc, Fsrc)

        prof = class_profiles(d["test_data"], d["test_doy"], d["test_valid"],
                              ytst, D, n_cls)
        sep = separability(prof)

        for k in ks:
            Fs = build_feats(d[f"sup{k}_data"], d[f"sup{k}_doy"],
                             d[f"sup{k}_valid"], D)
            ys = d[f"sup{k}_label"]
            # standardise support with the same source statistics
            _, Fs_s = standardize(Fsrc, Fs)

            # The official split is FIXED, so there is no support-set sampling
            # variance to average over (unlike the CropHarvest/BreizhCrops runs,
            # where we drew the support ourselves). A single pass is therefore
            # the honest design here, not a seed loop over an identical input.
            for seed in range(1):
                rng = np.random.default_rng(seed)
                # --- support-only readout (matches the BreizhCrops analysis)
                clf = LogisticRegression(max_iter=1000, C=1.0, n_jobs=-1)
                clf.fit(Fs_s, ys)
                p_sup = clf.predict(Ftst_s)

                # --- transfer: source + support upweighted
                Xa, ya = Fsrc_s, ysrc
                w = len(Xa) / max(len(Fs_s), 1)
                Xj = np.vstack([Xa, Fs_s])
                yj = np.concatenate([ya, ys])
                sw = np.concatenate([np.ones(len(Xa)), np.full(len(Fs_s), w)])
                clf2 = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
                clf2.fit(Xj, yj, sample_weight=sw)
                p_tr = clf2.predict(Ftst_s)

                for name, p in (("logreg", p_sup), ("logreg_transfer", p_tr)):
                    mf, per = macro_f1(ytst, p, list(range(n_cls)))
                    runs.append({"w": D, "k": k, "seed": seed, "method": name,
                                 "oa": float((p == ytst).mean()),
                                 "macro_f1": mf, "per_class_f1": per,
                                 "sep": [None if np.isnan(x) else float(x) for x in sep]})
            print(f"  D={D:3d} k={k:2d} done ({len(runs)})", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump({"runs": runs, "classes": [str(c) for c in d["classes"]]},
              open(a.out, "w"))
    print(f"saved {a.out}: {len(runs)} runs")


if __name__ == "__main__":
    main()
