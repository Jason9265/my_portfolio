"""Figure 3: the per-sample phenological-misalignment analysis.

Region-level correlation had n=6 and no power. At the per-sample level (N up to
10.8k per cell) the question is answerable -- and the within-class control matters:
in two regions the raw correlation is entirely a class-composition artifact.

Palette: single-hue marks with direct region labels (identity is never colour-alone,
and a 6-series scatter would break the <=3 all-pairs slot limit).
"""
import collections
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

from figures import AXIS, GRID, INK, INK2, MUTED, SURFACE, K_RAMP

# Validated categorical order (dataviz reference palette, adjacent pairlist ->
# 8 slots max). Assigned by FIXED slot index, never cycled: with 6 regions a
# K_RAMP[j % 4] would repaint martinique with canada's hue. Slots 3-5 (aqua,
# yellow, magenta) sit below 3:1 on this surface, so the relief rule applies --
# every series carries a visible direct label.
from figures import CAT3  # noqa: E402  (validated first three slots)
CAT6 = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]
REGION_ORDER = ["canada", "ile-de-france", "jecam:africa",
                "jecam:south_america", "martinique-france", "reunion-france"]
REGION_COLOR = {r: CAT6[i] for i, r in enumerate(REGION_ORDER)}


def main():
    rec = json.load(open("results/per_sample.json"))
    by = collections.defaultdict(list)
    for r in rec:
        by[(r["region"], r["w"])].append(r)

    regions = sorted({r["region"] for r in rec})
    ws = sorted({r["w"] for r in rec})

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(13.6, 4.0))

    # ---- panel A: trajectory of (coverage, accuracy) as w grows ----------
    for ax in (ax1, ax2, ax3):
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, alpha=1.0, zorder=0, color=GRID)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=8)

    for reg in regions:
        pts = [(np.mean([x["cov"] for x in by[(reg, w)]]),
                np.mean([x["acc"] for x in by[(reg, w)]]), w)
               for w in ws if (reg, w) in by]
        if not pts:
            continue
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        c = REGION_COLOR.get(reg, MUTED)
        ax1.plot(xs, ys, color=c, lw=2, zorder=3, alpha=0.9)
        ax1.scatter(xs, ys, s=52, color=c, edgecolor=SURFACE, linewidth=1.6,
                    zorder=4)
        ax1.annotate(reg, (xs[-1], ys[-1]), textcoords="offset points",
                     xytext=(6, -2), fontsize=7.2, color=INK2, ha="left")
    ax1.set_xlabel("mean fraction of the sample's growing season observed",
                   fontsize=8.5)
    ax1.set_ylabel("mean per-sample accuracy (k=20)", fontsize=8.5)
    ax1.set_title("A  window growth moves regions along coverage/accuracy",
                  fontsize=9.5, color=INK, loc="left", pad=6)
    ax1.set_xlim(-0.03, 1.22)

    # ---- panels B & C: correlation with w, raw vs class-controlled --------
    # Per-w curves with direct labels instead of one bar per (region, w): 31
    # stacked tick labels collide badly.
    curves = {}
    for reg in regions:
        raw_c, within_c = [], []
        for w in ws:
            if (reg, w) not in by or w == max(ws):
                raw_c.append(np.nan); within_c.append(np.nan); continue
            v = by[(reg, w)]
            cov = np.array([x["cov"] for x in v])
            acc = np.array([x["acc"] for x in v])
            cls = np.array([x["cls"] for x in v])
            if cov.std() < 1e-9:
                raw_c.append(np.nan); within_c.append(np.nan); continue
            cd, ad = np.zeros_like(cov), np.zeros_like(acc)
            for c in np.unique(cls):
                m = cls == c
                if m.sum() < 5:
                    continue
                cd[m] = cov[m] - cov[m].mean()
                ad[m] = acc[m] - acc[m].mean()
            raw_c.append(stats.pearsonr(cov, acc)[0])
            within_c.append(stats.pearsonr(cd, ad)[0])
        curves[reg] = (np.array(raw_c), np.array(within_c))

    for ax, idx, title in ((ax2, 0, "B  raw correlation"),
                           (ax3, 1, "C  within-class controlled")):
        ends = []
        for reg in regions:
            y = curves[reg][idx]
            m = ~np.isnan(y)
            if m.sum() == 0:
                continue
            c = REGION_COLOR.get(reg, MUTED)
            ax.plot(np.array(ws)[m], y[m], color=c, lw=2, marker="o", ms=7,
                    mfc=c, mec=SURFACE, mew=1.8, zorder=3)
            ends.append((y[m][-1], reg))
        # push apart end labels that would overprint
        ends.sort()
        for i in range(1, len(ends)):
            if ends[i][0] - ends[i - 1][0] < 0.035:
                ends[i] = (ends[i - 1][0] + 0.035, ends[i][1])
        for yv, reg in ends:
            ax.annotate(reg, (max(ws) - 2, yv), textcoords="offset points",
                        xytext=(6, 0), fontsize=6.8, color=INK2,
                        va="center", ha="left")
        ax.axhline(0, color=AXIS, lw=1.2, zorder=2)
        ax.set_xticks(ws)
        ax.set_xlim(min(ws) - 0.4, max(ws) + 5.0)
        ax.set_ylim(-0.16, 0.42)
        ax.set_xlabel("window w (months)", fontsize=8.5)
        ax.set_title(title, fontsize=9.5, color=INK, loc="left", pad=6)
    ax2.set_ylabel("Pearson r:  coverage vs accuracy", fontsize=8.5)
    ax2.grid(True, axis="y", alpha=1.0, zorder=0, color=GRID)
    ax2.grid(False, axis="x")

    fig.tight_layout()
    fig.savefig("figs/fig6_coverage.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig6_coverage.png")


if __name__ == "__main__":
    main()
