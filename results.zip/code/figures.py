"""Figures for the k x w interaction study.

Palette is the dataviz reference instance, validated with scripts/validate_palette.js:
  - k is an ORDERED quantity -> ordinal single-hue blue ramp (NOT categorical hues).
    light: #86b6ef #5598e7 #2a78d6 #184f95   (monotone lightness, dL>=0.06,
    light-end contrast 2.06:1, hue spread 3deg)  => ok
  - categorical slots 1-3 (all-pairs validated) for region comparisons; aqua
    #1baf7a is 2.74:1 on the light surface, so those marks carry direct labels
    (the relief rule).
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# --- palette (validated) -------------------------------------------------
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
K_RAMP = ["#86b6ef", "#5598e7", "#2a78d6", "#184f95"]   # k = 1,5,10,20
CAT3 = ["#2a78d6", "#eb6834", "#1baf7a"]

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Segoe UI", "Arial"],
    "axes.edgecolor": AXIS, "axes.linewidth": 0.8,
    "axes.labelcolor": INK2, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED,
    "xtick.labelcolor": INK2, "ytick.labelcolor": INK2,
    "grid.color": GRID, "grid.linewidth": 0.8,
    "legend.frameon": False, "figure.dpi": 160,
})


def _clean(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, axis="y", alpha=1.0, zorder=0)
    ax.set_axisbelow(True)


def load_agg(path="results/agg.json"):
    raw = json.load(open(path))
    out = {}
    for k, v in raw.items():
        # keys were stringified tuples: "('region', 12, 1, 'proto')"
        t = eval(k)
        out[t] = v
    return out


def fig_kxw(A, method="logreg_transfer", metric_lo=0.0, out="figs/fig8_kxw.png"):
    """Small multiples: macro-F1 vs window length, one line per label budget k."""
    regions = sorted({t[0] for t in A})
    ws = sorted({t[1] for t in A})
    ks = sorted({t[2] for t in A})
    n = len(regions)
    ncol = 3
    nrow = (n + ncol - 1) // ncol
    fig, axes = plt.subplots(nrow, ncol, figsize=(3.4 * ncol, 2.7 * nrow),
                             sharey=True)
    axes = np.atleast_2d(axes)

    for i, r in enumerate(regions):
        ax = axes[i // ncol][i % ncol]
        _clean(ax)
        for j, k in enumerate(ks):
            ys, errs = [], []
            for w in ws:
                v = A.get((r, w, k, method))
                ys.append(v["mean"] if v else np.nan)
                errs.append(1.96 * v["se"] if v else np.nan)
            c = K_RAMP[j % len(K_RAMP)]
            ax.errorbar(ws, ys, yerr=errs, color=c, lw=2, marker="o",
                        ms=8, mfc=c, mec=SURFACE, mew=2, capsize=0,
                        elinewidth=1.2, alpha=0.95, zorder=3,
                        label=f"k={k}" if i == 0 else None)
            # Direct-label only the extremes: labelling all four collides where
            # the k curves converge. k=1 (lightest ramp step, 2.06:1 on this
            # surface) must carry a visible label per the relief rule.
            if j in (0, len(ks) - 1):
                ax.annotate(f"k={k}", (ws[-1], ys[-1]),
                            textcoords="offset points", xytext=(7, 0),
                            fontsize=7.5, color=INK2, va="center", ha="left")
        ax.set_title(r, fontsize=9.5, color=INK, pad=6, loc="left")
        ax.set_xticks(ws)
        ax.set_xlim(min(ws) - 0.5, max(ws) + 1.6)
        if i // ncol == nrow - 1:
            ax.set_xlabel("observation window w (months)", fontsize=8.5)
        if i % ncol == 0:
            ax.set_ylabel("macro-F1", fontsize=8.5)
        ax.tick_params(labelsize=8)

    for j in range(n, nrow * ncol):
        axes[j // ncol][j % ncol].axis("off")

    axes[0][0].legend(fontsize=8, loc="upper left", handlelength=1.6,
                      labelspacing=0.3)
    fig.suptitle(f"Label budget x observation window  ({method})",
                 fontsize=11, color=INK, x=0.01, ha="left", y=0.995)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("wrote", out)


def fig_region_penalty(A, method="logreg_transfer", k=20,
                       out="figs/fig9_region_early_full.png"):
    """Early vs full observation window, per region (descriptive).

    Deliberately does NOT plot the region-level phenology-vs-penalty correlation:
    with n=6 regions nothing there reaches significance (|r|>0.81 required), so
    drawing it would invite over-reading. The phenology question is tested at the
    per-sample level instead -- see fig3.
    """
    regions = sorted({t[0] for t in A})
    ws = sorted({t[1] for t in A})
    rows = []
    for r in regions:
        lo, hi = A.get((r, min(ws), k, method)), A.get((r, max(ws), k, method))
        if not (lo and hi):
            continue
        rows.append((r, lo["mean"], hi["mean"], hi["mean"] - lo["mean"]))
    if not rows:
        print("no rows"); return

    rows.sort(key=lambda r: r[1])
    fig, ax = plt.subplots(figsize=(6.6, 3.6))
    _clean(ax)
    yy = np.arange(len(rows))
    h = 0.38
    ax.barh(yy - h / 2, [r[1] for r in rows], height=h, color=K_RAMP[0],
            label=f"w={min(ws)} mo (early)", zorder=3)
    ax.barh(yy + h / 2, [r[2] for r in rows], height=h, color=K_RAMP[3],
            label=f"w={max(ws)} mo (full)", zorder=3)
    for i, r in enumerate(rows):
        # direct value labels: the delta is the point of the chart
        ax.annotate(f"+{r[3]:.3f}", (r[2], yy[i] + h / 2),
                    textcoords="offset points", xytext=(4, 0), fontsize=7.5,
                    color=INK2, va="center", ha="left")
    ax.set_yticks(yy)
    ax.set_yticklabels([r[0] for r in rows], fontsize=8)
    ax.set_xlabel("macro-F1", fontsize=8.5)
    ax.set_xlim(0, max(r[2] for r in rows) * 1.16)
    ax.set_title(f"gain from a longer observation window (k={k}, {method})",
                 fontsize=9.5, color=INK, loc="left", pad=6)
    ax.legend(fontsize=8, loc="lower right")
    ax.grid(True, axis="x", alpha=1.0, zorder=0)
    ax.grid(False, axis="y")
    ax.tick_params(labelsize=8)

    fig.tight_layout()
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("wrote", out)


if __name__ == "__main__":
    A = load_agg()
    fig_kxw(A)
    fig_region_penalty(A)
