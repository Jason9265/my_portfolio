"""L2b: frozen Presto on CropHarvest's RAW Sentinel-1/2 time series.

This is the confirmatory test of the hypothesis in results section 4.4/4.7:
the small pretraining gain on pre-aggregated features (+0.031) should be much
larger on raw time series, because aggregation compresses away the structure
pretraining exploits.

Raw data format (verified against the official cropharvest source and by
inspecting a real file):
  eo_data/<index>-<dataset>_<start>_<end>.tif
  array (206, H, W) = [12 timesteps x 17 dynamic bands] + [2 static bands]
  dynamic order: VV, VH, B1..B12, temperature_2m, total_precipitation
  static:        elevation, slope
  DAYS_PER_TIMESTEP = 30, DEFAULT_NUM_TIMESTEPS = 12  -> monthly, calendar-aligned
  missing values are NaN

Presto needs 17 channels. We take 16 of the tif's 19 bands (dropping B1, B9, B10)
and compute NDVI from B8/B4.
"""
import argparse
import glob
import json
import os
import time
import warnings

import numpy as np
import torch

from extract_l2 import build_random_encoder
from single_file_presto import BANDS_GROUPS_IDX
from presto_features import NORMED_BANDS, build_encoder

# tif dynamic-band layout (17 per timestep)
TIF_DYN = (["VV", "VH"]
           + ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B8A", "B9",
              "B10", "B11", "B12"]
           + ["temperature_2m", "total_precipitation"])
N_T, N_DYN, N_STATIC = 12, 17, 2

# Presto normalisation (from presto_ref/s1_s2_era5_srtm.py)
SHIFT = {"VV": 25.0, "VH": 25.0, "temperature_2m": -272.15}
DIV = {"VV": 25.0, "VH": 25.0, "temperature_2m": 35.0,
       "total_precipitation": 0.03, "elevation": 2000.0, "slope": 50.0}


def read_sample(path):
    """-> (12, 19) spatial-mean time series, or None if unreadable.

    Channels: the 17 dynamic bands followed by elevation, slope. Spatial
    aggregation is the mean over finite pixels, matching how CropHarvest's own
    precomputed features were reduced from these same chips.
    """
    import rasterio
    try:
        with rasterio.open(path) as src:
            a = src.read().astype(np.float32)
    except Exception:
        return None
    if a.shape[0] != N_T * N_DYN + N_STATIC:
        return None
    dyn = a[:N_T * N_DYN].reshape(N_T, N_DYN, -1)
    sta = a[N_T * N_DYN:]
    with warnings.catch_warnings(), np.errstate(invalid="ignore"):
        warnings.simplefilter("ignore", RuntimeWarning)
        dyn_m = np.nanmean(dyn, axis=2)
        sta_m = np.array([np.nanmean(s) for s in sta], dtype=np.float32)
    out = np.concatenate([dyn_m, sta_m[None, :].repeat(N_T, 0)], axis=1)
    return out.astype(np.float32)


def to_presto(series, w):
    """(T,19) raw -> (w,17) Presto channels and (w,17) mask (1 = missing)."""
    sub = series[:w]
    x = np.zeros((w, len(NORMED_BANDS)), dtype=np.float32)
    m = np.ones((w, len(NORMED_BANDS)), dtype=np.float32)

    for name in NORMED_BANDS:
        if name == "NDVI":
            continue
        if name in TIF_DYN:
            col = TIF_DYN.index(name)
        elif name == "elevation":
            col = N_DYN
        elif name == "slope":
            col = N_DYN + 1
        else:
            continue                       # absent (shouldn't happen)
        v = sub[:, col]
        shift = SHIFT.get(name, 0.0)
        div = DIV.get(name, 1e4 if name.startswith("B") else 1.0)
        x[:, NORMED_BANDS.index(name)] = (v + shift) / div
        m[:, NORMED_BANDS.index(name)] = (~np.isfinite(v)).astype(np.float32)

    b4 = sub[:, TIF_DYN.index("B4")]
    b8 = sub[:, TIF_DYN.index("B8")]
    den = b8 + b4
    ok = np.isfinite(den) & (den > 1e-6)
    nd = np.where(ok, (b8 - b4) / np.where(ok, den, 1), 0.0)
    ni = NORMED_BANDS.index("NDVI")
    x[:, ni] = nd
    m[:, ni] = 1.0 - ok.astype(np.float32)
    return np.nan_to_num(x), m


def token_mask_count(ms, w):
    """Masked-token count per sample, replicating Encoder's group masking.

    mask_tokens asserts that every item in a batch has an equal number of masked
    *tokens*, not masked input cells. Two things make those differ:
      * a group is masked if ANY of its channels is masked
        (torch.max over the group's channel indices), and
      * SRTM collapses to a SINGLE token rather than one per timestep.
    Bucketing on the raw cell count (my first attempt) therefore still tripped
    the assert. This reproduces the encoder's arithmetic exactly.
    """
    counts = np.full(len(ms), w, dtype=np.int64)   # dynamic_world: always masked
    for group, idxs in BANDS_GROUPS_IDX.items():
        g = ms[:, :, idxs].max(axis=2)             # (N, w) group-level mask
        if group == "SRTM":
            counts += g[:, 0].astype(np.int64)     # single token
        else:
            counts += g.sum(axis=1).astype(np.int64)
    return counts


@torch.no_grad()
def extract(enc, arr, w, batch=128, device="cuda", month=1):
    """Frozen embeddings for a list of (12,19) series; batched by token-mask count."""
    N = len(arr)
    xs = np.zeros((N, w, len(NORMED_BANDS)), dtype=np.float32)
    ms = np.zeros((N, w, len(NORMED_BANDS)), dtype=np.float32)
    for i, s in enumerate(arr):
        xs[i], ms[i] = to_presto(s, w)

    out = np.zeros((N, 128), dtype=np.float32)
    counts = token_mask_count(ms, w)
    order = np.argsort(counts, kind="stable")
    cs = counts[order]
    starts = np.flatnonzero(np.r_[True, cs[1:] != cs[:-1]])
    ends = np.r_[starts[1:], len(order)]
    for s, e in zip(starts, ends):
        idx_all = order[s:e]
        for i in range(0, len(idx_all), batch):
            idx = idx_all[i:i + batch]
            xb = torch.from_numpy(xs[idx]).to(device)
            mb = torch.from_numpy(ms[idx]).to(device)
            dw = torch.full((len(idx), w), 9, dtype=torch.long, device=device)
            lb = torch.zeros((len(idx), 2), dtype=torch.float32, device=device)
            out[idx] = enc(x=xb, dynamic_world=dw, latlons=lb, mask=mb,
                           month=month, eval_task=True).float().cpu().numpy()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tif-dir", default="data/eo_extract/eo_data")
    ap.add_argument("--windows", default="2,4,6,8,10,12")
    ap.add_argument("--cache", default="data/raw_series.npy")
    ap.add_argument("--out", default="data/l2b_presto.npz")
    a = ap.parse_args()

    d = np.load("data/ds_cropharvest.npz", allow_pickle=True)
    y, region = d["y"], d["region"]
    meta = json.load(open("data/meta_cropharvest.json"))
    classes = set(d["classes"])
    keep = [m for m in meta
            if m.get("crop_type") not in (None, "non_crop")
            and m.get("crop_type") in classes]
    assert len(keep) == len(y)

    if os.path.exists(a.cache):
        arr = np.load(a.cache)
        print(f"loaded cached raw series {arr.shape}")
    else:
        # map "<index>-<dataset>" -> row in our filtered arrays.
        # Dataset names contain hyphens but never underscores, so splitting the
        # stem on '_' cleanly separates it from the date suffix.
        key2row = {}
        for i, m in enumerate(keep):
            key2row[f"{m['index']}-{m['dataset']}"] = i
        allf = glob.glob(os.path.join(a.tif_dir, "*.tif"))
        # Two on-disk filename forms exist:
        #   <index>-<dataset>_<start>_<end>.tif   (most datasets)
        #   <index>-<dataset>.tif                  (jecam, china-crop, ...)
        # So strip the extension BEFORE splitting on "_", otherwise the
        # short form yields "<dataset>.tif" and silently matches nothing.
        files = [f for f in allf
                 if os.path.basename(f)[:-4].split("_")[0] in key2row]
        print(f"tif files: {len(allf)}  matching our rows: {len(files)}  "
              f"expected rows: {len(keep)}", flush=True)
        arr3d = np.zeros((len(keep), N_T, 19), dtype=np.float32)
        got = 0
        t0 = time.time()
        for n, f in enumerate(files):
            stem = os.path.basename(f)[:-4].split("_")[0]
            row = key2row.get(stem)
            if row is None:
                continue
            s = read_sample(f)
            if s is None:
                continue
            arr3d[row] = s
            got += 1
            if n and n % 20000 == 0:
                print(f"  {n}/{len(files)}  matched={got}  "
                      f"{time.time()-t0:.0f}s", flush=True)
        print(f"matched {got}/{len(keep)} samples")
        arr = arr3d
        np.save(a.cache, arr)

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    enc = build_encoder(device=dev)
    rnd = build_random_encoder(seed=0, device=dev)
    out = {}
    for w in [int(x) for x in a.windows.split(",")]:
        t0 = time.time()
        out[f"presto_w{w}"] = extract(enc, arr, w, device=dev)
        out[f"random_w{w}"] = extract(rnd, arr, w, device=dev)
        print(f"  w={w:2d} extracted in {time.time()-t0:.0f}s", flush=True)
    np.savez_compressed(a.out, **out)
    print("saved", a.out)


if __name__ == "__main__":
    main()
