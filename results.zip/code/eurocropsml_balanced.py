"""EuroCropsML, balanced re-run: is class IMBALANCE what breaks the construct?

The post-hoc ablation (restricting the correlation to better-populated classes)
suggested imbalance rather than class-space granularity is the culprit, but it
was achieved by subsetting a correlation -- a reviewer can call that cherry
picking. This runs it as a real experiment instead.

Design: keep the full 123-class label space, but CONTROL the per-class test
population to a fixed N (and keep only classes that can sustain N test parcels
and a full k-shot support). Then re-fit and re-measure. If the construct
recovers once balance is imposed, imbalance is the mechanism; if it does not,
granularity is.

The test-set subsample is redrawn across several seeds so the result is not an
artefact of one particular draw.
"""
import argparse
import json
import os

import numpy as np
from scipy import stats
from sklearn.linear_model import LogisticRegression

from eurocropsml_exp import BATCH, build_feats, class_profiles, macro_f1, separability
from experiment import standardize


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="data/ds_eurocropsml.npz")
    ap.add_argument("--windows", default="180,240")
    ap.add_argument("--ks", default="5,20")
    ap.add_argument("--ns", default="50,100,200", help="per-class test population")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--out", default="results/eurocropsml_balanced.json")
    a = ap.parse_args()

    D = np.load(a.ds, allow_pickle=True)
    n_cls = len(D["classes"])
    out = []

    for W in [int(x) for x in a.windows.split(",")]:
        Fsrc_all = build_feats(D["pretrain_data"], D["pretrain_doy"],
                               D["pretrain_valid"], W)
        Ftst_all = build_feats(D["test_data"], D["test_doy"],
                               D["test_valid"], W)
        ytst_all = D["test_label"]

        for k in [int(x) for x in a.ks.split(",")]:
            ys = D[f"sup{k}_label"]
            Fs_all = build_feats(D[f"sup{k}_data"], D[f"sup{k}_doy"],
                                 D[f"sup{k}_valid"], W)

            for N in [int(x) for x in a.ns.split(",")]:
                # classes able to sustain BOTH an exact k-shot support and N test
                ok_cls = []
                for c in range(n_cls):
                    if (ys == c).sum() >= k and (ytst_all == c).sum() >= N:
                        ok_cls.append(c)
                if len(ok_cls) < 8:
                    print(f"  W={W} k={k} N={N}: only {len(ok_cls)} classes, skip")
                    continue

                # separability from the FULL test set's class profiles
                prof = class_profiles(D["test_data"], D["test_doy"],
                                      D["test_valid"], ytst_all, W, n_cls)
                sep = separability(prof)

                for seed in range(a.seeds):
                    rng = np.random.default_rng(1000 * seed + N)
                    te_idx = []
                    sup_idx = []
                    for c in ok_cls:
                        pool = np.where(ytst_all == c)[0]
                        te_idx.extend(rng.choice(pool, N, replace=False))
                        sp = np.where(ys == c)[0]
                        sup_idx.extend(rng.choice(sp, k, replace=False))
                    te_idx = np.array(te_idx); sup_idx = np.array(sup_idx)

                    # ONE set of scaling statistics (from the source subsample)
                    # applied to source, support and test alike; scaling them
                    # with their own statistics would put them on different
                    # scales and silently corrupt the readout.
                    ssel = rng.choice(len(Fsrc_all), min(BATCH, len(Fsrc_all)),
                                      replace=False)
                    mu = Fsrc_all[ssel].mean(0)
                    sd = Fsrc_all[ssel].std(0) + 1e-8
                    Fsrc_s = (Fsrc_all[ssel] - mu) / sd
                    Ftst_s = (Ftst_all - mu) / sd
                    Fs_s = (Fs_all - mu) / sd

                    yq = ytst_all[te_idx]
                    clf = LogisticRegression(max_iter=1500, C=1.0, n_jobs=-1)
                    clf.fit(Fs_s[sup_idx], ys[sup_idx])
                    p = clf.predict(Ftst_s[te_idx])

                    _, per = macro_f1(yq, p, list(range(n_cls)))
                    per = np.array(per)
                    x = sep[ok_cls]; f = per[ok_cls]
                    m = np.isfinite(x)
                    if m.sum() < 8:
                        continue
                    xx, ff = x[m], f[m]
                    r, pv = stats.pearsonr(xx, ff)
                    rho, prho = stats.spearmanr(xx, ff)
                    o = np.argsort(-xx)[1:]
                    r2, p2 = stats.pearsonr(xx[o], ff[o])
                    out.append({"W": W, "k": k, "N": N, "seed": seed,
                                "n_classes": int(m.sum()), "r": r, "p": pv,
                                "rho": rho, "p_rho": prho, "drop1": r2,
                                "p_drop1": p2,
                                "macro_f1": float(np.mean(ff))})
                print(f"  W={W} k={k} N={N}: {len(ok_cls)} classes, "
                      f"{a.seeds} seeds done", flush=True)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(out, open(a.out, "w"))
    print(f"saved {a.out}: {len(out)} records")


if __name__ == "__main__":
    main()
