"""H_timing tested against a FAMILY of phenological metrics, each checked for
outlier robustness.

The reviewer's point: the paper claims "phenological timing does not predict
difficulty" while testing only NDVI-peak DOY. Green-up onset, peak and centre of
mass are different events and can rank crops differently.

Detector notes (learned from the first attempt):
  * The BreizhCrops NDVI composites have a spurious near-zero first bin (DOY 5).
    A naive threshold detector therefore fires at bin 0-1 for every class and
    SOS degenerates to a constant. The first LEAD_DROP bins are excluded.
  * Winter-cereal trajectories are double-peaked (green in spring, senescence
    dip, then a harvest-driven second rise), so "first crossing" and "maximum"
    need to be treated separately.

Every metric is reported with pearson / spearman / drop-one-out so that a
metric reaching significance only through a single class cannot pass unnoticed.
"""
import json
import sys
import warnings

import numpy as np
from scipy import stats

sys.path.insert(0, "code")
from breizh_exp import load  # noqa: E402

BIN = 10
LEAD_DROP = 3
W = 24


def metrics(prof):
    p = np.asarray(prof, dtype=float)
    v = p.copy()
    v[:LEAD_DROP] = np.nan
    ok = ~np.isnan(v)
    if ok.sum() < 6:
        return None
    base = np.nanpercentile(v, 10)
    amp = np.nanpercentile(v, 90) - base
    if amp < 0.05:
        return None
    out = {}
    out["peak"] = int(np.nanargmax(v)) * BIN + BIN // 2

    w = np.nan_to_num(v, nan=0.0)
    out["centre"] = float(np.nansum(np.arange(len(v)) * w) / max(w.sum(), 1e-9)) * BIN + BIN // 2

    d = np.diff(v)
    out["maxrise"] = int(np.nanargmax(d)) * BIN + BIN // 2      # steepest green-up

    for tag, frac in (("SOS20", 0.20), ("SOS50", 0.50)):
        thr = base + frac * amp
        found = None
        for b in range(len(v) - 1):
            if ok[b] and ok[b + 1] and v[b] > thr and v[b + 1] > thr:
                found = b
                break
        out[tag] = float("nan") if found is None else found * BIN + BIN // 2
        if tag == "SOS20":
            out["gslope"] = (float(np.nanmean(d[found:found + 3]))
                             if found is not None else float("nan"))
    return out


def main():
    bz = json.load(open("results/breizh.json"))
    br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys])
    n = len(keep)
    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])

    met = {c: metrics(prof[c]) for c in range(n)}
    met = {c: m for c, m in met.items() if m}
    f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                            if r["w"] == W and r["method"] == "logreg"
                            and r["k"] == 20]) for c in range(n)])

    print(f"H_timing family (BreizhCrops, w={W}, k=20)  --  outlier robustness included")
    print(f"{'metric':>9}{'n':>4}{'pearson':>10}{'p':>9}{'spearman':>10}{'p':>9}{'DROP1':>9}{'p':>9}{'verdict':>10}")
    rows = []
    for name in ("peak", "SOS20", "SOS50", "maxrise", "gslope", "centre"):
        cs = [c for c in met if np.isfinite(met[c].get(name, np.nan))
              and np.isfinite(f1[c]) and f1[c] > 0]
        if len(cs) < 6:
            print(f"{name:>9}{len(cs):4d}   too few"); continue
        x = np.array([met[c][name] for c in cs]); yy = np.array([f1[c] for c in cs])
        r, p = stats.pearsonr(x, yy); rho, pr = stats.spearmanr(x, yy)
        o = np.argsort(-np.abs(x - x.mean()))[1:]
        r2, p2 = stats.pearsonr(x[o], yy[o])
        robust = (p < 0.05) and (pr < 0.05) and (p2 < 0.05)
        verdict = "SURVIVES" if robust else "fails"
        print(f"{name:>9}{len(cs):4d}{r:+10.3f}{p:9.4f}{rho:+10.3f}{pr:9.4f}{r2:+9.3f}{p2:9.4f}{verdict:>10}")
        rows.append({"metric": name, "n": len(cs), "pearson": r, "p": p,
                     "spearman": rho, "p_spearman": pr, "drop1": r2, "p_drop1": p2,
                     "robust": bool(robust)})
    json.dump(rows, open("results/timing_family.json", "w"))
    n_robust = sum(r["robust"] for r in rows)
    print()
    print(f"metrics surviving all three checks: {n_robust}/{len(rows)}")


if __name__ == "__main__":
    main()
