"""Fig. 2 -- the figure the reviewer singled out.

Shows why "late peak" does NOT mean "hard": maize peaks latest yet is among the
easiest classes at short windows, because at that time the winter cereals have
closed canopy while maize fields are still bare soil. Absence of greenness is
itself a discriminative signal.

Panel A: class-mean NDVI trajectories (winter cereals vs maize vs grass).
Panel B: per-class F1 against peak DOY -- the naive expectation (later = harder)
         and what is actually observed.

Palette: validated reference instance. Series are an unordered set of three
groups, so categorical slots 1-3 (the only ones that clear the all-pairs floors).
Aqua sits below 3:1 on this surface -> direct labels carry identity.
"""
import json
import sys
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from scipy.signal import savgol_filter

sys.path.insert(0, "code")
from breizh_exp import load                                        # noqa: E402
from figures import AXIS, CAT3, GRID, INK, INK2, MUTED, SURFACE    # noqa: E402

BIN_DOY = 10


def main():
    bz = json.load(open("results/breizh.json"))
    br = bz["runs"]
    X, mask, ys, region, bands, keep = load(cap_per_cell=1500)
    idx = {c: i for i, c in enumerate(keep)}
    y = np.array([idx[v] for v in ys])
    n = len(keep)
    nd = X[:, :, X.shape[2] - 1].copy()
    nd[~mask] = np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        prof = np.stack([np.nanmean(nd[y == c], axis=0) for c in range(n)])
    # The per-bin class means are noisy (cloud gaps leave few observations per
    # bin), so raw curves zigzag and hide the seasonal shape. Savitzky-Golay is
    # the standard smoother for this in the phenology literature.
    profs = np.stack([
        savgol_filter(np.nan_to_num(p, nan=np.nanmean(p)), 7, 2) for p in prof])

    W = 24
    f1 = np.array([np.mean([r["per_class_f1"][c] for r in br
                            if r["w"] == W and r["method"] == "logreg"
                            and r["k"] == 20]) for c in range(n)])

    doy = np.arange(36) * BIN_DOY + BIN_DOY // 2
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11.0, 4.1))

    # ---------------- Panel A: trajectories ----------------
    groups = [("winter cereals (BTH, ORH, TTH, AVH)", ["BTH", "ORH", "TTH", "AVH"], CAT3[0]),
              ("maize (MIE, MIS)", ["MIE", "MIS"], CAT3[1]),
              ("grassland (PPH, RGA)", ["PPH", "RGA"], CAT3[2])]
    for lab, names, col in groups:
        cs = [keep.index(nm) for nm in names if nm in keep]
        for c in cs:
            ax1.plot(doy, profs[c], color=col, lw=1.0, alpha=0.35, zorder=2)
        m = np.nanmean(profs[cs], axis=0)
        ax1.plot(doy, m, color=col, lw=3, zorder=4)
        nudge = {"grassland (PPH, RGA)": 9, "winter cereals (BTH, ORH, TTH, AVH)": -9,
                 "maize (MIE, MIS)": 0}.get(lab, 0)
        ax1.annotate(lab, (doy[-1], m[-1]), textcoords="offset points",
                     xytext=(7, nudge), fontsize=7.4, color=INK2, va="center")
    ax1.axvspan(0, 120, color=GRID, alpha=0.55, zorder=1)
    ax1.annotate("window w=12\n(DOY ≤ 120)", (60, 0.72), fontsize=7.4,
                 color=MUTED, ha="center")
    ax1.set_xlim(0, 520)
    ax1.set_xticks([0, 100, 200, 300, 365])
    ax1.set_ylim(0, 0.82)
    ax1.set_xlabel("day of year", fontsize=8.5)
    ax1.set_ylabel("mean NDVI", fontsize=8.5)
    ax1.set_title("A  at w=12 the maize fields are still bare soil",
                  fontsize=9.5, color=INK, loc="left", pad=6)

    # ---------------- Panel B: F1 vs peak DOY ----------------
    # peak on the RAW profile (matches the statistic reported in the text);
    # Savitzky-Golay is used only to make the trajectories legible.
    peak = np.array([np.nanargmax(prof[c]) * BIN_DOY + BIN_DOY // 2
                     for c in range(n)])
    ok = np.isfinite(f1) & (f1 > 0)
    for lab, names, col in groups:
        cs = [keep.index(nm) for nm in names if nm in keep and ok[idx[nm]]]
        ax2.scatter(peak[cs], f1[cs], s=64, color=col, edgecolor=SURFACE,
                    linewidth=2, zorder=3)
    # The low-F1 classes stack at nearly the same (peak, F1); stagger their
    # labels vertically so every point stays identifiable.
    for i, c in enumerate(sorted([c for c in range(n) if ok[c]],
                                 key=lambda c: (-peak[c], -f1[c]))):
        if f1[c] < 0.26:
            dy = 8 + 9 * (i % 4)
        else:
            dy = 10
        ax2.annotate(keep[c], (peak[c], f1[c]), textcoords="offset points",
                     xytext=(0, dy), ha="center", fontsize=6.4, color=INK2)
    # the naive expectation
    xs = np.linspace(peak[ok].min(), peak[ok].max(), 2)
    ax2.plot(xs, np.linspace(f1[ok].max(), f1[ok].min(), 2), color=AXIS,
             lw=1.6, ls="--", zorder=2)
    ax2.annotate("naive H$_{timing}$:\nlater ⇒ harder", (165, 0.115),
                 fontsize=7.4, color=MUTED, ha="center", va="top")
    r, p = stats.pearsonr(peak[ok], f1[ok])
    ax2.annotate(f"observed: r = {r:+.2f}  (p = {p:.2f}, n.s.)",
                 (0.35, 0.96), xycoords="axes fraction", fontsize=8,
                 color=INK2, ha="center")
    ax2.set_xlabel("class NDVI-peak DOY", fontsize=8.5)
    ax2.set_ylabel(f"per-class $F_1$  (w={W}, logreg $k$=20)", fontsize=8.5)
    ax2.set_ylim(0.05, 0.55)
    ax2.set_title("B  and the naive expectation is not what happens",
                  fontsize=9.5, color=INK, loc="left", pad=6)

    for ax in (ax1, ax2):
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(True, alpha=1.0, zorder=0, color=GRID)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=8)

    fig.tight_layout()
    fig.savefig("figs/fig2_trajectories.png", bbox_inches="tight")
    plt.close(fig)
    print("wrote figs/fig2_trajectories.png")
    print(f"  peak-DOY vs F1: r={r:+.3f} p={p:.3f} n={int(ok.sum())}")
    for lab, names, _ in groups:
        cs = [keep.index(nm) for nm in names if nm in keep and ok[idx[nm]]]
        if cs:
            print(f"  {lab:34s} median F1 = {np.median(f1[cs]):.3f}")


if __name__ == "__main__":
    main()
