"""Region definition + cross-region viability analysis for CropHarvest.

CropHarvest's `dataset` field mixes true regions (germany, ile-de-france, ...) with
global aggregations (geowiki-landcover-2017, croplands, jecam). For a leave-one-region
out protocol we need regions that are (a) geographically coherent and (b) contain
enough samples/classes to evaluate on.
"""
import collections
import json

import numpy as np

GLOBAL_SOURCES = {"geowiki-landcover-2017", "croplands", "jecam"}

# Coarse continents for splitting the global-aggregation sources.
CONTINENT_BINS = [
    ("africa",      (-40,  40), (-25,  55)),
    ("europe",      ( 35,  72), (-15,  45)),
    ("asia",        (  5,  75), ( 45, 180)),
    ("north_america", ( 15,  85), (-170, -50)),
    ("south_america", (-60,  15), (-85, -30)),
    ("oceania",     (-50,   0), (110, 180)),
]


def continent_of(lat, lon):
    for name, (la0, la1), (lo0, lo1) in CONTINENT_BINS:
        if la0 <= lat <= la1 and lo0 <= lon <= lo1:
            return name
    return "other"


def assign_region(m):
    """Stable region label per sample."""
    ds = m["dataset"]
    lat, lon = m.get("lat"), m.get("lon")
    if ds in GLOBAL_SOURCES:
        if lat is None or lon is None:
            return f"{ds}:unknown"
        return f"{ds}:{continent_of(lat, lon)}"
    return ds


def main():
    meta = json.load(open("data/meta_cropharvest.json"))
    X = np.load("data/X_cropharvest.npy")
    assert len(meta) == len(X)

    # crop-type task only (binary is_crop is near-saturated for the reference tasks)
    typed = [(i, m) for i, m in enumerate(meta)
             if m.get("crop_type") is not None
             and m.get("crop_type") != "non_crop"]
    print(f"samples with crop-type label (excl. non_crop): {len(typed)}")

    by_region = collections.defaultdict(collections.Counter)
    for i, m in typed:
        by_region[assign_region(m)][m["crop_type"]] += 1

    all_classes = sorted({m["crop_type"] for _, m in typed})
    print(f"classes: {all_classes}\n")

    print(f"{'region':32s} {'n':>7s} {'#cls':>5s}  classes present")
    viable = []
    for r, cnt in sorted(by_region.items(), key=lambda kv: -sum(kv[1].values())):
        n = sum(cnt.values())
        cls = sorted(cnt)
        flag = ""
        if n >= 300 and len(cls) >= 5:
            viable.append(r)
            flag = "  <== viable"
        print(f"{r:32s} {n:7d} {len(cls):5d}  {','.join(c[:9] for c in cls)}{flag}")

    print(f"\nviable test regions (n>=300, >=5 classes): {len(viable)}")
    for r in viable:
        print(f"  {r}")

    with open("data/regions.json", "w") as f:
        json.dump({
            "classes": all_classes,
            "by_region": {r: dict(c) for r, c in by_region.items()},
            "viable": viable,
        }, f, indent=1)
    print("\nsaved data/regions.json")


if __name__ == "__main__":
    main()
